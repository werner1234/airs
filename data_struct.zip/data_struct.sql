-- MySQL dump 10.16  Distrib 10.2.6-MariaDB, for osx10.12 (x86_64)
--
-- Host: appie12.airshost.nl    Database: airs_btr
-- ------------------------------------------------------
-- Server version	5.5.60-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `AABBETransactieCodes`
--

DROP TABLE IF EXISTS `AABBETransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AABBETransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `bankCode` varchar(10) NOT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `AABTransaktieCodes`
--

DROP TABLE IF EXISTS `AABTransaktieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AABTransaktieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(10) DEFAULT NULL,
  `actie` varchar(50) DEFAULT NULL,
  `toelichting` tinytext,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `AFMKostensoorten`
--

DROP TABLE IF EXISTS `AFMKostensoorten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AFMKostensoorten` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `AfmKostensoort` varchar(30) NOT NULL,
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `API_HZ_logging`
--

DROP TABLE IF EXISTS `API_HZ_logging`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `API_HZ_logging` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `ip` varchar(20) NOT NULL,
  `referer` varchar(200) NOT NULL,
  `request` text NOT NULL,
  `errors` text NOT NULL,
  `results` text NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Accountmanagers`
--

DROP TABLE IF EXISTS `Accountmanagers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Accountmanagers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Accountmanager` varchar(15) DEFAULT NULL,
  `Naam` varchar(75) NOT NULL DEFAULT '',
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `Titel` varchar(50) NOT NULL DEFAULT '',
  `Handtekening` mediumblob NOT NULL,
  `Titel2` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Accountmanager` (`Accountmanager`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1017 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ActieveFondsen`
--

DROP TABLE IF EXISTS `ActieveFondsen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ActieveFondsen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `FondsImportCode` varchar(16) DEFAULT NULL,
  `Fonds` varchar(25) NOT NULL DEFAULT '',
  `ISINCode` varchar(26) NOT NULL DEFAULT '',
  `Valuta` varchar(4) DEFAULT NULL,
  `fondssoort` varchar(8) NOT NULL DEFAULT '',
  `identifierVWD` varchar(20) NOT NULL DEFAULT '',
  `identifierFactSet` varchar(20) NOT NULL DEFAULT '',
  `koersmethodiek` tinyint(3) NOT NULL DEFAULT '0',
  `Aantal` double NOT NULL DEFAULT '0',
  `portefeuilleAantal` int(11) DEFAULT '0',
  `Fondseenheid` double DEFAULT NULL,
  `EindDatum` date NOT NULL DEFAULT '0000-00-00',
  `Lossingsdatum` date NOT NULL DEFAULT '0000-00-00',
  `OptieExpDatum` varchar(6) NOT NULL DEFAULT '',
  `KoersAltijdAanvragen` tinyint(3) NOT NULL DEFAULT '0',
  `koersControleOverslaan` tinyint(3) NOT NULL DEFAULT '0',
  `InPositie` tinyint(3) NOT NULL DEFAULT '0',
  `Actief` tinyint(3) NOT NULL DEFAULT '0',
  `laatsteKoers` double DEFAULT NULL,
  `laatsteKoersDatum` date NOT NULL DEFAULT '0000-00-00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Fonds` (`Fonds`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1714 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `AttributieCategorien`
--

DROP TABLE IF EXISTS `AttributieCategorien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AttributieCategorien` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `AttributieCategorie` varchar(15) DEFAULT NULL,
  `Omschrijving` varchar(50) DEFAULT NULL,
  `Afdrukvolgorde` tinyint(4) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `AttributieCategorie` (`AttributieCategorie`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=63 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `AttributiePerGrootboekrekening`
--

DROP TABLE IF EXISTS `AttributiePerGrootboekrekening`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AttributiePerGrootboekrekening` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `AttributieCategorie` varchar(15) DEFAULT NULL,
  `Grootboekrekening` varchar(5) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `AutoRun`
--

DROP TABLE IF EXISTS `AutoRun`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AutoRun` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) NOT NULL DEFAULT '',
  `Rapportage` varchar(25) NOT NULL DEFAULT '',
  `BestandsNaam` varchar(25) NOT NULL DEFAULT '',
  `Trigger` varchar(25) NOT NULL DEFAULT '',
  `Export_pad` varchar(255) NOT NULL DEFAULT '',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `gebruikersnaam` varchar(200) NOT NULL DEFAULT '',
  `wachtwoord` varchar(200) NOT NULL DEFAULT '',
  `frequentie` tinyint(4) NOT NULL,
  `instellingen` text NOT NULL,
  `autoVanaf` date NOT NULL DEFAULT '0000-00-00',
  `autoLaatste` date NOT NULL DEFAULT '0000-00-00',
  `autoEmailadres` varchar(250) NOT NULL,
  `memo` text NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `BICcodes`
--

DROP TABLE IF EXISTS `BICcodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BICcodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vermogensbeheerder` varchar(10) NOT NULL DEFAULT '',
  `code` varchar(12) NOT NULL DEFAULT '',
  `naam` varchar(50) NOT NULL DEFAULT '',
  `BICcode` varchar(32) NOT NULL DEFAULT '',
  `PSET` tinyint(4) NOT NULL DEFAULT '0',
  `PSAF` tinyint(4) NOT NULL DEFAULT '0',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `landcode` varchar(3) NOT NULL,
  `correspondent` varchar(25) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `BbLandcodes`
--

DROP TABLE IF EXISTS `BbLandcodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BbLandcodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bbLandcode` char(2) DEFAULT NULL,
  `omschrijving` varchar(25) DEFAULT NULL,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `settlementDays` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=82 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Bedrijfsgegevens`
--

DROP TABLE IF EXISTS `Bedrijfsgegevens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Bedrijfsgegevens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Bedrijf` varchar(100) NOT NULL DEFAULT '',
  `Pincode` varchar(10) NOT NULL DEFAULT '',
  `LaatsteUpdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(15) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(15) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `crypted` tinyint(4) NOT NULL DEFAULT '0',
  `laatsteDagelijkeUpdate` datetime NOT NULL,
  `vastzetdatumRapportages` date NOT NULL,
  `zaterdagExport` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=58 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `BeleggingscategoriePerFonds`
--

DROP TABLE IF EXISTS `BeleggingscategoriePerFonds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BeleggingscategoriePerFonds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `Fonds` varchar(25) DEFAULT NULL,
  `Beleggingscategorie` varchar(15) DEFAULT NULL,
  `RisicoPercentageFonds` double DEFAULT NULL,
  `Regio` varchar(15) DEFAULT NULL,
  `grafiekKleur` text NOT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `Vanaf` date NOT NULL DEFAULT '0000-00-00',
  `afmCategorie` varchar(15) NOT NULL DEFAULT '',
  `duurzaamheid` varchar(4) NOT NULL,
  `duurzaamEcon` tinyint(3) NOT NULL DEFAULT '0',
  `duurzaamSociaal` tinyint(3) NOT NULL DEFAULT '0',
  `duurzaamMilieu` tinyint(3) NOT NULL DEFAULT '0',
  `belgTOB` double NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Vermogensbeheerder` (`Vermogensbeheerder`) USING BTREE,
  KEY `Fonds` (`Fonds`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=291884 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `BeleggingscategoriePerFonds_AFM2010_20150821`
--

DROP TABLE IF EXISTS `BeleggingscategoriePerFonds_AFM2010_20150821`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BeleggingscategoriePerFonds_AFM2010_20150821` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `Fonds` varchar(25) DEFAULT NULL,
  `Beleggingscategorie` varchar(15) DEFAULT NULL,
  `RisicoPercentageFonds` double DEFAULT NULL,
  `Regio` varchar(15) DEFAULT NULL,
  `grafiekKleur` text NOT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `Vanaf` date NOT NULL DEFAULT '0000-00-00',
  `afmCategorie` varchar(15) NOT NULL DEFAULT '',
  `duurzaamheid` tinyint(4) NOT NULL DEFAULT '0',
  `duurzaamEcon` tinyint(3) NOT NULL DEFAULT '0',
  `duurzaamSociaal` tinyint(3) NOT NULL DEFAULT '0',
  `duurzaamMilieu` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Vermogensbeheerder` (`Vermogensbeheerder`) USING BTREE,
  KEY `Fonds` (`Fonds`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=109792 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Beleggingscategorien`
--

DROP TABLE IF EXISTS `Beleggingscategorien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Beleggingscategorien` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Beleggingscategorie` varchar(15) DEFAULT NULL,
  `Omschrijving` varchar(50) DEFAULT NULL,
  `Afdrukvolgorde` tinyint(4) DEFAULT NULL,
  `RisicoEUR` double DEFAULT NULL,
  `RisicoVV` double DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Beleggingscategorie` (`Beleggingscategorie`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=524 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `BeleggingscategorienPerWegingscategorie`
--

DROP TABLE IF EXISTS `BeleggingscategorienPerWegingscategorie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BeleggingscategorienPerWegingscategorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `Wegingscategorie` tinyint(4) DEFAULT NULL,
  `Beleggingscategorie` varchar(15) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Beleggingsplan`
--

DROP TABLE IF EXISTS `Beleggingsplan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Beleggingsplan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Portefeuille` varchar(24) NOT NULL,
  `Datum` date NOT NULL DEFAULT '0000-00-00',
  `Waarde` double DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `ProcentRisicoDragend` tinyint(4) NOT NULL DEFAULT '0',
  `ProcentRisicoMijdend` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Portefeuille` (`Portefeuille`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `BeleggingssectorPerFonds`
--

DROP TABLE IF EXISTS `BeleggingssectorPerFonds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BeleggingssectorPerFonds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `Fonds` varchar(25) DEFAULT NULL,
  `Beleggingssector` varchar(15) DEFAULT NULL,
  `Regio` varchar(15) NOT NULL DEFAULT '',
  `AttributieCategorie` varchar(15) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `Vanaf` date NOT NULL DEFAULT '0000-00-00',
  `DuurzaamCategorie` varchar(15) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Fonds` (`Fonds`) USING BTREE,
  KEY `Beleggingssector` (`Beleggingssector`) USING BTREE,
  KEY `Vermogensbeheerder` (`Vermogensbeheerder`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Beleggingssectoren`
--

DROP TABLE IF EXISTS `Beleggingssectoren`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Beleggingssectoren` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Beleggingssector` varchar(15) DEFAULT NULL,
  `Omschrijving` varchar(50) DEFAULT NULL,
  `Afdrukvolgorde` tinyint(4) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `standaard` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Beleggingssector` (`Beleggingssector`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=299 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `BestandsvergoedingPerPortefeuille`
--

DROP TABLE IF EXISTS `BestandsvergoedingPerPortefeuille`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BestandsvergoedingPerPortefeuille` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bestandsvergoedingId` int(11) NOT NULL DEFAULT '0',
  `portefeuille` varchar(24) NOT NULL,
  `bedragBerekend` double NOT NULL DEFAULT '0',
  `bedragUitbetaald` double NOT NULL DEFAULT '0',
  `datumUitbetaald` date NOT NULL DEFAULT '0000-00-00',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `Fonds` varchar(25) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Bestandsvergoedingen`
--

DROP TABLE IF EXISTS `Bestandsvergoedingen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Bestandsvergoedingen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vermogensbeheerder` varchar(5) NOT NULL DEFAULT '',
  `emittent` varchar(15) NOT NULL DEFAULT '',
  `depotbank` varchar(10) DEFAULT NULL,
  `datumBerekend` date NOT NULL DEFAULT '0000-00-00',
  `waardeBerekend` double NOT NULL DEFAULT '0',
  `datumHerrekend` date NOT NULL DEFAULT '0000-00-00',
  `waardeHerrekend` double NOT NULL DEFAULT '0',
  `datumGeaccordeerd` date DEFAULT NULL,
  `datumOntvangen` date NOT NULL DEFAULT '0000-00-00',
  `datumUitbetaald` date NOT NULL DEFAULT '0000-00-00',
  `status` text NOT NULL,
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `periodeVan` date NOT NULL DEFAULT '0000-00-00',
  `periodeTm` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Beurzen`
--

DROP TABLE IF EXISTS `Beurzen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Beurzen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `beurs` varchar(4) DEFAULT NULL,
  `omschrijving` varchar(60) DEFAULT NULL,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `beursregio` varchar(4) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=155 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Bewaarders`
--

DROP TABLE IF EXISTS `Bewaarders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Bewaarders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Bewaarder` varchar(15) DEFAULT NULL,
  `Omschrijving` varchar(50) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Brokerinstructies`
--

DROP TABLE IF EXISTS `Brokerinstructies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Brokerinstructies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vermogensbeheerder` varchar(10) NOT NULL DEFAULT '',
  `depotbank` varchar(10) NOT NULL DEFAULT '',
  `portefeuille` varchar(24) NOT NULL DEFAULT '',
  `iban` varchar(30) NOT NULL DEFAULT '',
  `vvSettlement` varchar(4) NOT NULL DEFAULT '',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CRM_blanco_mutatieQueue`
--

DROP TABLE IF EXISTS `CRM_blanco_mutatieQueue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CRM_blanco_mutatieQueue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `CRM_id` int(11) NOT NULL,
  `blancoId` varchar(100) NOT NULL,
  `verwerkt` tinyint(4) NOT NULL,
  `afgewerkt` tinyint(4) NOT NULL,
  `jsonData` text NOT NULL,
  `verwerktDoor` varchar(25) NOT NULL,
  `verwerktDatum` datetime NOT NULL,
  `md5` varchar(100) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CRM_eigenVelden`
--

DROP TABLE IF EXISTS `CRM_eigenVelden`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CRM_eigenVelden` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `veldnaam` varchar(60) NOT NULL DEFAULT '',
  `omschrijving` varchar(150) NOT NULL DEFAULT '',
  `veldtype` varchar(60) NOT NULL DEFAULT '',
  `weergaveBreedte` int(11) NOT NULL,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `relatieSoort` tinyint(4) NOT NULL DEFAULT '0',
  `headerBreedte` int(11) NOT NULL DEFAULT '0',
  `extraVeldData` text NOT NULL,
  `trekveldSelectieveld` varchar(40) NOT NULL,
  `uitlijning` varchar(1) NOT NULL,
  `getalformat` varchar(3) NOT NULL,
  `aantalTekens` int(11) NOT NULL,
  `omschrijving_en` varchar(150) NOT NULL,
  `omschrijving_fr` varchar(150) NOT NULL,
  `omschrijving_du` varchar(150) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CRM_evenementen`
--

DROP TABLE IF EXISTS `CRM_evenementen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CRM_evenementen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL DEFAULT '0',
  `evenement` varchar(50) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `rel_id` (`rel_id`) USING BTREE,
  KEY `evenement` (`evenement`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CRM_faq`
--

DROP TABLE IF EXISTS `CRM_faq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CRM_faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kop` tinytext,
  `sectie` int(11) DEFAULT NULL,
  `txt` text,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CRM_faq_ow`
--

DROP TABLE IF EXISTS `CRM_faq_ow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CRM_faq_ow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `onderwerp` varchar(30) DEFAULT NULL,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CRM_mutatieQueue`
--

DROP TABLE IF EXISTS `CRM_mutatieQueue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CRM_mutatieQueue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `CRM_id` int(11) NOT NULL,
  `portefeuille` varchar(40) NOT NULL,
  `verwerkt` tinyint(4) NOT NULL,
  `afgewerkt` tinyint(4) NOT NULL,
  `type` varchar(20) NOT NULL,
  `veld` varchar(200) NOT NULL,
  `wasWaarde` varchar(255) NOT NULL,
  `wordtWaarde` varchar(255) NOT NULL,
  `verwerktDoor` varchar(25) NOT NULL,
  `verwerktDatum` datetime NOT NULL,
  `ip` varchar(20) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CRM_naw`
--

DROP TABLE IF EXISTS `CRM_naw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CRM_naw` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `naam` tinytext,
  `zoekveld` varchar(100) NOT NULL DEFAULT '0',
  `portefeuille` varchar(24) NOT NULL,
  `titel` varchar(25) DEFAULT NULL,
  `voorvoegsel` varchar(15) DEFAULT NULL,
  `voorletters` varchar(15) DEFAULT NULL,
  `voornamen` varchar(100) NOT NULL,
  `roepnaam` varchar(25) DEFAULT NULL,
  `tussenvoegsel` varchar(15) DEFAULT NULL,
  `achternaam` varchar(64) DEFAULT NULL,
  `beroep` varchar(60) NOT NULL DEFAULT '',
  `geboortedatum` date DEFAULT NULL,
  `geslacht` varchar(5) DEFAULT NULL,
  `huwelijkseStaat` varchar(60) NOT NULL,
  `nationaliteit` varchar(15) DEFAULT NULL,
  `ingezetene` tinyint(4) DEFAULT NULL,
  `legitimatie` varchar(60) NOT NULL DEFAULT '',
  `nummerID` varchar(15) DEFAULT NULL,
  `landID` varchar(15) DEFAULT NULL,
  `plaatsID` varchar(25) DEFAULT NULL,
  `part_naam` tinytext,
  `part_zoekveld` varchar(50) DEFAULT NULL,
  `part_titel` varchar(25) DEFAULT NULL,
  `part_voorvoegsel` varchar(15) DEFAULT NULL,
  `part_voorletters` varchar(15) DEFAULT NULL,
  `part_voornamen` varchar(100) NOT NULL,
  `part_roepnaam` varchar(25) DEFAULT NULL,
  `part_tussenvoegsel` varchar(15) DEFAULT NULL,
  `part_achternaam` varchar(64) DEFAULT NULL,
  `part_beroep` varchar(60) NOT NULL DEFAULT '',
  `part_geboortedatum` date DEFAULT NULL,
  `part_geslacht` varchar(5) DEFAULT NULL,
  `part_nationaliteit` varchar(15) DEFAULT NULL,
  `part_ingezetene` tinyint(4) DEFAULT NULL,
  `part_legitimatie` varchar(60) NOT NULL DEFAULT '',
  `part_nummerID` varchar(15) DEFAULT NULL,
  `part_landID` varchar(15) DEFAULT NULL,
  `part_plaatsID` varchar(25) DEFAULT NULL,
  `adres` tinytext,
  `pc` varchar(17) DEFAULT NULL,
  `plaats` varchar(30) DEFAULT NULL,
  `land` varchar(25) DEFAULT NULL,
  `tel1_oms` varchar(20) DEFAULT NULL,
  `tel1` varchar(20) NOT NULL DEFAULT '',
  `tel2_oms` varchar(20) DEFAULT NULL,
  `tel2` varchar(20) DEFAULT NULL,
  `fax` varchar(20) DEFAULT NULL,
  `debiteur` tinyint(4) DEFAULT NULL,
  `crediteur` tinyint(4) DEFAULT NULL,
  `crediteurnr` varchar(20) DEFAULT NULL,
  `debiteurnr` varchar(20) DEFAULT NULL,
  `prospect` tinyint(4) DEFAULT NULL,
  `overige` tinyint(4) DEFAULT NULL,
  `website` tinytext,
  `email` tinytext,
  `kvknr` varchar(15) DEFAULT NULL,
  `btwnr` varchar(15) DEFAULT NULL,
  `ondernemingsvorm` varchar(30) NOT NULL,
  `accountant` text,
  `belastingadviseur` text,
  `assurantietussenpersoon` text,
  `overigeAdviseurs` text,
  `tag` tinyint(4) DEFAULT NULL,
  `tag_date` date DEFAULT NULL,
  `mut_dat` date DEFAULT NULL,
  `mut_usr` varchar(5) DEFAULT NULL,
  `memo` text,
  `aktief` tinyint(4) DEFAULT NULL,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `naam1` varchar(60) NOT NULL DEFAULT '',
  `relatieSinds` date NOT NULL DEFAULT '0000-00-00',
  `IdGeldigTot` date NOT NULL DEFAULT '0000-00-00',
  `BSN` varchar(15) NOT NULL DEFAULT '',
  `achtervoegsel` varchar(15) NOT NULL DEFAULT '',
  `verjaardagLijst` tinyint(4) NOT NULL DEFAULT '0',
  `part_IdGeldigTot` date NOT NULL DEFAULT '0000-00-00',
  `part_BSN` varchar(15) NOT NULL DEFAULT '',
  `part_achtervoegsel` varchar(15) NOT NULL DEFAULT '',
  `part_verjaardagLijst` tinyint(4) NOT NULL DEFAULT '0',
  `tel3` varchar(20) NOT NULL DEFAULT '',
  `tel3_oms` varchar(20) NOT NULL DEFAULT '',
  `faxZakelijk` varchar(20) NOT NULL DEFAULT '',
  `emailZakelijk` tinytext NOT NULL,
  `notaris` text NOT NULL,
  `verzendAanhef` tinytext NOT NULL,
  `verzendAdres` tinytext NOT NULL,
  `verzendPc` varchar(17) NOT NULL DEFAULT '',
  `verzendPlaats` varchar(30) NOT NULL DEFAULT '',
  `verzendLand` varchar(25) NOT NULL DEFAULT '',
  `tel4_oms` varchar(20) NOT NULL DEFAULT '',
  `tel4` varchar(20) NOT NULL DEFAULT '',
  `tel5_oms` varchar(20) NOT NULL DEFAULT '',
  `tel5` varchar(20) NOT NULL DEFAULT '',
  `tel6_oms` varchar(20) NOT NULL DEFAULT '',
  `tel6` varchar(20) NOT NULL DEFAULT '',
  `emailPartner` tinytext NOT NULL,
  `emailPartnerZakelijk` tinytext NOT NULL,
  `verzendPaAanhef` tinytext NOT NULL,
  `tel_toev1` varchar(20) NOT NULL DEFAULT '',
  `tel_toev2` varchar(20) NOT NULL DEFAULT '',
  `tel_toev3` varchar(20) NOT NULL DEFAULT '',
  `tel_toev4` varchar(20) NOT NULL DEFAULT '',
  `tel_toev5` varchar(20) NOT NULL DEFAULT '',
  `tel_toev6` varchar(20) NOT NULL DEFAULT '',
  `custodian` text NOT NULL,
  `custodianRekeningNr` varchar(40) NOT NULL DEFAULT '',
  `custodianAfwijkendeAfspraak` text NOT NULL,
  `verzendFreq` varchar(60) NOT NULL DEFAULT '',
  `kvkInDossier` tinyint(4) NOT NULL DEFAULT '0',
  `statutenInDossier` tinyint(4) NOT NULL DEFAULT '0',
  `rekeningActiefSinds` date NOT NULL DEFAULT '0000-00-00',
  `tripartieteInDossier` tinyint(4) NOT NULL DEFAULT '0',
  `tripartieteDatum` date NOT NULL DEFAULT '0000-00-00',
  `vermogenbeheerOvereenkomstInDossier` tinyint(4) NOT NULL DEFAULT '0',
  `vermogenbeheerOvereenkomstDatum` date NOT NULL DEFAULT '0000-00-00',
  `kinderen` tinyint(4) NOT NULL DEFAULT '0',
  `inkomenSoort` varchar(60) NOT NULL DEFAULT '',
  `inkomenIndicatie` double(11,2) NOT NULL DEFAULT '0.00',
  `vermogenOnroerendGoed` double(11,2) NOT NULL DEFAULT '0.00',
  `vermogenHypotheek` double(11,2) NOT NULL DEFAULT '0.00',
  `vermogenOverigVermogen` double(11,2) NOT NULL DEFAULT '0.00',
  `vermogenOverigSchuld` double(11,2) NOT NULL DEFAULT '0.00',
  `vermogenTotaalBelegbaar` double(11,2) NOT NULL DEFAULT '0.00',
  `vermogenBelegdViaDC` double(11,2) NOT NULL DEFAULT '0.00',
  `vermogenHerkomst` text NOT NULL,
  `vermogenVerplichtingen` text NOT NULL,
  `ervaringBelegtSinds` date NOT NULL DEFAULT '0000-00-00',
  `ervaringBelegtInEigenbeheer` varchar(60) NOT NULL DEFAULT '',
  `ervaringBelegtInVermogensadvies` varchar(60) NOT NULL DEFAULT '',
  `ervaringInExecutionOnly` varchar(60) NOT NULL DEFAULT '',
  `ervaringMetVastrentende` varchar(60) NOT NULL DEFAULT '',
  `ervaringMetVastrentendeDatum` date NOT NULL DEFAULT '0000-00-00',
  `ervaringMetBeleggingsFondsen` varchar(60) NOT NULL DEFAULT '',
  `ervaringMetBeleggingsFondsenDatum` date NOT NULL DEFAULT '0000-00-00',
  `ervaringMetIndividueleAandelen` varchar(60) NOT NULL DEFAULT '',
  `ervaringMetIndividueleAandelenDatum` date NOT NULL DEFAULT '0000-00-00',
  `ervaringMetOpties` varchar(60) NOT NULL DEFAULT '',
  `ervaringMetOptiesDatum` date NOT NULL DEFAULT '0000-00-00',
  `ervaringMetFutures` varchar(60) NOT NULL DEFAULT '',
  `ervaringMetFuturesDatum` date NOT NULL DEFAULT '0000-00-00',
  `beleggingsHorizon` varchar(200) NOT NULL,
  `beleggingsDoelstelling` varchar(120) NOT NULL DEFAULT '',
  `risicoprofielFinancieleGegevens` text NOT NULL,
  `risicoprofielGesprek` text NOT NULL,
  `risicoprofielAfwijkendeAfspraak` text NOT NULL,
  `risicoprofielOverig` text NOT NULL,
  `risicoprofiel` varchar(60) NOT NULL DEFAULT '',
  `profielAandelenBinnenland` char(1) NOT NULL DEFAULT '',
  `profielAandelenBuitenland` char(1) NOT NULL DEFAULT '',
  `profielObligatiesEuro` char(1) NOT NULL DEFAULT '',
  `profielObligatiesOverigeValuta` char(1) NOT NULL DEFAULT '',
  `profielWarrants` char(1) NOT NULL DEFAULT '',
  `profielOptiesKopenCalls` char(1) NOT NULL DEFAULT '',
  `profielOptiesOngedektVerkopenCalls` char(1) NOT NULL DEFAULT '',
  `profielOptiesGedektVerkopenCalls` char(1) NOT NULL DEFAULT '',
  `profielOptiesKopenPuts` char(1) NOT NULL DEFAULT '',
  `profielOptiesVerkopenPuts` char(1) NOT NULL DEFAULT '',
  `profielTermijnFutures` char(1) NOT NULL DEFAULT '',
  `profielValutasInclOTC` char(1) NOT NULL DEFAULT '',
  `profielEdelmetalen` char(1) NOT NULL DEFAULT '',
  `profielVerleentToestemmingDebetstanden` char(1) NOT NULL DEFAULT '',
  `profielNietTerbeurzeBeleggingsfondsen` char(1) NOT NULL DEFAULT '',
  `profielInsiderRegeling` text NOT NULL,
  `profielOverigeBeperkingen` text NOT NULL,
  `huidigesamenstellingAandelen` double(11,2) NOT NULL DEFAULT '0.00',
  `huidigesamenstellingObligaties` double(11,2) NOT NULL DEFAULT '0.00',
  `huidigesamenstellingOverige` double(11,2) NOT NULL DEFAULT '0.00',
  `huidigesamenstellingLiquiditeiten` double(11,2) NOT NULL DEFAULT '0.00',
  `huidigesamenstellingTotaal` double(11,2) NOT NULL DEFAULT '0.00',
  `inContactDoor` varchar(60) NOT NULL DEFAULT '',
  `provisieAfspraak` text NOT NULL,
  `opleidingsniveau` varchar(120) NOT NULL,
  `verplichtingenBelasting` double(11,2) NOT NULL DEFAULT '0.00',
  `verplichtingenAssurantien` double(11,2) NOT NULL DEFAULT '0.00',
  `verplichtingenKrediet` double(11,2) NOT NULL DEFAULT '0.00',
  `verplichtingenAlimentatie` double(11,2) NOT NULL DEFAULT '0.00',
  `verplichtingenStudieKinderen` double(11,2) NOT NULL DEFAULT '0.00',
  `toekomstigErfenis` double(11,2) NOT NULL DEFAULT '0.00',
  `toekomstigKapitaalsverz` double(11,2) NOT NULL DEFAULT '0.00',
  `toekomstigVerkoopZaak` double(11,2) NOT NULL DEFAULT '0.00',
  `toekomstigOptieregeling` double(11,2) NOT NULL DEFAULT '0.00',
  `toekomstigPensioenopbouw` double(11,2) NOT NULL DEFAULT '0.00',
  `ervaringMetGestructureerdeProductenDatum` date NOT NULL DEFAULT '0000-00-00',
  `ervaringMetGestructureerdeProducten` varchar(60) NOT NULL DEFAULT '',
  `maandrapportage` text NOT NULL,
  `kwartaalrapportage` text NOT NULL,
  `halfjaarrapportage` text NOT NULL,
  `jaarrapportage` text NOT NULL,
  `ervaringInVermogensbeheer` varchar(60) NOT NULL DEFAULT '',
  `ervaringInVermogensbeheerSinds` date NOT NULL DEFAULT '0000-00-00',
  `ervaringBelegtInEigenbeheerSinds` date NOT NULL DEFAULT '0000-00-00',
  `ervaringBelegtInVermogensadviesSinds` date NOT NULL DEFAULT '0000-00-00',
  `ervaringInExecutionOnlySinds` date NOT NULL DEFAULT '0000-00-00',
  `enOfRekening` tinyint(4) NOT NULL DEFAULT '0',
  `clientenclassificatie` varchar(120) NOT NULL,
  `Relatie1` tinyint(1) NOT NULL DEFAULT '0',
  `Relatie2` tinyint(1) NOT NULL DEFAULT '0',
  `Relatie3` tinyint(1) NOT NULL DEFAULT '0',
  `Relatie4` tinyint(1) NOT NULL DEFAULT '0',
  `Relatie5` tinyint(1) NOT NULL DEFAULT '0',
  `Relatie6` tinyint(1) NOT NULL DEFAULT '0',
  `Relatie7` tinyint(1) NOT NULL DEFAULT '0',
  `Relatie8` tinyint(1) NOT NULL DEFAULT '0',
  `Relatie9` tinyint(1) NOT NULL DEFAULT '0',
  `Relatie10` tinyint(1) NOT NULL DEFAULT '0',
  `prospectStatus` varchar(120) NOT NULL,
  `contactTijd` int(11) NOT NULL DEFAULT '0',
  `prospectStatusChange` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `part_inkomenSoort` varchar(60) NOT NULL DEFAULT '',
  `part_inkomenIndicatie` double(11,2) NOT NULL DEFAULT '0.00',
  `kaartVerstuurd` date NOT NULL DEFAULT '0000-00-00',
  `kaartVerstuurdPartner` date NOT NULL DEFAULT '0000-00-00',
  `prospectEigenaar` varchar(10) NOT NULL DEFAULT '',
  `rapportageVinkSelectie` text NOT NULL,
  `IBAN` varchar(32) NOT NULL DEFAULT '',
  `wachtwoord` varchar(32) NOT NULL DEFAULT '',
  `overlijdensdatum` date NOT NULL DEFAULT '0000-00-00',
  `part_overlijdensdatum` date NOT NULL DEFAULT '0000-00-00',
  `accountEigenaar` varchar(50) NOT NULL DEFAULT '',
  `autoType` varchar(100) NOT NULL DEFAULT '',
  `autoBouwjaar` varchar(10) NOT NULL DEFAULT '',
  `autoKenteken` varchar(10) NOT NULL DEFAULT '',
  `BIC` varchar(20) NOT NULL DEFAULT '',
  `bijeenkomstinteresse` tinyint(4) NOT NULL DEFAULT '0',
  `profielVastgoed` char(1) NOT NULL DEFAULT '',
  `werkgever` varchar(50) NOT NULL DEFAULT '',
  `part_werkgever` varchar(50) NOT NULL DEFAULT '',
  `voorgebeld` tinyint(4) NOT NULL,
  `GeschatVolume` double NOT NULL,
  `SuccesKans` varchar(100) NOT NULL,
  `Birchview` tinyint(4) NOT NULL,
  `Termijn` varchar(100) NOT NULL,
  `startvermogen` double(11,2) NOT NULL DEFAULT '0.00',
  `doelvermogen` double(11,2) NOT NULL DEFAULT '0.00',
  `startdatum` varchar(4) NOT NULL DEFAULT '',
  `doeldatum` varchar(4) NOT NULL DEFAULT '',
  `gewenstRisicoprofiel` varchar(50) NOT NULL DEFAULT '',
  `begeleidendeBrief` varchar(100) NOT NULL DEFAULT '',
  `maximaalRisicoprofiel` varchar(50) NOT NULL DEFAULT '',
  `externID` varchar(50) NOT NULL DEFAULT '',
  `Relatie11` tinyint(1) NOT NULL DEFAULT '0',
  `Relatie12` tinyint(1) NOT NULL DEFAULT '0',
  `Relatie13` tinyint(1) NOT NULL DEFAULT '0',
  `Relatie14` tinyint(1) NOT NULL DEFAULT '0',
  `Relatie15` tinyint(1) NOT NULL DEFAULT '0',
  `CRMGebrNaam` varchar(30) NOT NULL,
  `PortGec` tinyint(3) NOT NULL,
  `laatsteGesprekId` bigint(20) NOT NULL DEFAULT '0',
  `clientGesproken` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `CRMReviewDatum` date NOT NULL,
  `LEInr` varchar(25) NOT NULL,
  `Ptf_ClientTypeRetail` varchar(10) NOT NULL,
  `Ptf_ClientTypeProfessional` varchar(10) NOT NULL,
  `Ptf_ClientTypeEligibleCounterparty` varchar(10) NOT NULL,
  `Ptf_ExpertiseBasic` varchar(10) NOT NULL,
  `Ptf_ExpertiseInformed` varchar(10) NOT NULL,
  `Ptf_ExpertiseAdvanced` varchar(10) NOT NULL,
  `Ptf_CapitalLossNone` varchar(10) NOT NULL,
  `Ptf_CapitalLossLimited` varchar(10) NOT NULL,
  `Ptf_CapitalLossTotal` varchar(10) NOT NULL,
  `Ptf_CapitalLossBeyondInvestment` varchar(10) NOT NULL,
  `Ptf_ProfilePreservation` varchar(10) NOT NULL,
  `Ptf_ProfileGrowth` varchar(10) NOT NULL,
  `Ptf_ProfileIncome` varchar(10) NOT NULL,
  `Ptf_ProfileHedging` varchar(10) NOT NULL,
  `Ptf_ProfileOptionsLeverage` varchar(10) NOT NULL,
  `Ptf_ProfileOther` varchar(10) NOT NULL,
  `Ptf_ServiceExecOnly` varchar(12) NOT NULL,
  `Ptf_ServiceExecOnlyAppTest` varchar(12) NOT NULL,
  `Ptf_ServiceAdvice` varchar(12) NOT NULL,
  `Ptf_ServiceManagement` varchar(12) NOT NULL,
  `Ptf_RiskSRRI` int(11) NOT NULL,
  `Ptf_RiskPRIIPSRI` int(11) NOT NULL,
  `Ptf_ClientHorizon` varchar(10) NOT NULL,
  `Ptf_ClientRiskTolerance` varchar(10) NOT NULL,
  `Ptf_EMT_Beheer` tinyint(3) NOT NULL,
  `blancoId` varchar(100) NOT NULL,
  `hz_dossierId` varchar(25) NOT NULL,
  `LeiGeldigTot` date NOT NULL,
  `tempPortefeuille` varchar(24) NOT NULL,
  `laatsteRapDatumSignalering` date NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `portefeuille` (`portefeuille`) USING BTREE,
  KEY `laatsteGesprekId` (`laatsteGesprekId`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=94 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CRM_naw_RtfTemplates`
--

DROP TABLE IF EXISTS `CRM_naw_RtfTemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CRM_naw_RtfTemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `naam` varchar(255) DEFAULT NULL,
  `standaard` tinyint(4) DEFAULT NULL,
  `template` mediumblob,
  `categorie` varchar(100) DEFAULT NULL,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `verplichteVelden` text NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CRM_naw_adressen`
--

DROP TABLE IF EXISTS `CRM_naw_adressen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CRM_naw_adressen` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `rel_id` bigint(20) DEFAULT NULL,
  `naam` varchar(255) NOT NULL DEFAULT '',
  `naam1` varchar(255) NOT NULL DEFAULT '',
  `adres` varchar(200) NOT NULL DEFAULT '',
  `pc` varchar(17) NOT NULL DEFAULT '',
  `plaats` varchar(30) NOT NULL DEFAULT '',
  `land` varchar(25) NOT NULL DEFAULT '',
  `evenement` varchar(50) NOT NULL DEFAULT '',
  `memo` text,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` date DEFAULT NULL,
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `email` varchar(64) NOT NULL DEFAULT '',
  `wachtwoord` varchar(32) NOT NULL DEFAULT '',
  `geboortedatum` date NOT NULL DEFAULT '0000-00-00',
  `verjaardagLijst` tinyint(4) NOT NULL DEFAULT '0',
  `kaartVerstuurd` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `verzendAanhef` varchar(255) NOT NULL,
  `rapportage` tinyint(3) NOT NULL,
  `voornamen` varchar(100) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `rel_id` (`rel_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CRM_naw_cashflow`
--

DROP TABLE IF EXISTS `CRM_naw_cashflow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CRM_naw_cashflow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` bigint(20) NOT NULL,
  `datum` date NOT NULL DEFAULT '0000-00-00',
  `bedrag` double(11,2) NOT NULL DEFAULT '0.00',
  `add_date` datetime DEFAULT NULL,
  `add_user` varchar(15) DEFAULT NULL,
  `change_user` varchar(15) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `totDatum` date NOT NULL,
  `indexatie` double NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=257 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CRM_naw_cf`
--

DROP TABLE IF EXISTS `CRM_naw_cf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CRM_naw_cf` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `rel_id` bigint(20) DEFAULT NULL,
  `verzendAdres` tinytext,
  `verzendPc` varchar(17) DEFAULT NULL,
  `verzendPlaats` varchar(30) DEFAULT NULL,
  `verzendLand` varchar(25) DEFAULT NULL,
  `custodian` text,
  `custodianRekeningNr` varchar(40) DEFAULT NULL,
  `custodianAfwijkendeAfspraak` text,
  `verzendFreq` varchar(30) DEFAULT NULL,
  `kvkInDossier` tinyint(4) DEFAULT NULL,
  `statutenInDossier` tinyint(4) DEFAULT NULL,
  `rekeningActiefSinds` date DEFAULT NULL,
  `tripartieteInDossier` tinyint(4) DEFAULT NULL,
  `tripartieteDatum` date DEFAULT NULL,
  `vermogenbeheerOvereenkomstInDossier` tinyint(4) DEFAULT NULL,
  `vermogenbeheerOvereenkomstDatum` date DEFAULT NULL,
  `kinderen` tinyint(4) DEFAULT NULL,
  `inkomenSoort` varchar(20) DEFAULT NULL,
  `inkomenIndicatie` double(10,2) DEFAULT NULL,
  `vermogenOnroerendGoed` double(10,2) DEFAULT NULL,
  `vermogenHypotheek` double(10,2) DEFAULT NULL,
  `vermogenOverigVermogen` double(10,2) DEFAULT NULL,
  `vermogenOverigSchuld` double(10,2) DEFAULT NULL,
  `vermogenTotaalBelegbaar` double(10,2) DEFAULT NULL,
  `vermogenBelegdViaDC` double(10,2) DEFAULT NULL,
  `vermogenHerkomst` text,
  `vermogenVerplichtingen` text,
  `ervaringBelegtSinds` date DEFAULT NULL,
  `ervaringBelegtInEigenbeheer` varchar(20) NOT NULL DEFAULT '',
  `ervaringBelegtInVermogensadvies` varchar(20) NOT NULL DEFAULT '',
  `ervaringBelegtInProducten` varchar(20) NOT NULL DEFAULT '',
  `ervaringMetVastrentende` varchar(20) NOT NULL DEFAULT '',
  `ervaringMetVastrentendeDatum` date DEFAULT NULL,
  `ervaringMetBeleggingsFondsen` varchar(20) NOT NULL DEFAULT '',
  `ervaringMetBeleggingsFondsenDatum` date DEFAULT NULL,
  `ervaringMetIndividueleAandelen` varchar(20) NOT NULL DEFAULT '',
  `ervaringMetIndividueleAandelenDatum` date DEFAULT NULL,
  `ervaringMetOpties` varchar(20) NOT NULL DEFAULT '',
  `ervaringMetOptiesDatum` date DEFAULT NULL,
  `ervaringMetFutures` varchar(20) NOT NULL DEFAULT '',
  `ervaringMetFuturesDatum` date DEFAULT NULL,
  `beleggingsHorizon` varchar(20) DEFAULT NULL,
  `beleggingsDoelstelling` varchar(30) DEFAULT NULL,
  `risicoprofielFinancieleGegevens` text,
  `risicoprofielGesprek` text,
  `risicoprofielAfwijkendeAfspraak` text,
  `risicoprofielOverig` text,
  `risicoprofiel` varchar(20) DEFAULT NULL,
  `profielAandelenBinnenland` char(1) DEFAULT NULL,
  `profielAandelenBuitenland` char(1) DEFAULT NULL,
  `profielObligatiesEuro` char(1) DEFAULT NULL,
  `profielObligatiesOverigeValuta` char(1) DEFAULT NULL,
  `profielWarrants` char(1) DEFAULT NULL,
  `profielOptiesKopenCalls` char(1) DEFAULT NULL,
  `profielOptiesOngedektVerkopenCalls` char(1) DEFAULT NULL,
  `profielOptiesGedektVerkopenCalls` char(1) DEFAULT NULL,
  `profielOptiesKopenPuts` char(1) DEFAULT NULL,
  `profielOptiesVerkopenPuts` char(1) DEFAULT NULL,
  `profielTermijnFutures` char(1) DEFAULT NULL,
  `profielValutasInclOTC` char(1) DEFAULT NULL,
  `profielEdelmetalen` char(1) DEFAULT NULL,
  `profielVerleentToestemmingDebetstanden` char(1) DEFAULT NULL,
  `profielNietTerbeurzeBeleggingsfondsen` char(1) DEFAULT NULL,
  `profielInsiderRegeling` text,
  `profielOverigeBeperkingen` text,
  `huidigesamenstellingAandelen` double(10,2) DEFAULT NULL,
  `huidigesamenstellingObligaties` double(10,2) DEFAULT NULL,
  `huidigesamenstellingOverige` double(10,2) DEFAULT NULL,
  `huidigesamenstellingLiquiditeiten` double(10,2) DEFAULT NULL,
  `huidigesamenstellingTotaal` double(10,2) DEFAULT NULL,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `verzendAanhef` tinytext NOT NULL,
  `inContactDoor` varchar(30) NOT NULL DEFAULT '',
  `provisieAfspraak` text NOT NULL,
  `opleidingsniveau` varchar(20) NOT NULL DEFAULT '',
  `verplichtingenBelasting` double(10,2) NOT NULL DEFAULT '0.00',
  `verplichtingenAssurantien` double(10,2) NOT NULL DEFAULT '0.00',
  `verplichtingenKrediet` double(10,2) NOT NULL DEFAULT '0.00',
  `verplichtingenAlimentatie` double(10,2) NOT NULL DEFAULT '0.00',
  `verplichtingenStudieKinderen` double(10,2) NOT NULL DEFAULT '0.00',
  `toekomstigErfenis` double(10,2) NOT NULL DEFAULT '0.00',
  `toekomstigKapitaalsverz` double(10,2) NOT NULL DEFAULT '0.00',
  `toekomstigVerkoopZaak` double(10,2) NOT NULL DEFAULT '0.00',
  `toekomstigOptieregeling` double(10,2) NOT NULL DEFAULT '0.00',
  `toekomstigPensioenopbouw` double(10,2) NOT NULL DEFAULT '0.00',
  `ervaringMetGestructureerdeProductenDatum` date NOT NULL DEFAULT '0000-00-00',
  `ervaringMetGestructureerdeProducten` varchar(20) NOT NULL DEFAULT '',
  `maandrapportage` text NOT NULL,
  `kwartaalrapportage` text NOT NULL,
  `halfjaarrapportage` text NOT NULL,
  `jaarrapportage` text NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CRM_naw_cf_copy`
--

DROP TABLE IF EXISTS `CRM_naw_cf_copy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CRM_naw_cf_copy` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `rel_id` bigint(20) DEFAULT NULL,
  `verzendAdres` tinytext,
  `verzendPc` varchar(17) DEFAULT NULL,
  `verzendPlaats` varchar(30) DEFAULT NULL,
  `verzendLand` varchar(25) DEFAULT NULL,
  `custodian` text,
  `custodianRekeningNr` varchar(40) DEFAULT NULL,
  `custodianAfwijkendeAfspraak` text,
  `verzendFreq` varchar(30) DEFAULT NULL,
  `kvkInDossier` tinyint(4) DEFAULT NULL,
  `statutenInDossier` tinyint(4) DEFAULT NULL,
  `rekeningActiefSinds` date DEFAULT NULL,
  `tripartieteInDossier` tinyint(4) DEFAULT NULL,
  `tripartieteDatum` date DEFAULT NULL,
  `vermogenbeheerOvereenkomstInDossier` tinyint(4) DEFAULT NULL,
  `vermogenbeheerOvereenkomstDatum` date DEFAULT NULL,
  `kinderen` tinyint(4) DEFAULT NULL,
  `inkomenSoort` varchar(20) DEFAULT NULL,
  `inkomenIndicatie` double(10,2) DEFAULT NULL,
  `vermogenOnroerendGoed` double(10,2) DEFAULT NULL,
  `vermogenHypotheek` double(10,2) DEFAULT NULL,
  `vermogenOverigVermogen` double(10,2) DEFAULT NULL,
  `vermogenOverigSchuld` double(10,2) DEFAULT NULL,
  `vermogenTotaalBelegbaar` double(10,2) DEFAULT NULL,
  `vermogenBelegdViaDC` double(10,2) DEFAULT NULL,
  `vermogenHerkomst` text,
  `vermogenVerplichtingen` text,
  `ervaringBelegtSinds` date DEFAULT NULL,
  `ervaringBelegtInEigenbeheer` tinyint(4) DEFAULT NULL,
  `ervaringBelegtInVermogensadvies` tinyint(4) DEFAULT NULL,
  `ervaringBelegtInProducten` tinyint(4) DEFAULT NULL,
  `ervaringMetVastrentende` tinyint(4) DEFAULT NULL,
  `ervaringMetVastrentendeDatum` date DEFAULT NULL,
  `ervaringMetBeleggingsFondsen` tinyint(4) DEFAULT NULL,
  `ervaringMetBeleggingsFondsenDatum` date DEFAULT NULL,
  `ervaringMetIndividueleAandelen` tinyint(4) DEFAULT NULL,
  `ervaringMetIndividueleAandelenDatum` date DEFAULT NULL,
  `ervaringMetOpties` tinyint(4) DEFAULT NULL,
  `ervaringMetOptiesDatum` date DEFAULT NULL,
  `ervaringMetFutures` tinyint(4) DEFAULT NULL,
  `ervaringMetFuturesDatum` date DEFAULT NULL,
  `beleggingsHorizon` varchar(20) DEFAULT NULL,
  `beleggingsDoelstelling` varchar(30) DEFAULT NULL,
  `risicoprofielFinancieleGegevens` text,
  `risicoprofielGesprek` text,
  `risicoprofielAfwijkendeAfspraak` text,
  `risicoprofielOverig` text,
  `risicoprofiel` varchar(20) DEFAULT NULL,
  `profielAandelenBinnenland` char(1) DEFAULT NULL,
  `profielAandelenBuitenland` char(1) DEFAULT NULL,
  `profielObligatiesEuro` char(1) DEFAULT NULL,
  `profielObligatiesOverigeValuta` char(1) DEFAULT NULL,
  `profielWarrants` char(1) DEFAULT NULL,
  `profielOptiesKopenCalls` char(1) DEFAULT NULL,
  `profielOptiesOngedektVerkopenCalls` char(1) DEFAULT NULL,
  `profielOptiesGedektVerkopenCalls` char(1) DEFAULT NULL,
  `profielOptiesKopenPuts` char(1) DEFAULT NULL,
  `profielOptiesVerkopenPuts` char(1) DEFAULT NULL,
  `profielTermijnFutures` char(1) DEFAULT NULL,
  `profielValutasInclOTC` char(1) DEFAULT NULL,
  `profielEdelmetalen` char(1) DEFAULT NULL,
  `profielVerleentToestemmingDebetstanden` char(1) DEFAULT NULL,
  `profielNietTerbeurzeBeleggingsfondsen` char(1) DEFAULT NULL,
  `profielInsiderRegeling` text,
  `profielOverigeBeperkingen` text,
  `huidigesamenstellingAandelen` double(10,2) DEFAULT NULL,
  `huidigesamenstellingObligaties` double(10,2) DEFAULT NULL,
  `huidigesamenstellingOverige` double(10,2) DEFAULT NULL,
  `huidigesamenstellingLiquiditeiten` double(10,2) DEFAULT NULL,
  `huidigesamenstellingTotaal` double(10,2) DEFAULT NULL,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `verzendAanhef` tinytext NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CRM_naw_copy`
--

DROP TABLE IF EXISTS `CRM_naw_copy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CRM_naw_copy` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `naam` tinytext,
  `zoekveld` varchar(50) DEFAULT NULL,
  `portefeuille` varchar(20) DEFAULT NULL,
  `titel` varchar(25) DEFAULT NULL,
  `voorvoegsel` varchar(15) DEFAULT NULL,
  `voorletters` varchar(15) DEFAULT NULL,
  `voornamen` varchar(35) DEFAULT NULL,
  `roepnaam` varchar(25) DEFAULT NULL,
  `tussenvoegsel` varchar(15) DEFAULT NULL,
  `achternaam` varchar(64) DEFAULT NULL,
  `beroep` varchar(30) NOT NULL DEFAULT '',
  `geboortedatum` date DEFAULT NULL,
  `geslacht` varchar(5) DEFAULT NULL,
  `huwelijkseStaat` varchar(40) DEFAULT NULL,
  `nationaliteit` varchar(15) DEFAULT NULL,
  `ingezetene` tinyint(4) DEFAULT NULL,
  `legitimatie` varchar(15) DEFAULT NULL,
  `nummerID` varchar(15) DEFAULT NULL,
  `landID` varchar(15) DEFAULT NULL,
  `plaatsID` varchar(25) DEFAULT NULL,
  `part_naam` tinytext,
  `part_zoekveld` varchar(50) DEFAULT NULL,
  `part_titel` varchar(25) DEFAULT NULL,
  `part_voorvoegsel` varchar(15) DEFAULT NULL,
  `part_voorletters` varchar(15) DEFAULT NULL,
  `part_voornamen` varchar(35) DEFAULT NULL,
  `part_roepnaam` varchar(25) DEFAULT NULL,
  `part_tussenvoegsel` varchar(15) DEFAULT NULL,
  `part_achternaam` varchar(64) DEFAULT NULL,
  `part_beroep` varchar(30) NOT NULL DEFAULT '',
  `part_geboortedatum` date DEFAULT NULL,
  `part_geslacht` varchar(5) DEFAULT NULL,
  `part_nationaliteit` varchar(15) DEFAULT NULL,
  `part_ingezetene` tinyint(4) DEFAULT NULL,
  `part_legitimatie` varchar(15) DEFAULT NULL,
  `part_nummerID` varchar(15) DEFAULT NULL,
  `part_landID` varchar(15) DEFAULT NULL,
  `part_plaatsID` varchar(25) DEFAULT NULL,
  `adres` tinytext,
  `pc` varchar(17) DEFAULT NULL,
  `plaats` varchar(30) DEFAULT NULL,
  `land` varchar(25) DEFAULT NULL,
  `tel1_oms` varchar(20) DEFAULT NULL,
  `tel1` varchar(20) NOT NULL DEFAULT '',
  `tel2_oms` varchar(20) DEFAULT NULL,
  `tel2` varchar(20) DEFAULT NULL,
  `fax` varchar(20) DEFAULT NULL,
  `debiteur` tinyint(4) DEFAULT NULL,
  `crediteur` tinyint(4) DEFAULT NULL,
  `crediteurnr` varchar(20) DEFAULT NULL,
  `debiteurnr` varchar(20) DEFAULT NULL,
  `prospect` tinyint(4) DEFAULT NULL,
  `overige` tinyint(4) DEFAULT NULL,
  `website` tinytext,
  `email` tinytext,
  `kvknr` varchar(15) DEFAULT NULL,
  `btwnr` varchar(15) DEFAULT NULL,
  `ondernemingsvorm` varchar(15) DEFAULT NULL,
  `accountant` text,
  `belastingadviseur` text,
  `assurantietussenpersoon` text,
  `overigeAdviseurs` text,
  `tag` tinyint(4) DEFAULT NULL,
  `tag_date` date DEFAULT NULL,
  `mut_dat` date DEFAULT NULL,
  `mut_usr` varchar(5) DEFAULT NULL,
  `memo` text,
  `aktief` tinyint(4) DEFAULT NULL,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `naam1` varchar(60) NOT NULL DEFAULT '',
  `relatieSinds` date NOT NULL DEFAULT '0000-00-00',
  `afgifteID` date NOT NULL DEFAULT '0000-00-00',
  `SofiNr` varchar(15) NOT NULL DEFAULT '',
  `achtervoegsel` varchar(15) NOT NULL DEFAULT '',
  `verjaardagLijst` tinyint(4) NOT NULL DEFAULT '0',
  `part_afgifteID` date NOT NULL DEFAULT '0000-00-00',
  `part_SofiNr` varchar(15) NOT NULL DEFAULT '',
  `part_achtervoegsel` varchar(15) NOT NULL DEFAULT '',
  `part_verjaardagLijst` tinyint(4) NOT NULL DEFAULT '0',
  `tel3` varchar(20) NOT NULL DEFAULT '',
  `tel3_oms` varchar(20) NOT NULL DEFAULT '',
  `faxZakelijk` varchar(20) NOT NULL DEFAULT '',
  `emailZakelijk` tinytext NOT NULL,
  `notaris` text NOT NULL,
  `verzendAanhef` tinytext NOT NULL,
  `verzendAdres` tinytext NOT NULL,
  `verzendPc` varchar(17) NOT NULL DEFAULT '',
  `verzendPlaats` varchar(30) NOT NULL DEFAULT '',
  `verzendLand` varchar(25) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CRM_naw_documenten`
--

DROP TABLE IF EXISTS `CRM_naw_documenten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CRM_naw_documenten` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT '0',
  `bestandsnaam` varchar(100) DEFAULT NULL,
  `omschrijving` text,
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CRM_naw_dossier`
--

DROP TABLE IF EXISTS `CRM_naw_dossier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CRM_naw_dossier` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `rel_id` bigint(20) DEFAULT NULL,
  `datum` datetime DEFAULT NULL,
  `kop` tinytext,
  `txt` text,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `duur` time NOT NULL DEFAULT '00:00:00',
  `memo` tinytext NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT '',
  `clientGesproken` tinyint(4) NOT NULL DEFAULT '0',
  `aanwezig` varchar(255) NOT NULL,
  `dd_reference_id` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `rel_id` (`rel_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CRM_naw_dossier_templates`
--

DROP TABLE IF EXISTS `CRM_naw_dossier_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CRM_naw_dossier_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `omschrijving` varchar(50) NOT NULL DEFAULT '',
  `template` mediumtext,
  `memo` text NOT NULL,
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL,
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CRM_naw_kontaktpersoon`
--

DROP TABLE IF EXISTS `CRM_naw_kontaktpersoon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CRM_naw_kontaktpersoon` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `rel_id` bigint(20) DEFAULT NULL,
  `naam` tinytext,
  `sortering` varchar(20) DEFAULT NULL,
  `functie` varchar(100) NOT NULL DEFAULT '',
  `tel1` varchar(20) DEFAULT NULL,
  `tel1_oms` varchar(20) DEFAULT NULL,
  `tel2` varchar(20) DEFAULT NULL,
  `tel2_oms` varchar(20) DEFAULT NULL,
  `email` tinytext,
  `crm_password` varchar(50) NOT NULL DEFAULT '',
  `crm_login` tinyint(1) NOT NULL DEFAULT '0',
  `crm_lastseen` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` date DEFAULT NULL,
  `memo` text,
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `adres` varchar(200) NOT NULL DEFAULT '',
  `pc` varchar(17) NOT NULL DEFAULT '',
  `plaats` varchar(30) NOT NULL DEFAULT '',
  `land` varchar(25) NOT NULL DEFAULT '',
  `fax_nr` varchar(20) NOT NULL DEFAULT '',
  `naam1` varchar(255) NOT NULL DEFAULT '',
  `geboortedatum` date NOT NULL,
  `verjaardagLijst` tinyint(4) NOT NULL DEFAULT '0',
  `paspoortNummer` varchar(15) NOT NULL,
  `nationaliteit` varchar(25) NOT NULL,
  `paspoortGeldigTot` date NOT NULL,
  `contactpersoonUBO` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `rel_id` (`rel_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CRM_naw_rekeningen`
--

DROP TABLE IF EXISTS `CRM_naw_rekeningen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CRM_naw_rekeningen` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `rel_id` bigint(20) DEFAULT NULL,
  `rekening` varchar(20) NOT NULL DEFAULT '',
  `bank` varchar(50) NOT NULL DEFAULT '',
  `omschrijving` varchar(60) NOT NULL DEFAULT '',
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` date DEFAULT NULL,
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `IBAN` varchar(50) NOT NULL DEFAULT '',
  `BICcode` varchar(20) NOT NULL DEFAULT '',
  `memo` text NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `rel_id` (`rel_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CRM_naw_templates`
--

DROP TABLE IF EXISTS `CRM_naw_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CRM_naw_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tabs` mediumtext,
  `veldenPerTab` mediumtext,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `memo` text NOT NULL,
  `intake` tinyint(3) NOT NULL,
  `pdfMaken` tinyint(3) NOT NULL,
  `intakeOmschrijving` varchar(50) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CRM_selectievelden`
--

DROP TABLE IF EXISTS `CRM_selectievelden`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CRM_selectievelden` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(40) DEFAULT NULL,
  `waarde` varchar(40) DEFAULT NULL,
  `omschrijving` varchar(200) NOT NULL,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `extra` text NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CRM_uur_activiteiten`
--

DROP TABLE IF EXISTS `CRM_uur_activiteiten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CRM_uur_activiteiten` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `code` varchar(4) NOT NULL DEFAULT '',
  `omschrijving` varchar(50) NOT NULL DEFAULT '',
  `uurtarief` double NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CRM_uur_registratie`
--

DROP TABLE IF EXISTS `CRM_uur_registratie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CRM_uur_registratie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `wn_code` varchar(10) NOT NULL DEFAULT '',
  `datum` date NOT NULL DEFAULT '0000-00-00',
  `deb_id` int(11) NOT NULL DEFAULT '0',
  `act_id` int(11) NOT NULL DEFAULT '0',
  `tijd` double NOT NULL DEFAULT '0',
  `memo` text NOT NULL,
  `verwerkt` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CategorienPerHoofdcategorie`
--

DROP TABLE IF EXISTS `CategorienPerHoofdcategorie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CategorienPerHoofdcategorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `Hoofdcategorie` varchar(15) DEFAULT NULL,
  `Beleggingscategorie` varchar(15) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Vermogensbeheerder` (`Vermogensbeheerder`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=522 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CategorienPerVermogensbeheerder`
--

DROP TABLE IF EXISTS `CategorienPerVermogensbeheerder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CategorienPerVermogensbeheerder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Beleggingscategorie` varchar(15) DEFAULT NULL,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Vermogensbeheerder` (`Vermogensbeheerder`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Clienten`
--

DROP TABLE IF EXISTS `Clienten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Clienten` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Client` varchar(25) NOT NULL,
  `Naam` varchar(50) DEFAULT NULL,
  `Naam1` varchar(50) DEFAULT NULL,
  `Adres` varchar(50) DEFAULT NULL,
  `Woonplaats` varchar(50) DEFAULT NULL,
  `Telefoon` varchar(15) DEFAULT NULL,
  `Fax` varchar(15) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `Land` varchar(50) NOT NULL DEFAULT '',
  `Wachtwoord` varchar(15) DEFAULT NULL,
  `pc` varchar(17) NOT NULL DEFAULT '',
  `consolidatie` tinyint(3) NOT NULL,
  `extraInfo` text NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Client` (`Client`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=102932 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Controles`
--

DROP TABLE IF EXISTS `Controles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Controles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `TestNummer` bigint(20) DEFAULT NULL,
  `String1` varchar(255) DEFAULT NULL,
  `String2` varchar(255) DEFAULT NULL,
  `String3` varchar(255) DEFAULT NULL,
  `String4` varchar(255) DEFAULT NULL,
  `String5` varchar(255) DEFAULT NULL,
  `Double1` double DEFAULT NULL,
  `Double2` double DEFAULT NULL,
  `Double3` double DEFAULT NULL,
  `Double4` double DEFAULT NULL,
  `Double5` double DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `DepositoRentepercentages`
--

DROP TABLE IF EXISTS `DepositoRentepercentages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DepositoRentepercentages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Rekening` varchar(25) NOT NULL,
  `DatumVan` datetime DEFAULT NULL,
  `DatumTot` datetime DEFAULT NULL,
  `Rentepercentage` double DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Rekening` (`Rekening`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Depotbanken`
--

DROP TABLE IF EXISTS `Depotbanken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Depotbanken` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Depotbank` varchar(10) DEFAULT NULL,
  `Omschrijving` varchar(50) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `IbanVoorloop` varchar(32) NOT NULL DEFAULT '',
  `BICcode` varchar(32) NOT NULL,
  `orderLayout` tinyint(3) NOT NULL,
  `orderRekeningTonen` tinyint(3) NOT NULL,
  `LEInrDepBank` varchar(25) NOT NULL,
  `landCode` varchar(3) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Depotbank` (`Depotbank`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=122 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `DuurzaamCategorien`
--

DROP TABLE IF EXISTS `DuurzaamCategorien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DuurzaamCategorien` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `DuurzaamCategorie` varchar(15) DEFAULT NULL,
  `Omschrijving` varchar(50) DEFAULT NULL,
  `Afdrukvolgorde` tinyint(4) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Eigenaars`
--

DROP TABLE IF EXISTS `Eigenaars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Eigenaars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Eigenaar` varchar(16) DEFAULT NULL,
  `Naam` varchar(50) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EigendomPerPortefeuille`
--

DROP TABLE IF EXISTS `EigendomPerPortefeuille`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EigendomPerPortefeuille` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Portefeuille` varchar(24) NOT NULL,
  `Eigenaar` varchar(16) DEFAULT NULL,
  `percentage` double DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Portefeuille` (`Portefeuille`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `FactuurBeheerfeeHistorie`
--

DROP TABLE IF EXISTS `FactuurBeheerfeeHistorie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FactuurBeheerfeeHistorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `portefeuille` varchar(24) NOT NULL,
  `rekeningmutatieId` int(11) NOT NULL,
  `factuurNr` varchar(20) NOT NULL,
  `periodeDatum` date NOT NULL DEFAULT '0000-00-00',
  `grondslag` double NOT NULL DEFAULT '0',
  `beheerfee` double NOT NULL DEFAULT '0',
  `bedragBuitenBtw` double NOT NULL DEFAULT '0',
  `bedragVerrekendeHuisfondsen` double NOT NULL DEFAULT '0',
  `btw` double NOT NULL DEFAULT '0',
  `bedragTotaal` double NOT NULL DEFAULT '0',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `portefeuille` (`portefeuille`) USING BTREE,
  KEY `periodeDatum` (`periodeDatum`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `FactuurHistorie`
--

DROP TABLE IF EXISTS `FactuurHistorie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FactuurHistorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `portefeuille` varchar(24) NOT NULL,
  `factuurNr` int(11) NOT NULL DEFAULT '0',
  `periodeDatum` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `grondslag` double NOT NULL DEFAULT '0',
  `fee` double NOT NULL DEFAULT '0',
  `btw` double NOT NULL DEFAULT '0',
  `totaalIncl` double NOT NULL DEFAULT '0',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `omschrijving` varchar(100) NOT NULL DEFAULT '',
  `factuurDatum` date NOT NULL DEFAULT '0000-00-00',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `printDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `betaald` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `portefeuille` (`portefeuille`) USING BTREE,
  KEY `periodeDatum` (`periodeDatum`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Factuurregels`
--

DROP TABLE IF EXISTS `Factuurregels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Factuurregels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `portefeuille` varchar(24) NOT NULL,
  `datum` datetime DEFAULT NULL,
  `omschrijving` varchar(200) NOT NULL,
  `bedrag` double NOT NULL DEFAULT '0',
  `btw` tinyint(3) NOT NULL DEFAULT '0',
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `portefeuille` (`portefeuille`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `FondsExtraInformatie`
--

DROP TABLE IF EXISTS `FondsExtraInformatie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FondsExtraInformatie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fonds` varchar(25) DEFAULT NULL,
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `FondsRapportagenaam` varchar(50) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `fonds` (`fonds`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `FondsExtraTrekvelden`
--

DROP TABLE IF EXISTS `FondsExtraTrekvelden`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FondsExtraTrekvelden` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trekveld` varchar(60) NOT NULL DEFAULT '',
  `waarde` varchar(60) NOT NULL DEFAULT '',
  `volgorde` int(3) NOT NULL DEFAULT '0',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `trekveld` (`trekveld`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `FondsExtraVelden`
--

DROP TABLE IF EXISTS `FondsExtraVelden`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FondsExtraVelden` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `veldnaam` varchar(60) NOT NULL DEFAULT '',
  `omschrijving` varchar(150) NOT NULL,
  `veldtype` varchar(60) NOT NULL DEFAULT '',
  `volgorde` int(3) NOT NULL DEFAULT '0',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `inActief` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `veldnaam` (`veldnaam`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `FondsOmschrijvingVanaf`
--

DROP TABLE IF EXISTS `FondsOmschrijvingVanaf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FondsOmschrijvingVanaf` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Fonds` varchar(25) DEFAULT '',
  `Omschrijving` varchar(50) DEFAULT '',
  `Vanaf` date DEFAULT '0000-00-00',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FondsVanaf` (`Fonds`,`Vanaf`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1012 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `FondsParameterHistorie`
--

DROP TABLE IF EXISTS `FondsParameterHistorie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FondsParameterHistorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Fonds` varchar(25) DEFAULT '',
  `GebruikTot` date DEFAULT '0000-00-00',
  `Rentedatum` datetime NOT NULL,
  `Renteperiode` tinyint(4) NOT NULL,
  `EersteRentedatum` datetime NOT NULL,
  `Lossingsdatum` date NOT NULL DEFAULT '0000-00-00',
  `lossingskoers` double NOT NULL DEFAULT '0',
  `Rente30_360` tinyint(4) NOT NULL,
  `variabeleCoupon` tinyint(1) NOT NULL,
  `OblSoortFloater` varchar(2) NOT NULL,
  `inflatieGekoppeld` tinyint(3) NOT NULL,
  `OblPerpetual` tinyint(3) NOT NULL,
  `OblDirtyPr` tinyint(3) NOT NULL,
  `OblMemo` text NOT NULL,
  `datumControleStatics` datetime NOT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FondsTot` (`Fonds`,`GebruikTot`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Fondsen`
--

DROP TABLE IF EXISTS `Fondsen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fondsen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Fonds` varchar(25) DEFAULT NULL,
  `Omschrijving` varchar(50) DEFAULT NULL,
  `FondsImportCode` varchar(16) DEFAULT NULL,
  `Valuta` varchar(4) DEFAULT NULL,
  `Fondseenheid` double DEFAULT NULL,
  `Rentepercentage` double DEFAULT NULL,
  `Rentedatum` datetime DEFAULT NULL,
  `ISINCode` varchar(26) NOT NULL DEFAULT '',
  `TGBCode` varchar(25) NOT NULL DEFAULT '',
  `snsCode` varchar(25) NOT NULL DEFAULT '',
  `binckCode` varchar(26) NOT NULL DEFAULT '',
  `Renteperiode` bigint(20) DEFAULT NULL,
  `Rente30_360` tinyint(4) NOT NULL DEFAULT '0',
  `EersteRentedatum` datetime DEFAULT NULL,
  `AABCode` varchar(26) NOT NULL DEFAULT '',
  `ABRCode` varchar(26) NOT NULL DEFAULT '',
  `Huisfonds` tinyint(4) DEFAULT NULL,
  `Portefeuille` varchar(24) NOT NULL,
  `EindDatum` date NOT NULL DEFAULT '0000-00-00',
  `Lossingsdatum` date NOT NULL DEFAULT '0000-00-00',
  `AantalParticipaties` int(11) NOT NULL DEFAULT '0',
  `FondsOverslaanInValutaRisico` tinyint(4) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `stroeveCode` varchar(25) NOT NULL DEFAULT '',
  `HeeftOptie` tinyint(4) NOT NULL DEFAULT '0',
  `OptieType` char(1) NOT NULL DEFAULT '',
  `OptieExpDatum` varchar(6) NOT NULL DEFAULT '',
  `OptieUitoefenPrijs` double NOT NULL DEFAULT '0',
  `OptieBovenliggendFonds` varchar(25) NOT NULL DEFAULT '',
  `Garantiepercentage` double NOT NULL DEFAULT '0',
  `optieCode` varchar(30) NOT NULL DEFAULT '',
  `rating` varchar(26) NOT NULL DEFAULT '',
  `beurs` varchar(4) NOT NULL DEFAULT '',
  `bbLandcode` char(2) NOT NULL DEFAULT '',
  `valutaRisicoPercentage` double NOT NULL DEFAULT '100',
  `raboCode` varchar(35) NOT NULL DEFAULT '',
  `variabeleCoupon` tinyint(1) NOT NULL DEFAULT '0',
  `snsSecCode` varchar(30) NOT NULL DEFAULT '',
  `aabbeCode` varchar(50) NOT NULL,
  `koersControle` tinyint(4) NOT NULL DEFAULT '0',
  `standaardSector` varchar(15) NOT NULL DEFAULT '',
  `forward` tinyint(4) NOT NULL DEFAULT '0',
  `forwardReferentieKoers` double NOT NULL DEFAULT '0',
  `forwardAfloopDatum` date NOT NULL DEFAULT '0000-00-00',
  `lossingskoers` double NOT NULL DEFAULT '0',
  `bucketCode` varchar(26) NOT NULL DEFAULT '',
  `identifierVWD` varchar(80) NOT NULL DEFAULT '',
  `identifierFactSet` varchar(30) NOT NULL,
  `koersmethodiek` tinyint(3) NOT NULL DEFAULT '0',
  `KoersAltijdAanvragen` tinyint(3) NOT NULL DEFAULT '0',
  `fondssoort` varchar(8) NOT NULL DEFAULT '',
  `inflatieGekoppeld` tinyint(3) NOT NULL,
  `koersmemo` varchar(255) NOT NULL,
  `kasbankCode` varchar(26) NOT NULL,
  `OblMemo` text NOT NULL,
  `OblSoortFloater` varchar(20) NOT NULL,
  `OblPerpetual` tinyint(3) NOT NULL,
  `OblDirtyPr` tinyint(3) NOT NULL,
  `datumControleStatics` datetime NOT NULL,
  `KoersVBH` varchar(10) NOT NULL,
  `koersBron` tinyint(3) NOT NULL,
  `koersFrequentie` tinyint(3) NOT NULL,
  `koersbronOpm` text NOT NULL,
  `revisieDatum` date NOT NULL,
  `FVLCode` varchar(35) NOT NULL DEFAULT '',
  `CSCode` varchar(25) NOT NULL,
  `giroCode` varchar(50) NOT NULL,
  `PICcode` varchar(25) NOT NULL,
  `LomCode` varchar(25) NOT NULL,
  `RevConvertable` tinyint(3) NOT NULL,
  `orderinlegInBedrag` tinyint(3) NOT NULL,
  `VKM` tinyint(3) NOT NULL,
  `passiefFonds` tinyint(3) NOT NULL,
  `UBPcode` varchar(50) NOT NULL DEFAULT '',
  `UBScode` varchar(50) NOT NULL DEFAULT '',
  `JBcode` varchar(26) NOT NULL,
  `LYNXcode` varchar(26) NOT NULL,
  `BILcode` varchar(26) NOT NULL,
  `handelseenheid` double NOT NULL,
  `minOrdergrootte` double NOT NULL,
  `INGCode` varchar(23) NOT NULL,
  `IdentifierMS` varchar(50) NOT NULL,
  `KIDformulier` varchar(150) NOT NULL,
  `HSBCcode` varchar(50) NOT NULL,
  `KBCcode` varchar(26) NOT NULL,
  `binckValuta` varchar(4) NOT NULL,
  `binckBeurs` varchar(4) NOT NULL,
  `OblFloaterJaar` varchar(4) NOT NULL,
  `HHBcode` varchar(26) NOT NULL,
  `callabledatum` date NOT NULL,
  `UBSLcode` varchar(26) NOT NULL,
  `BNPBGLcode` varchar(26) NOT NULL,
  `JBLuxcode` varchar(26) NOT NULL,
  `CAWcode` varchar(26) NOT NULL,
  `optCode` varchar(20) NOT NULL,
  `KNOXcode` varchar(26) NOT NULL,
  `GScode` varchar(26) NOT NULL,
  `Sarasincode` varchar(26) NOT NULL,
  `Dierickscode` varchar(26) NOT NULL,
  `VPcode` varchar(26) NOT NULL,
  `JPMcode` varchar(30) NOT NULL,
  `SAXOcode` varchar(26) NOT NULL,
  `Quintetcode` varchar(26) NOT NULL,
  `SOCcode` varchar(26) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Fonds` (`Fonds`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=87976 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `FondsenBuitenBeheerfee`
--

DROP TABLE IF EXISTS `FondsenBuitenBeheerfee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FondsenBuitenBeheerfee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `Fonds` varchar(25) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `uitsluitenFee` tinyint(3) NOT NULL,
  `huisfonds` tinyint(3) NOT NULL,
  `layoutNr` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `VermogensbeheerderFonds` (`Vermogensbeheerder`,`Fonds`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `FondsenEMTdata`
--

DROP TABLE IF EXISTS `FondsenEMTdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FondsenEMTdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `Fonds` varchar(25) NOT NULL,
  `ClientTypeRetail` varchar(10) NOT NULL,
  `ClientTypeProfessional` varchar(10) NOT NULL,
  `ClientTypeEligibleCounterparty` varchar(10) NOT NULL,
  `ExpertiseBasic` varchar(10) NOT NULL,
  `ExpertiseInformed` varchar(10) NOT NULL,
  `ExpertiseAdvanced` varchar(10) NOT NULL,
  `CapitalLossNone` varchar(10) NOT NULL,
  `CapitalLossLimited` varchar(10) NOT NULL,
  `CapitalLossTotal` varchar(10) NOT NULL,
  `CapitalLossBeyondInvestment` varchar(10) NOT NULL,
  `ProfilePreservation` varchar(10) NOT NULL,
  `ProfileGrowth` varchar(10) NOT NULL,
  `ProfileIncome` varchar(10) NOT NULL,
  `ProfileHedging` varchar(10) NOT NULL,
  `ProfileOptionsLeverage` varchar(10) NOT NULL,
  `ProfileOther` varchar(10) NOT NULL,
  `ServiceExecOnly` varchar(12) NOT NULL,
  `ServiceExecOnlyAppTest` varchar(12) NOT NULL,
  `ServiceAdvice` varchar(12) NOT NULL,
  `ServiceManagement` varchar(12) NOT NULL,
  `RiskSRRI` int(11) NOT NULL,
  `RiskPRIIPSRI` int(11) NOT NULL,
  `ClientHorizon` varchar(10) NOT NULL,
  `ClientRiskTolerance` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Fonds` (`Fonds`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=9810 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `FondsenFundInformatie`
--

DROP TABLE IF EXISTS `FondsenFundInformatie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FondsenFundInformatie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fonds` varchar(25) NOT NULL,
  `datumVanaf` date NOT NULL,
  `MSFondswaarde` double NOT NULL,
  `MSAantalIntr` int(11) NOT NULL,
  `MSManFeeFonds` double NOT NULL,
  `YieldtoMaturity` double NOT NULL DEFAULT '0',
  `AverageCreditQuality` varchar(10) NOT NULL,
  `AverageEffDuration` double NOT NULL DEFAULT '0',
  `AverageEffMaturity` double NOT NULL DEFAULT '0',
  `AverageCoupon` double NOT NULL DEFAULT '0',
  `change_user` varchar(10) NOT NULL,
  `change_date` datetime NOT NULL,
  `add_user` varchar(10) NOT NULL,
  `add_date` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Fonds` (`fonds`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=69417 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `FondsenPerBedrijf`
--

DROP TABLE IF EXISTS `FondsenPerBedrijf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FondsenPerBedrijf` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Bedrijf` varchar(20) NOT NULL DEFAULT '',
  `Fonds` varchar(25) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Bedrijf` (`Bedrijf`) USING BTREE,
  KEY `Fonds` (`Fonds`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `FondsenPerVermogensbeheerder`
--

DROP TABLE IF EXISTS `FondsenPerVermogensbeheerder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FondsenPerVermogensbeheerder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(20) NOT NULL DEFAULT '',
  `Fonds` varchar(25) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Vermogensbeheerder` (`Vermogensbeheerder`) USING BTREE,
  KEY `Fonds` (`Fonds`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Fondskoersen`
--

DROP TABLE IF EXISTS `Fondskoersen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fondskoersen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Fonds` varchar(25) DEFAULT NULL,
  `Datum` datetime DEFAULT NULL,
  `Koers` double DEFAULT NULL,
  `import` int(11) NOT NULL DEFAULT '0',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `oorspKrsDt` date NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Fonds` (`Fonds`) USING BTREE,
  KEY `Datum` (`Datum`) USING BTREE,
  KEY `change_date` (`change_date`) USING BTREE,
  KEY `koersDatum` (`Fonds`,`Datum`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=40687883 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Gebruikers`
--

DROP TABLE IF EXISTS `Gebruikers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Gebruikers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Gebruiker` varchar(10) DEFAULT NULL,
  `Naam` varchar(60) NOT NULL,
  `Wachtwoord` varchar(12) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `CRMlevel` tinyint(4) DEFAULT NULL,
  `Beheerder` tinyint(4) NOT NULL DEFAULT '0',
  `beperkingOpheffen` tinyint(1) NOT NULL DEFAULT '0',
  `bgkleur` varchar(6) NOT NULL DEFAULT '',
  `CRMeigenRecords` tinyint(4) NOT NULL DEFAULT '0',
  `CRMxlsExport` tinyint(4) NOT NULL DEFAULT '0',
  `emailAdres` varchar(50) NOT NULL DEFAULT '',
  `mutatiesAanleveren` tinyint(4) NOT NULL DEFAULT '0',
  `verzendrechten` tinyint(4) NOT NULL DEFAULT '0',
  `bestandsvergoedingEdit` tinyint(3) NOT NULL DEFAULT '0',
  `emailHandtekening` mediumtext NOT NULL,
  `ordersNietAanmaken` tinyint(4) NOT NULL,
  `ordersNietVerwerken` tinyint(4) NOT NULL,
  `Accountmanager` varchar(15) NOT NULL DEFAULT '',
  `internePortefeuilles` tinyint(3) NOT NULL DEFAULT '0',
  `CRM_relatieSoorten` mediumtext NOT NULL,
  `titel` varchar(50) NOT NULL DEFAULT '',
  `overigePortefeuilles` tinyint(4) NOT NULL DEFAULT '0',
  `Gebruikersbeheer` tinyint(3) NOT NULL,
  `updateInfoAan` tinyint(4) NOT NULL,
  `fondsmutatiesAanleveren` tinyint(3) NOT NULL,
  `fondsaanvragenAanleveren` tinyint(3) NOT NULL,
  `portefeuilledetailsAanleveren` tinyint(3) NOT NULL,
  `participanten` tinyint(3) NOT NULL,
  `urenregistratie` varchar(4) NOT NULL,
  `mobiel` varchar(20) NOT NULL,
  `orderdesk` tinyint(3) NOT NULL,
  `orderbeheerder` tinyint(3) NOT NULL,
  `orderRechten` mediumtext NOT NULL,
  `crmImport` tinyint(4) NOT NULL,
  `voornamen` varchar(100) NOT NULL,
  `tussenvoegsel` varchar(15) NOT NULL,
  `achternaam` varchar(100) NOT NULL,
  `geboortedatum` date NOT NULL,
  `paspoortNummer` varchar(15) NOT NULL,
  `paspoortGeldigTot` date NOT NULL,
  `rechtenExterneQueries` tinyint(3) NOT NULL,
  `emailRechten` mediumtext NOT NULL,
  `secretTwoFactor` varchar(100) NOT NULL,
  `taal` varchar(5) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Gebruiker` (`Gebruiker`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=370 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `GebruikersLogin`
--

DROP TABLE IF EXISTS `GebruikersLogin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GebruikersLogin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `userID` int(11) NOT NULL,
  `userNaam` varchar(10) NOT NULL,
  `geldigTot` date NOT NULL,
  `vorigWW` varchar(200) NOT NULL,
  `huidigWW` varchar(200) NOT NULL,
  `laatsteLogin` datetime NOT NULL,
  `laatsteIP` varchar(200) NOT NULL,
  `laatsteSMScode` varchar(20) NOT NULL,
  `SMSstamp` datetime NOT NULL,
  `loginSucces` varchar(20) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `GeconsolideerdePortefeuilles`
--

DROP TABLE IF EXISTS `GeconsolideerdePortefeuilles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GeconsolideerdePortefeuilles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `VirtuelePortefeuille` varchar(24) NOT NULL,
  `Portefeuille1` varchar(24) NOT NULL,
  `Portefeuille2` varchar(24) NOT NULL,
  `Portefeuille3` varchar(24) NOT NULL,
  `Portefeuille4` varchar(24) NOT NULL,
  `Vermogensbeheerder` varchar(10) NOT NULL DEFAULT '',
  `Client` varchar(25) NOT NULL,
  `Naam` varchar(50) DEFAULT NULL,
  `Naam1` varchar(50) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `Portefeuille5` varchar(24) NOT NULL,
  `Portefeuille6` varchar(24) NOT NULL,
  `Portefeuille7` varchar(24) NOT NULL,
  `Portefeuille8` varchar(24) NOT NULL,
  `Portefeuille9` varchar(24) NOT NULL,
  `Portefeuille10` varchar(24) NOT NULL,
  `Risicoprofiel` varchar(50) NOT NULL DEFAULT '',
  `SoortOvereenkomst` varchar(30) NOT NULL,
  `SpecifiekeIndex` varchar(25) NOT NULL,
  `ModelPortefeuille` varchar(24) NOT NULL,
  `ZpMethode` tinyint(3) NOT NULL,
  `Einddatum` datetime NOT NULL,
  `Portefeuille11` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille12` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille13` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille14` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille15` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille16` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille17` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille18` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille19` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille20` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille21` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille22` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille23` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille24` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille25` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille26` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille27` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille28` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille29` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille30` varchar(24) NOT NULL DEFAULT '',
  `Startdatum` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Portefeuille31` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille32` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille33` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille34` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille35` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille36` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille37` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille38` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille39` varchar(24) NOT NULL DEFAULT '',
  `Portefeuille40` varchar(24) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `VirtuelePortefeuille` (`VirtuelePortefeuille`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1007 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `GrootboekPerVermogensbeheerder`
--

DROP TABLE IF EXISTS `GrootboekPerVermogensbeheerder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GrootboekPerVermogensbeheerder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `StartDatum` datetime DEFAULT '0000-00-00 00:00:00',
  `Grootboekrekening` varchar(5) DEFAULT NULL,
  `Omschrijving` varchar(50) DEFAULT NULL,
  `FondsAanVerkoop` tinyint(4) DEFAULT NULL,
  `Storting` tinyint(4) DEFAULT NULL,
  `Kosten` tinyint(4) DEFAULT NULL,
  `Opbrengst` tinyint(4) DEFAULT NULL,
  `Beginboeking` tinyint(4) DEFAULT NULL,
  `Kruispost` tinyint(4) DEFAULT NULL,
  `Afdrukvolgorde` char(3) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `Onttrekking` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Grootboekrekening` (`Grootboekrekening`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Grootboekrekeningen`
--

DROP TABLE IF EXISTS `Grootboekrekeningen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Grootboekrekeningen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Grootboekrekening` varchar(5) DEFAULT NULL,
  `Omschrijving` varchar(50) DEFAULT NULL,
  `FondsAanVerkoop` tinyint(4) DEFAULT NULL,
  `Storting` tinyint(4) DEFAULT NULL,
  `Kosten` tinyint(4) DEFAULT NULL,
  `Opbrengst` tinyint(4) DEFAULT NULL,
  `Beginboeking` tinyint(4) DEFAULT NULL,
  `Kruispost` tinyint(4) DEFAULT NULL,
  `Afdrukvolgorde` char(3) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `FondsGebruik` tinyint(4) NOT NULL DEFAULT '0',
  `Onttrekking` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Grootboekrekening` (`Grootboekrekening`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HistorischeDagelijkseWaarden`
--

DROP TABLE IF EXISTS `HistorischeDagelijkseWaarden`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HistorischeDagelijkseWaarden` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `portefeuille` varchar(24) NOT NULL,
  `datum` date DEFAULT NULL,
  `eindvermogen` double NOT NULL DEFAULT '0',
  `liquiditeiten` double NOT NULL DEFAULT '0',
  `huisfondsen` mediumtext NOT NULL,
  `grondslag` double NOT NULL DEFAULT '0',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `portefeuille` (`portefeuille`) USING BTREE,
  KEY `datum` (`datum`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HistorischePerformance`
--

DROP TABLE IF EXISTS `HistorischePerformance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HistorischePerformance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Portefeuille` varchar(24) NOT NULL,
  `Datum` datetime DEFAULT NULL,
  `Waarde` double DEFAULT NULL,
  `Performance` double DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HistorischePortefeuilleIndex`
--

DROP TABLE IF EXISTS `HistorischePortefeuilleIndex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HistorischePortefeuilleIndex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Portefeuille` varchar(24) NOT NULL,
  `Datum` date DEFAULT NULL,
  `IndexWaarde` decimal(7,4) DEFAULT NULL,
  `PortefeuilleWaarde` double DEFAULT NULL,
  `Stortingen` double DEFAULT NULL,
  `Onttrekkingen` double DEFAULT NULL,
  `Opbrengsten` double DEFAULT NULL,
  `Kosten` double DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `Categorie` varchar(15) NOT NULL DEFAULT '',
  `PortefeuilleBeginWaarde` double DEFAULT NULL,
  `gerealiseerd` double NOT NULL,
  `ongerealiseerd` double NOT NULL,
  `rente` double NOT NULL,
  `extra` text NOT NULL,
  `gemiddelde` double NOT NULL,
  `periode` varchar(2) NOT NULL DEFAULT 'm',
  `scenarioKansOpDoel` double NOT NULL,
  `scenarioVerwachtVermogen` double NOT NULL,
  `scenarioProfiel` varchar(50) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Portefeuille` (`Portefeuille`) USING BTREE,
  KEY `Datum` (`Datum`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=775674 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HistorischeScenarios`
--

DROP TABLE IF EXISTS `HistorischeScenarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HistorischeScenarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `portefeuille` varchar(24) NOT NULL,
  `datum` date DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `scenarioKansOpDoel` double NOT NULL,
  `scenarioVerwachtVermogen` double NOT NULL,
  `scenarioProfiel` varchar(50) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `portefeuille` (`portefeuille`) USING BTREE,
  KEY `datum` (`datum`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HistorischeSpecifiekeIndex`
--

DROP TABLE IF EXISTS `HistorischeSpecifiekeIndex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HistorischeSpecifiekeIndex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `portefeuille` varchar(24) NOT NULL,
  `specifiekeIndex` varchar(25) DEFAULT NULL,
  `tot` date DEFAULT NULL,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `portefeuille` (`portefeuille`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ISOLanden`
--

DROP TABLE IF EXISTS `ISOLanden`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ISOLanden` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `landCode` varchar(3) NOT NULL DEFAULT '',
  `landCodeKort` varchar(2) NOT NULL DEFAULT '',
  `landISOnr` varchar(3) NOT NULL DEFAULT '',
  `omschrijvingNL` varchar(100) NOT NULL DEFAULT '',
  `omschrijvingEN` varchar(100) NOT NULL DEFAULT '',
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `landCode` (`landCode`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=250 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `IndexPerAttributieCategorie`
--

DROP TABLE IF EXISTS `IndexPerAttributieCategorie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IndexPerAttributieCategorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `AttributieCategorie` varchar(15) DEFAULT NULL,
  `Fonds` varchar(25) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `IndexPerBeleggingscategorie`
--

DROP TABLE IF EXISTS `IndexPerBeleggingscategorie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IndexPerBeleggingscategorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `Beleggingscategorie` varchar(15) DEFAULT NULL,
  `Fonds` varchar(25) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `vanaf` date NOT NULL DEFAULT '0000-00-00',
  `Portefeuille` varchar(24) NOT NULL,
  `Categoriesoort` varchar(50) NOT NULL,
  `Categorie` varchar(30) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Vermogensbeheerder` (`Vermogensbeheerder`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Indices`
--

DROP TABLE IF EXISTS `Indices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Indices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `Beursindex` varchar(25) DEFAULT NULL,
  `Afdrukvolgorde` tinyint(4) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `grafiekKleur` text NOT NULL,
  `specialeIndex` tinyint(4) NOT NULL DEFAULT '0',
  `toelichting` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Vermogensbeheerder` (`Vermogensbeheerder`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=39912 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `KeuzePerVermogensbeheerder`
--

DROP TABLE IF EXISTS `KeuzePerVermogensbeheerder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `KeuzePerVermogensbeheerder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vermogensbeheerder` varchar(10) DEFAULT NULL,
  `categorie` varchar(50) DEFAULT NULL,
  `waarde` varchar(50) NOT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `Afdrukvolgorde` tinyint(4) NOT NULL DEFAULT '0',
  `norm` double NOT NULL,
  `categorieIXP` varchar(30) NOT NULL,
  `AfmKostensoort` varchar(30) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `categorie` (`categorie`) USING BTREE,
  KEY `vermogensbeheerder` (`vermogensbeheerder`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3376 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `KortingenPerDepotbank`
--

DROP TABLE IF EXISTS `KortingenPerDepotbank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `KortingenPerDepotbank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `Depotbank` varchar(16) DEFAULT NULL,
  `Grootboekrekening` varchar(5) DEFAULT NULL,
  `Korting` double DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MONITOR_bedrijfDepot`
--

DROP TABLE IF EXISTS `MONITOR_bedrijfDepot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MONITOR_bedrijfDepot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `bedrijf` varchar(10) NOT NULL,
  `depotbank` varchar(50) NOT NULL,
  `bestanden` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MONITOR_importMatrix`
--

DROP TABLE IF EXISTS `MONITOR_importMatrix`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MONITOR_importMatrix` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `bedrijf` varchar(10) NOT NULL,
  `depotbank` varchar(20) NOT NULL,
  `datum` datetime NOT NULL,
  `verwerkt` tinyint(4) NOT NULL,
  `door` varchar(10) NOT NULL,
  `bestanden` tinyint(4) NOT NULL,
  `klaargezet` tinyint(4) NOT NULL,
  `autoPortaalVulling` tinyint(4) NOT NULL,
  `verwerkPrio` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ModelPortefeuilleFixed`
--

DROP TABLE IF EXISTS `ModelPortefeuilleFixed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ModelPortefeuilleFixed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Portefeuille` varchar(24) NOT NULL,
  `Fonds` varchar(25) NOT NULL DEFAULT '',
  `Percentage` double NOT NULL DEFAULT '0',
  `Datum` date NOT NULL DEFAULT '0000-00-00',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ModelPortefeuilles`
--

DROP TABLE IF EXISTS `ModelPortefeuilles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ModelPortefeuilles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Portefeuille` varchar(24) NOT NULL,
  `Omschrijving` varchar(50) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `Fixed` tinyint(4) NOT NULL DEFAULT '0',
  `FixedDatum` date NOT NULL DEFAULT '0000-00-00',
  `Beleggingscategorie` varchar(15) NOT NULL DEFAULT '',
  `AfdrukNiveau` varchar(20) NOT NULL DEFAULT '',
  `VerwerkingsmethodeDiv` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Portefeuille` (`Portefeuille`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1489 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ModelPortefeuillesPerPortefeuille`
--

DROP TABLE IF EXISTS `ModelPortefeuillesPerPortefeuille`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ModelPortefeuillesPerPortefeuille` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Portefeuille` varchar(24) NOT NULL,
  `ModelPortefeuille` varchar(24) NOT NULL,
  `Percentage` double NOT NULL DEFAULT '0',
  `Vanaf` date NOT NULL DEFAULT '0000-00-00',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Portefeuille` (`Portefeuille`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `NormPerRisicoprofiel`
--

DROP TABLE IF EXISTS `NormPerRisicoprofiel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `NormPerRisicoprofiel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `Risicoklasse` varchar(50) DEFAULT NULL,
  `Beleggingscategorie` varchar(15) DEFAULT NULL,
  `norm` double NOT NULL DEFAULT '0',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `NormwegingPerBeleggingscategorie`
--

DROP TABLE IF EXISTS `NormwegingPerBeleggingscategorie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `NormwegingPerBeleggingscategorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Portefeuille` varchar(24) NOT NULL,
  `Beleggingscategorie` varchar(15) DEFAULT NULL,
  `Normweging` double DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `DatumVanaf` date NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `beleggingscategorie` (`Beleggingscategorie`) USING BTREE,
  KEY `portefeuille` (`Portefeuille`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `OrderRegels`
--

DROP TABLE IF EXISTS `OrderRegels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrderRegels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderid` varchar(16) NOT NULL DEFAULT '',
  `positie` int(3) unsigned NOT NULL DEFAULT '0',
  `portefeuille` varchar(24) NOT NULL,
  `rekeningnr` varchar(25) NOT NULL,
  `valuta` varchar(6) NOT NULL DEFAULT '',
  `aantal` double(12,4) NOT NULL DEFAULT '0.0000',
  `client` varchar(60) NOT NULL DEFAULT '',
  `status` varchar(60) NOT NULL DEFAULT '',
  `controle_regels` text,
  `controle` tinyint(4) DEFAULT NULL,
  `memo` varchar(100) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `handelsDag` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `kosten` double NOT NULL DEFAULT '0',
  `handelsTijd` time NOT NULL DEFAULT '00:00:00',
  `beurs` varchar(4) NOT NULL DEFAULT '',
  `memoHandel` varchar(200) NOT NULL DEFAULT '',
  `valutakoers` double NOT NULL DEFAULT '0',
  `fondsKoers` double NOT NULL DEFAULT '0',
  `opgelopenRente` double NOT NULL DEFAULT '0',
  `brutoBedrag` double NOT NULL DEFAULT '0',
  `nettoBedrag` double NOT NULL DEFAULT '0',
  `definitief` tinyint(4) NOT NULL DEFAULT '0',
  `interneNummer` varchar(25) NOT NULL DEFAULT '',
  `aanvullendeInfo` varchar(255) NOT NULL DEFAULT '',
  `transactieAantal` double(12,4) NOT NULL DEFAULT '0.0000',
  `brutoBedragValuta` double NOT NULL DEFAULT '0',
  `CheckResult` text NOT NULL,
  `brokerkosten` double NOT NULL DEFAULT '0',
  `printDate` datetime NOT NULL,
  `PSET` varchar(12) NOT NULL,
  `PSAF` varchar(12) NOT NULL,
  `USDSettlement` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `orderid` (`orderid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `OrderRegelsV2`
--

DROP TABLE IF EXISTS `OrderRegelsV2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrderRegelsV2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderid` int(11) NOT NULL DEFAULT '0',
  `positie` int(11) unsigned NOT NULL DEFAULT '0',
  `portefeuille` varchar(24) NOT NULL,
  `rekening` varchar(25) NOT NULL,
  `aantal` double NOT NULL DEFAULT '0',
  `bedrag` double NOT NULL,
  `client` varchar(60) NOT NULL DEFAULT '',
  `orderregelStatus` tinyint(3) NOT NULL DEFAULT '0',
  `controleRegels` text,
  `controleStatus` tinyint(4) DEFAULT NULL,
  `kosten` double NOT NULL,
  `brokerkosten` double NOT NULL,
  `opgelopenRente` double NOT NULL,
  `brutoBedrag` double NOT NULL,
  `nettoBedrag` double NOT NULL,
  `PSET` varchar(12) NOT NULL,
  `PSAF` varchar(12) NOT NULL,
  `orderReden` varchar(100) NOT NULL DEFAULT '',
  `effRekeningTegenpartij` varchar(24) NOT NULL,
  `BIC_tegenpartij` varchar(24) NOT NULL,
  `regelNotaValutakoers` double NOT NULL,
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `notaDefinitief` tinyint(3) NOT NULL,
  `printDate` date NOT NULL,
  `mailBevestigingVerzonden` datetime NOT NULL,
  `mailBevestigingData` mediumtext NOT NULL,
  `externeBatchId` varchar(25) NOT NULL,
  `orderbedrag` double(16,2) NOT NULL,
  `kopieOrderId` int(11) NOT NULL,
  `orderaantal` double(16,2) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `orderid` (`orderid`) USING BTREE,
  KEY `portefeuille` (`portefeuille`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `OrderUitvoering`
--

DROP TABLE IF EXISTS `OrderUitvoering`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrderUitvoering` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderid` varchar(16) NOT NULL DEFAULT '',
  `uitvoeringsAantal` double NOT NULL DEFAULT '0',
  `uitvoeringsDatum` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `uitvoeringsPrijs` double NOT NULL DEFAULT '0',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `nettokoers` double NOT NULL DEFAULT '0',
  `opgelopenrente` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `orderid` (`orderid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `OrderUitvoeringV2`
--

DROP TABLE IF EXISTS `OrderUitvoeringV2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrderUitvoeringV2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderid` int(11) NOT NULL DEFAULT '0',
  `uitvoeringsAantal` double NOT NULL DEFAULT '0',
  `uitvoeringsDatum` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `uitvoeringsPrijs` double NOT NULL DEFAULT '0',
  `exec_id` varchar(30) NOT NULL,
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `nettokoers` double NOT NULL DEFAULT '0',
  `opgelopenrente` double NOT NULL DEFAULT '0',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `brokerkostenTotaal` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `orderid` (`orderid`) USING BTREE,
  KEY `exec_id` (`exec_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Orderredenen`
--

DROP TABLE IF EXISTS `Orderredenen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Orderredenen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderreden` varchar(30) NOT NULL DEFAULT '',
  `omschrijving` varchar(100) NOT NULL DEFAULT '',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Orders`
--

DROP TABLE IF EXISTS `Orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Ordernummer',
  `vermogensBeheerder` varchar(5) NOT NULL DEFAULT '',
  `orderid` varchar(16) NOT NULL DEFAULT '',
  `aantal` double NOT NULL DEFAULT '0',
  `fondsCode` varchar(26) NOT NULL DEFAULT '',
  `fonds` varchar(50) NOT NULL DEFAULT '',
  `transactieType` varchar(4) NOT NULL DEFAULT '' COMMENT 'L-limiet B-bestens SL-Stoploss SLIM-StopLimiet',
  `transactieSoort` char(2) NOT NULL DEFAULT '' COMMENT 'A-aankoop B-verkoop',
  `tijdsLimiet` date NOT NULL DEFAULT '0000-00-00',
  `tijdsSoort` char(3) NOT NULL DEFAULT '',
  `koersLimiet` double(12,5) NOT NULL DEFAULT '0.00000',
  `status` text NOT NULL COMMENT 'Serialied overzicht statussen',
  `laatsteStatus` varchar(15) NOT NULL DEFAULT '' COMMENT 'laatst bereikte status',
  `memo` text NOT NULL,
  `controle_datum` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `uitvoeringsPrijs` double(12,5) NOT NULL DEFAULT '0.00000',
  `uitvoeringsDatum` date NOT NULL DEFAULT '0000-00-00',
  `Depotbank` varchar(10) NOT NULL DEFAULT '',
  `fondsOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `printDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `batchId` int(11) NOT NULL DEFAULT '0',
  `OrderSoort` char(1) NOT NULL DEFAULT '',
  `giraleOrder` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `orderid` (`orderid`) USING BTREE,
  KEY `fonds` (`fonds`) USING BTREE,
  KEY `laatsteStatus` (`laatsteStatus`) USING BTREE,
  KEY `batchId` (`batchId`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `OrdersV2`
--

DROP TABLE IF EXISTS `OrdersV2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrdersV2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fonds` varchar(50) NOT NULL DEFAULT '',
  `fondseenheid` double NOT NULL,
  `fondsValuta` varchar(4) NOT NULL,
  `fondsBankcode` varchar(50) NOT NULL,
  `optieSymbool` varchar(5) NOT NULL,
  `optieType` varchar(1) NOT NULL,
  `optieUitoefenprijs` double NOT NULL,
  `optieExpDatum` varchar(6) NOT NULL,
  `beurs` varchar(4) NOT NULL,
  `ISINCode` varchar(26) NOT NULL DEFAULT '',
  `fondsOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `transactieType` varchar(4) NOT NULL DEFAULT '',
  `transactieSoort` char(2) NOT NULL DEFAULT '',
  `tijdsLimiet` date NOT NULL DEFAULT '0000-00-00',
  `tijdsSoort` char(3) NOT NULL DEFAULT '',
  `koersLimiet` double(12,5) NOT NULL DEFAULT '0.00000',
  `orderStatus` int(11) NOT NULL DEFAULT '0',
  `orderSubStatus` varchar(2) NOT NULL,
  `memo` text NOT NULL,
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `depotbank` varchar(10) NOT NULL DEFAULT '',
  `batchId` int(11) NOT NULL DEFAULT '0',
  `orderSoort` char(1) NOT NULL DEFAULT '',
  `giraleOrder` tinyint(3) NOT NULL,
  `fixOrder` tinyint(3) NOT NULL,
  `fixVerzenddatum` datetime NOT NULL,
  `fixAnnuleerdatum` datetime NOT NULL,
  `fondssoort` varchar(8) NOT NULL,
  `settlementdatum` date NOT NULL,
  `notaValutakoers` double NOT NULL,
  `careOrder` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `fonds` (`fonds`) USING BTREE,
  KEY `orderStatus` (`orderStatus`) USING BTREE,
  KEY `batchId` (`batchId`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PSAFperFonds`
--

DROP TABLE IF EXISTS `PSAFperFonds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PSAFperFonds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vermogensbeheerder` varchar(10) NOT NULL DEFAULT '',
  `fonds` varchar(25) NOT NULL DEFAULT '',
  `code` varchar(12) NOT NULL DEFAULT '',
  `type` varchar(4) NOT NULL DEFAULT '0',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `fonds` (`fonds`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PortefeuilleHistorischeParameters`
--

DROP TABLE IF EXISTS `PortefeuilleHistorischeParameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PortefeuilleHistorischeParameters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `portefeuille` varchar(26) NOT NULL DEFAULT '',
  `tot` date DEFAULT '0000-00-00',
  `veld` varchar(50) NOT NULL DEFAULT '',
  `waarde` varchar(50) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `portefeuille` (`portefeuille`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Portefeuilles`
--

DROP TABLE IF EXISTS `Portefeuilles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Portefeuilles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Portefeuille` varchar(24) NOT NULL,
  `PortefeuilleVoorzet` varchar(8) DEFAULT NULL,
  `Vermogensbeheerder` varchar(10) NOT NULL DEFAULT '',
  `Client` varchar(25) NOT NULL,
  `Depotbank` varchar(10) NOT NULL DEFAULT '',
  `Startdatum` datetime DEFAULT NULL,
  `Einddatum` datetime DEFAULT NULL,
  `ClientVermogensbeheerder` varchar(20) NOT NULL,
  `AEXVergelijking` tinyint(4) DEFAULT NULL,
  `Accountmanager` varchar(15) NOT NULL DEFAULT '',
  `Risicoprofiel` varchar(5) NOT NULL DEFAULT '',
  `SoortOvereenkomst` varchar(30) NOT NULL DEFAULT '',
  `HistorischeInfo` tinyint(4) DEFAULT NULL,
  `AantalAfdrukken` tinyint(4) DEFAULT NULL,
  `Risicoklasse` varchar(50) DEFAULT NULL,
  `Taal` tinyint(4) DEFAULT NULL,
  `BeheerfeeBasisberekening` tinyint(4) NOT NULL DEFAULT '0',
  `BeheerfeeMethode` tinyint(4) DEFAULT NULL,
  `BeheerfeeKortingspercentage` double DEFAULT NULL,
  `BeheerfeePercentageVermogen` double DEFAULT NULL,
  `BeheerfeeBedrag` double DEFAULT NULL,
  `BeheerfeePerformancePercentage` double DEFAULT NULL,
  `BeheerfeeTeruggaveHuisfondsenPercentage` double DEFAULT NULL,
  `BeheerfeeRemisiervergoedingsPercentage` double DEFAULT NULL,
  `BeheerfeeToevoegenAanPortefeuille` varchar(24) NOT NULL,
  `BeheerfeeAantalFacturen` tinyint(4) DEFAULT NULL,
  `BeheerfeeStaffel1` double DEFAULT NULL,
  `BeheerfeeStaffel2` double DEFAULT NULL,
  `BeheerfeeStaffel3` double DEFAULT NULL,
  `BeheerfeeStaffel4` double DEFAULT NULL,
  `BeheerfeeStaffel5` double DEFAULT NULL,
  `BeheerfeeStaffelPercentage1` double DEFAULT NULL,
  `BeheerfeeStaffelPercentage2` double DEFAULT NULL,
  `BeheerfeeStaffelPercentage3` double DEFAULT NULL,
  `BeheerfeeStaffelPercentage4` double DEFAULT NULL,
  `BeheerfeeStaffelPercentage5` double DEFAULT NULL,
  `BeheerfeeBTW` decimal(8,1) NOT NULL DEFAULT '19.0',
  `BeheerfeeMinJaarBedrag` double NOT NULL DEFAULT '0',
  `BeheerfeePerformanceDrempelPercentage` double NOT NULL DEFAULT '0',
  `BeheerfeePerformanceDrempelBedrag` double NOT NULL DEFAULT '0',
  `BeheerfeeSchijvenTarief` tinyint(4) NOT NULL DEFAULT '0',
  `BeheerfeePerformancefeeJaarlijks` tinyint(4) NOT NULL DEFAULT '0',
  `BeheerfeeFacturatieVanaf` date NOT NULL DEFAULT '0000-00-00',
  `BeheerfeeFacturatieVooraf` tinyint(4) NOT NULL DEFAULT '0',
  `OptieToestaan` tinyint(4) NOT NULL DEFAULT '0',
  `WerkelijkeDagen` tinyint(4) NOT NULL DEFAULT '0',
  `valutaUitsluiten` tinyint(4) NOT NULL DEFAULT '0',
  `Remisier` varchar(15) NOT NULL DEFAULT '',
  `AFMprofiel` varchar(15) NOT NULL DEFAULT '',
  `ModelPortefeuille` varchar(24) NOT NULL,
  `RapportageValuta` varchar(4) DEFAULT NULL,
  `BeheerfeeAdministratieVergoeding` double DEFAULT NULL,
  `SpecifiekeIndex` varchar(25) DEFAULT NULL,
  `InternDepot` tinyint(1) NOT NULL DEFAULT '0',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `Aanbrenger` varchar(200) NOT NULL DEFAULT '',
  `Memo` text NOT NULL,
  `tweedeAanspreekpunt` varchar(15) NOT NULL DEFAULT '',
  `maandAfdrukken` tinyint(4) NOT NULL DEFAULT '0',
  `kwartaalAfdrukken` tinyint(4) NOT NULL DEFAULT '0',
  `beperktToegankelijk` tinyint(1) NOT NULL DEFAULT '0',
  `CrmPortefeuilleInformatie` tinyint(1) NOT NULL DEFAULT '0',
  `Vastetegenrekening` varchar(26) NOT NULL DEFAULT '',
  `BetalingsinfoMee` tinyint(1) NOT NULL DEFAULT '0',
  `FactuurMemo` text NOT NULL,
  `BeheerfeeBedragBuitenFee` double NOT NULL DEFAULT '0',
  `BeheerfeeLiquiditeitenViaModel` tinyint(4) NOT NULL DEFAULT '0',
  `BestandsvergoedingUitkeren` tinyint(4) NOT NULL DEFAULT '0',
  `feeToevoegMethode` tinyint(4) NOT NULL DEFAULT '0',
  `startdatumMeerjarenrendement` date NOT NULL DEFAULT '0000-00-00',
  `kleurcode` varchar(255) NOT NULL DEFAULT '',
  `BeheerfeeBedragVast` tinyint(3) NOT NULL DEFAULT '0',
  `BeheerfeeHuisfondsenOvernemen` tinyint(3) NOT NULL DEFAULT '0',
  `BeheerfeeLiquiditeitenAnderPercentage` tinyint(3) NOT NULL DEFAULT '0',
  `BeheerfeeLiquiditeitenPercentage` double NOT NULL DEFAULT '0',
  `BeheerfeeTransactiefeeKosten` double NOT NULL DEFAULT '0',
  `TijdelijkUitsluitenZp` tinyint(4) NOT NULL DEFAULT '0',
  `ZpMethode` tinyint(4) NOT NULL DEFAULT '0',
  `afrekenvalutaKosten` varchar(4) NOT NULL,
  `consolidatie` tinyint(3) NOT NULL,
  `PortefeuilleDepotbank` varchar(24) NOT NULL,
  `BeheerfeeLiquiditeitenAfroomPercentage` double NOT NULL,
  `BeheerfeeHighwatermarkStart` double NOT NULL,
  `BeheerfeeHighwatermarkOnder` double NOT NULL,
  `BeheerfeePerformanceViaHighwatermark` tinyint(4) NOT NULL,
  `BeheerfeeAdminVgConUitsluiten` tinyint(3) NOT NULL,
  `BeheerfeeBedragBuitenBTW` double NOT NULL,
  `afwijkendeOmzetsoort` varchar(4) NOT NULL,
  `spreadKosten` double NOT NULL,
  `overgangsdepot` tinyint(3) NOT NULL,
  `consolidatieVasteStart` tinyint(3) NOT NULL,
  `consolidatieVasteEind` tinyint(3) NOT NULL,
  `selectieveld1` varchar(40) NOT NULL,
  `selectieveld2` varchar(40) NOT NULL,
  `BeheerfeeAdminVergoedingJaarlijks` tinyint(3) NOT NULL,
  `AfwStartdatumRend` date NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Portefeuille` (`Portefeuille`) USING BTREE,
  KEY `Vermogensbeheerder` (`Vermogensbeheerder`) USING BTREE,
  KEY `Client` (`Client`) USING BTREE,
  KEY `Accountmanager` (`Accountmanager`) USING BTREE,
  KEY `tweedeAanspreekpunt` (`tweedeAanspreekpunt`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=66116 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PortefeuillesGeconsolideerd`
--

DROP TABLE IF EXISTS `PortefeuillesGeconsolideerd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PortefeuillesGeconsolideerd` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `VirtuelePortefeuille` varchar(24) NOT NULL,
  `Portefeuille` varchar(24) NOT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `VirtuelePortefeuille` (`VirtuelePortefeuille`) USING BTREE,
  KEY `Portefeuille` (`Portefeuille`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PositieLijst`
--

DROP TABLE IF EXISTS `PositieLijst`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PositieLijst` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `portefeuille` varchar(24) NOT NULL,
  `depotbank` varchar(20) NOT NULL DEFAULT '',
  `vermogensbeheerder` varchar(20) NOT NULL DEFAULT '',
  `datum` date NOT NULL DEFAULT '0000-00-00',
  `fondsCode` varchar(25) NOT NULL DEFAULT '',
  `fondsCodeNumeriek` varchar(25) NOT NULL DEFAULT '',
  `fondsSoort` varchar(50) NOT NULL DEFAULT '',
  `fondsOmschrijving` varchar(100) NOT NULL DEFAULT '',
  `fondsValuta` varchar(10) NOT NULL DEFAULT '',
  `ISIN` varchar(20) NOT NULL DEFAULT '',
  `aantal` double NOT NULL DEFAULT '0',
  `optieSoort` varchar(10) NOT NULL DEFAULT '',
  `soort` varchar(15) NOT NULL DEFAULT '',
  `waardeInEUR` double NOT NULL DEFAULT '0',
  `waardeInValuta` double NOT NULL DEFAULT '0',
  `kostprijs` double NOT NULL DEFAULT '0',
  `koers` double NOT NULL DEFAULT '0',
  `valutakoers` double NOT NULL DEFAULT '0',
  `batchid` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Querydata`
--

DROP TABLE IF EXISTS `Querydata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Querydata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Naam` varchar(35) NOT NULL DEFAULT '',
  `Omschrijving` text NOT NULL,
  `Gebruiker` varchar(10) NOT NULL DEFAULT '',
  `Vermogensbeheerder` varchar(10) NOT NULL DEFAULT '',
  `Type` varchar(15) NOT NULL DEFAULT '',
  `Data` text NOT NULL,
  `add_user` varchar(15) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(15) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RapportBuilderQuery`
--

DROP TABLE IF EXISTS `RapportBuilderQuery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RapportBuilderQuery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Naam` varchar(35) NOT NULL DEFAULT '',
  `Omschrijving` text NOT NULL,
  `Gebruiker` varchar(10) NOT NULL DEFAULT '',
  `Vermogensbeheerder` varchar(10) NOT NULL DEFAULT '',
  `Type` varchar(15) NOT NULL DEFAULT '',
  `Data` text NOT NULL,
  `add_user` varchar(15) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(15) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RapportBuilderQueryAirs`
--

DROP TABLE IF EXISTS `RapportBuilderQueryAirs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RapportBuilderQueryAirs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Naam` varchar(35) NOT NULL DEFAULT '',
  `Omschrijving` text NOT NULL,
  `Gebruiker` varchar(10) NOT NULL DEFAULT '',
  `Vermogensbeheerder` varchar(10) NOT NULL DEFAULT '',
  `Type` varchar(15) NOT NULL DEFAULT '',
  `Data` text NOT NULL,
  `add_user` varchar(15) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(15) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RapportXlsQuery`
--

DROP TABLE IF EXISTS `RapportXlsQuery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RapportXlsQuery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Naam` varchar(35) NOT NULL DEFAULT '',
  `Omschrijving` text NOT NULL,
  `Gebruiker` varchar(10) NOT NULL DEFAULT '',
  `Vermogensbeheerder` varchar(10) NOT NULL DEFAULT '',
  `Type` varchar(15) NOT NULL DEFAULT '',
  `Data` text NOT NULL,
  `add_user` varchar(15) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(15) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Rating`
--

DROP TABLE IF EXISTS `Rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Rating` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rating` varchar(26) DEFAULT NULL,
  `omschrijving` varchar(60) DEFAULT NULL,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `Afdrukvolgorde` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ReferentieportefeuillePerBeleggingscategorie`
--

DROP TABLE IF EXISTS `ReferentieportefeuillePerBeleggingscategorie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ReferentieportefeuillePerBeleggingscategorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `Referentieportefeuille` varchar(24) DEFAULT NULL,
  `vanaf` date NOT NULL DEFAULT '0000-00-00',
  `Portefeuille` varchar(24) NOT NULL,
  `Categoriesoort` varchar(50) NOT NULL,
  `Categorie` varchar(30) NOT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Vermogensbeheerder` (`Vermogensbeheerder`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Regios`
--

DROP TABLE IF EXISTS `Regios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Regios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Regio` varchar(15) DEFAULT NULL,
  `Omschrijving` varchar(50) DEFAULT NULL,
  `Afdrukvolgorde` tinyint(4) NOT NULL DEFAULT '0',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Regio` (`Regio`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=193 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Rekeningafschriften`
--

DROP TABLE IF EXISTS `Rekeningafschriften`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Rekeningafschriften` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Rekening` varchar(25) NOT NULL,
  `Afschriftnummer` double DEFAULT NULL,
  `Datum` datetime DEFAULT NULL,
  `Saldo` double DEFAULT NULL,
  `NieuwSaldo` double DEFAULT NULL,
  `Verwerkt` tinyint(4) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Rekening` (`Rekening`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=8979227 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Rekeningen`
--

DROP TABLE IF EXISTS `Rekeningen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Rekeningen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Rekening` varchar(25) NOT NULL,
  `Portefeuille` varchar(24) NOT NULL,
  `Valuta` varchar(4) NOT NULL,
  `Memoriaal` tinyint(4) NOT NULL,
  `Tenaamstelling` varchar(50) NOT NULL,
  `Termijnrekening` tinyint(4) NOT NULL,
  `Deposito` tinyint(4) NOT NULL DEFAULT '0',
  `RenteBerekenen` tinyint(4) NOT NULL DEFAULT '0',
  `Rente30_360` tinyint(4) DEFAULT '0',
  `add_date` datetime NOT NULL,
  `add_user` varchar(10) NOT NULL,
  `change_date` datetime NOT NULL,
  `change_user` varchar(10) NOT NULL,
  `Beleggingscategorie` varchar(15) NOT NULL DEFAULT '',
  `Inleg` double NOT NULL DEFAULT '0',
  `AttributieCategorie` varchar(15) NOT NULL DEFAULT '',
  `Inactief` tinyint(4) NOT NULL DEFAULT '0',
  `Depotbank` varchar(10) NOT NULL DEFAULT '',
  `typeRekening` varchar(25) NOT NULL DEFAULT '',
  `consolidatie` tinyint(3) NOT NULL,
  `RekeningDepotbank` varchar(25) NOT NULL,
  `IBANnr` varchar(30) NOT NULL,
  `Afdrukvolgorde` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Portefeuille` (`Portefeuille`) USING BTREE,
  KEY `Rekening` (`Rekening`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=295307 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RekeningenDuplicaat`
--

DROP TABLE IF EXISTS `RekeningenDuplicaat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RekeningenDuplicaat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Rekening` varchar(25) NOT NULL,
  `RekeningDuplicaat` varchar(25) NOT NULL,
  `Memo` text NOT NULL,
  `actief` tinyint(4) NOT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RekeningenHistorischeParameters`
--

DROP TABLE IF EXISTS `RekeningenHistorischeParameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RekeningenHistorischeParameters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Rekening` varchar(25) NOT NULL,
  `GebruikTot` date DEFAULT '0000-00-00',
  `Depotbank` varchar(10) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL,
  `add_user` varchar(10) NOT NULL,
  `change_date` datetime NOT NULL,
  `change_user` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Rekening` (`Rekening`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Rekeningmutaties`
--

DROP TABLE IF EXISTS `Rekeningmutaties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Rekeningmutaties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Rekening` varchar(25) NOT NULL,
  `Afschriftnummer` double DEFAULT NULL,
  `Volgnummer` double DEFAULT NULL,
  `Omschrijving` varchar(50) DEFAULT NULL,
  `Boekdatum` datetime DEFAULT NULL,
  `Grootboekrekening` varchar(5) DEFAULT NULL,
  `Valuta` varchar(4) DEFAULT NULL,
  `Valutakoers` double DEFAULT NULL,
  `Fonds` varchar(25) DEFAULT NULL,
  `Aantal` double NOT NULL DEFAULT '0',
  `Fondskoers` double DEFAULT NULL,
  `Debet` double NOT NULL DEFAULT '0',
  `Credit` double NOT NULL DEFAULT '0',
  `Bedrag` double NOT NULL DEFAULT '0',
  `Transactietype` varchar(5) DEFAULT NULL,
  `Verwerkt` tinyint(4) DEFAULT NULL,
  `Memoriaalboeking` tinyint(4) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `Bewaarder` varchar(20) NOT NULL DEFAULT '',
  `bankTransactieId` varchar(25) NOT NULL,
  `settlementDatum` date NOT NULL,
  `orderId` varchar(25) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Rekening` (`Rekening`) USING BTREE,
  KEY `Afschriftnummer` (`Afschriftnummer`) USING BTREE,
  KEY `Fonds` (`Fonds`) USING BTREE,
  KEY `Valuta` (`Valuta`) USING BTREE,
  KEY `Boekdatum` (`Boekdatum`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2017038961 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Remisiers`
--

DROP TABLE IF EXISTS `Remisiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Remisiers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Remisier` varchar(15) DEFAULT NULL,
  `Naam` varchar(50) DEFAULT NULL,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `methode` int(11) NOT NULL DEFAULT '0',
  `percentage` double NOT NULL DEFAULT '0',
  `btw` double NOT NULL DEFAULT '0',
  `bodemVermogen` double NOT NULL DEFAULT '0',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Rendementsheffing`
--

DROP TABLE IF EXISTS `Rendementsheffing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Rendementsheffing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jaar` date DEFAULT '0000-00-00',
  `vrijstellingEenP` double NOT NULL DEFAULT '0',
  `vrijstellingTweeP` double NOT NULL DEFAULT '0',
  `percentage1` double NOT NULL DEFAULT '0',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `vermogen1` double NOT NULL,
  `vermogen2` double NOT NULL,
  `vermogen3` double NOT NULL,
  `vermogen4` double NOT NULL,
  `percentage2` double NOT NULL,
  `percentage3` double NOT NULL,
  `percentage4` double NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Rentepercentages`
--

DROP TABLE IF EXISTS `Rentepercentages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Rentepercentages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Fonds` varchar(25) DEFAULT NULL,
  `Datum` datetime DEFAULT NULL,
  `Rentepercentage` double DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `GeldigVanaf` date NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Fonds` (`Fonds`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=13455 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Risicoklassen`
--

DROP TABLE IF EXISTS `Risicoklassen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Risicoklassen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `Risicoklasse` varchar(50) DEFAULT NULL,
  `Minimaal` double DEFAULT NULL,
  `Maximaal` double DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `verwachtRendement` float NOT NULL DEFAULT '0',
  `verwachtMaxVerlies` float NOT NULL DEFAULT '0',
  `verwachtMaxWinst` float NOT NULL DEFAULT '0',
  `klasseStd` float NOT NULL DEFAULT '0',
  `afkorting` varchar(20) NOT NULL,
  `uitsluitenScenario` tinyint(3) NOT NULL,
  `verwachtKostenPercentage` double NOT NULL,
  `verwachtBrutoRendement` float NOT NULL,
  `kleur` mediumtext NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Vermogensbeheerder` (`Vermogensbeheerder`) USING BTREE,
  KEY `Risicoklasse` (`Risicoklasse`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=391 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Schaduwkoersen`
--

DROP TABLE IF EXISTS `Schaduwkoersen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Schaduwkoersen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Fonds` varchar(25) DEFAULT NULL,
  `Datum` datetime DEFAULT NULL,
  `Koers` double DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Fonds` (`Fonds`) USING BTREE,
  KEY `Datum` (`Datum`) USING BTREE,
  KEY `change_date` (`change_date`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=4035378 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SectorenPerHoofdsector`
--

DROP TABLE IF EXISTS `SectorenPerHoofdsector`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SectorenPerHoofdsector` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `Hoofdsector` varchar(15) DEFAULT NULL,
  `Beleggingssector` varchar(15) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SoortOvereenkomsten`
--

DROP TABLE IF EXISTS `SoortOvereenkomsten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SoortOvereenkomsten` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) NOT NULL,
  `change_date` datetime NOT NULL,
  `add_user` varchar(10) NOT NULL,
  `add_date` datetime NOT NULL,
  `SoortOvereenkomst` varchar(30) DEFAULT '',
  `adviesRelatie` varchar(1) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `StandaardVeldVulling`
--

DROP TABLE IF EXISTS `StandaardVeldVulling`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `StandaardVeldVulling` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tabel` varchar(255) DEFAULT NULL,
  `veld` varchar(255) DEFAULT NULL,
  `waarde` text NOT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `tabelVeld` (`tabel`,`veld`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `StandaarddeviatiePerPortefeuille`
--

DROP TABLE IF EXISTS `StandaarddeviatiePerPortefeuille`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `StandaarddeviatiePerPortefeuille` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `Portefeuille` varchar(24) NOT NULL,
  `Minimum` double DEFAULT NULL,
  `Maximum` double DEFAULT NULL,
  `Norm` double NOT NULL DEFAULT '0',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Portefeuille` (`Portefeuille`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `StandaarddeviatiePerRisicoklasse`
--

DROP TABLE IF EXISTS `StandaarddeviatiePerRisicoklasse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `StandaarddeviatiePerRisicoklasse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `Risicoklasse` varchar(50) DEFAULT NULL,
  `Minimum` double DEFAULT NULL,
  `Maximum` double DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `norm` double NOT NULL DEFAULT '0',
  `debetNietToestaan` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `VermogensbeheerderRisicoklasse` (`Vermogensbeheerder`,`Risicoklasse`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TEMP_portcon`
--

DROP TABLE IF EXISTS `TEMP_portcon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TEMP_portcon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `portefeuille` varchar(100) DEFAULT NULL,
  `rekeningnr` varchar(100) DEFAULT NULL,
  `fonds` varchar(100) DEFAULT NULL,
  `aantal` decimal(15,5) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TijdelijkeBulkOrders`
--

DROP TABLE IF EXISTS `TijdelijkeBulkOrders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TijdelijkeBulkOrders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `portefeuille` varchar(24) NOT NULL,
  `client` varchar(25) NOT NULL,
  `ISINCode` varchar(26) NOT NULL DEFAULT '',
  `fonds` varchar(25) NOT NULL DEFAULT '',
  `aantal` double NOT NULL DEFAULT '0',
  `transactieSoort` varchar(2) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `koersLimiet` double NOT NULL DEFAULT '0',
  `depotbank` varchar(10) NOT NULL DEFAULT '',
  `pagina` int(11) NOT NULL,
  `checkResult` tinyint(4) NOT NULL,
  `checkResultRegels` text NOT NULL,
  `statusLog` text NOT NULL,
  `regelNr` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TijdelijkeBulkOrdersV2`
--

DROP TABLE IF EXISTS `TijdelijkeBulkOrdersV2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TijdelijkeBulkOrdersV2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `regelNr` int(11) NOT NULL,
  `aantal` double NOT NULL DEFAULT '0',
  `fonds` varchar(25) NOT NULL DEFAULT '',
  `fondssoort` varchar(8) NOT NULL,
  `fondseenheid` double NOT NULL,
  `fondsValuta` varchar(4) NOT NULL,
  `fondsBankcode` varchar(30) NOT NULL,
  `optieSymbool` varchar(5) NOT NULL,
  `optieType` varchar(1) NOT NULL,
  `optieUitoefenprijs` double NOT NULL,
  `optieExpDatum` varchar(6) NOT NULL,
  `ISINCode` varchar(26) NOT NULL DEFAULT '',
  `fondsOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `beurs` varchar(4) NOT NULL,
  `transactieSoort` char(2) NOT NULL DEFAULT '',
  `accountmanager` varchar(15) NOT NULL,
  `client` varchar(60) NOT NULL DEFAULT '',
  `portefeuille` varchar(24) NOT NULL,
  `depotbank` varchar(10) NOT NULL DEFAULT '',
  `rekening` varchar(25) NOT NULL,
  `valuta` varchar(6) NOT NULL DEFAULT '',
  `controleRegels` text,
  `controleStatus` tinyint(4) DEFAULT NULL,
  `koersLimiet` double NOT NULL DEFAULT '0',
  `pagina` int(11) NOT NULL,
  `orderbedrag` double(16,2) NOT NULL DEFAULT '0.00',
  `modelPercentage` double(8,4) NOT NULL,
  `portefeuillePercentage` double(8,4) NOT NULL,
  `afwijking` double(8,4) NOT NULL,
  `modelWaarde` double(16,2) NOT NULL DEFAULT '0.00',
  `koers` double(12,4) NOT NULL DEFAULT '0.0000',
  `bron` varchar(25) NOT NULL,
  `naarOrder` tinyint(3) NOT NULL,
  `validatieAanw` tinyint(3) NOT NULL,
  `validatieShort` tinyint(3) NOT NULL,
  `validatieLiqu` tinyint(3) NOT NULL,
  `validatieZorg` tinyint(3) NOT NULL,
  `validatieRisi` tinyint(3) NOT NULL,
  `validatieAkkam` tinyint(3) NOT NULL,
  `validatieGroot` tinyint(3) NOT NULL,
  `validatieVbep` tinyint(3) NOT NULL,
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `afmStdevVoor` double NOT NULL,
  `afmStdevNa` double NOT NULL,
  `Beleggingscategorie` varchar(15) NOT NULL DEFAULT '',
  `validatieVast` tinyint(1) NOT NULL,
  `validatieOptie` tinyint(3) NOT NULL,
  `validatieRest` tinyint(3) NOT NULL,
  `externeBatchId` varchar(25) NOT NULL,
  `afwijkingsbedrag` double(16,2) NOT NULL,
  `bedrag` double NOT NULL,
  `aantalInPositie` decimal(14,6) NOT NULL,
  `nieuwAantal` decimal(14,6) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `fonds` (`fonds`) USING BTREE,
  KEY `portefeuille` (`portefeuille`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TijdelijkeOrderRegels`
--

DROP TABLE IF EXISTS `TijdelijkeOrderRegels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TijdelijkeOrderRegels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fonds` varchar(25) NOT NULL DEFAULT '',
  `portefeuille` varchar(24) NOT NULL,
  `modelPercentage` double(8,4) NOT NULL DEFAULT '0.0000',
  `portefeuillePercentage` double(8,4) NOT NULL DEFAULT '0.0000',
  `afwijking` double(8,4) NOT NULL DEFAULT '0.0000',
  `valuta` varchar(6) NOT NULL DEFAULT '',
  `kopen` double(12,4) NOT NULL DEFAULT '0.0000',
  `verkopen` double(12,4) NOT NULL DEFAULT '0.0000',
  `overschrijding` double(12,4) NOT NULL DEFAULT '0.0000',
  `modelWaarde` double(12,4) NOT NULL DEFAULT '0.0000',
  `koers` double(12,4) NOT NULL DEFAULT '0.0000',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TijdelijkePerformance`
--

DROP TABLE IF EXISTS `TijdelijkePerformance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TijdelijkePerformance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Client` varchar(50) DEFAULT NULL,
  `Portefeuille` varchar(50) DEFAULT NULL,
  `Fonds` varchar(50) DEFAULT NULL,
  `Performance` double DEFAULT NULL,
  `Datum` datetime DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TijdelijkePositieLijst`
--

DROP TABLE IF EXISTS `TijdelijkePositieLijst`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TijdelijkePositieLijst` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `portefeuille` varchar(24) NOT NULL,
  `depotbank` varchar(20) NOT NULL DEFAULT '',
  `vermogensbeheerder` varchar(20) NOT NULL DEFAULT '',
  `datum` date NOT NULL DEFAULT '0000-00-00',
  `fondsCode` varchar(25) NOT NULL DEFAULT '',
  `fondsCodeNumeriek` varchar(25) NOT NULL DEFAULT '',
  `fondsSoort` varchar(50) NOT NULL DEFAULT '',
  `fondsOmschrijving` varchar(100) NOT NULL DEFAULT '',
  `fondsValuta` varchar(10) NOT NULL DEFAULT '',
  `ISIN` varchar(20) NOT NULL DEFAULT '',
  `aantal` double NOT NULL DEFAULT '0',
  `optieSoort` varchar(10) NOT NULL DEFAULT '',
  `soort` varchar(15) NOT NULL DEFAULT '',
  `waardeInEUR` double NOT NULL DEFAULT '0',
  `waardeInValuta` double NOT NULL DEFAULT '0',
  `kostprijs` double NOT NULL DEFAULT '0',
  `koers` double NOT NULL DEFAULT '0',
  `valutakoers` double NOT NULL DEFAULT '0',
  `batchid` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TijdelijkeRapportage`
--

DROP TABLE IF EXISTS `TijdelijkeRapportage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TijdelijkeRapportage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `beginAantal` decimal(18,6) NOT NULL,
  `totaalAantal` decimal(18,6) NOT NULL,
  `historischeWaarde` double NOT NULL DEFAULT '0',
  `historischeValutakoers` double NOT NULL DEFAULT '0',
  `historischeRapportageValutakoers` double NOT NULL DEFAULT '0',
  `beginwaardeLopendeJaar` double NOT NULL DEFAULT '0',
  `fondsEenheid` double NOT NULL DEFAULT '0',
  `actueleValuta` double NOT NULL DEFAULT '0',
  `beginwaardeValutaLopendeJaar` double NOT NULL DEFAULT '0',
  `fondsOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `actueleFonds` double NOT NULL DEFAULT '0',
  `valuta` varchar(4) NOT NULL DEFAULT '',
  `beginJaarPortefeuilleWaardeInValuta` double NOT NULL DEFAULT '0',
  `beginJaarPortefeuilleWaardeEuro` double NOT NULL DEFAULT '0',
  `beginPortefeuilleWaardeInValuta` double NOT NULL DEFAULT '0',
  `beginPortefeuilleWaardeEuro` double NOT NULL DEFAULT '0',
  `actuelePortefeuilleWaardeInValuta` double NOT NULL DEFAULT '0',
  `actuelePortefeuilleWaardeEuro` double NOT NULL DEFAULT '0',
  `fonds` varchar(25) NOT NULL DEFAULT '',
  `beleggingssector` varchar(15) NOT NULL DEFAULT '',
  `beleggingscategorie` varchar(15) NOT NULL DEFAULT '',
  `renteBerekenen` tinyint(1) NOT NULL DEFAULT '0',
  `rentePercentage` double NOT NULL DEFAULT '0',
  `renteDagen` int(11) NOT NULL DEFAULT '0',
  `eersteRentedatum` date NOT NULL DEFAULT '0000-00-00',
  `rentedatum` date NOT NULL DEFAULT '0000-00-00',
  `renteperiode` tinyint(4) NOT NULL DEFAULT '0',
  `renteVanaf` date NOT NULL DEFAULT '0000-00-00',
  `opgelopenRente` double NOT NULL DEFAULT '0',
  `opgelopenRenteEuro` double NOT NULL DEFAULT '0',
  `portefeuille` varchar(25) NOT NULL,
  `rekening` varchar(25) NOT NULL DEFAULT '',
  `type` varchar(25) NOT NULL DEFAULT '',
  `Regio` varchar(15) NOT NULL DEFAULT '',
  `AttributieCategorie` varchar(15) NOT NULL DEFAULT '',
  `Lossingsdatum` date NOT NULL DEFAULT '0000-00-00',
  `rapportageDatum` date NOT NULL DEFAULT '0000-00-00',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(15) NOT NULL DEFAULT '',
  `Bewaarder` varchar(20) NOT NULL DEFAULT '',
  `EindDatum` date NOT NULL DEFAULT '0000-00-00',
  `koersDatum` date NOT NULL DEFAULT '0000-00-00',
  `sessionId` tinyint(4) NOT NULL DEFAULT '0',
  `beleggingscategorieOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `beleggingssectorOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `hoofdcategorie` varchar(15) NOT NULL DEFAULT '',
  `hoofdsector` varchar(15) NOT NULL DEFAULT '',
  `hoofdcategorieOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `hoofdsectorOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `hoofdcategorieVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `hoofdsectorVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `beleggingssectorVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `beleggingscategorieVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `valutaVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `regioOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `regioVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `attributieCategorieVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `attributieCategorieOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `valutaOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `afmCategorie` varchar(15) NOT NULL DEFAULT '',
  `afmCategorieOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `fondspaar` int(11) NOT NULL,
  `afmCategorieVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `duurzaamCategorie` varchar(15) NOT NULL,
  `duurzaamCategorieOmschrijving` varchar(50) NOT NULL,
  `duurzaamCategorieVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `portefeuille` (`portefeuille`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `rapportageDatum` (`rapportageDatum`) USING BTREE,
  KEY `beleggingscategorie` (`beleggingscategorie`) USING BTREE,
  KEY `beleggingssector` (`beleggingssector`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=215 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TijdelijkeRekeningmutaties`
--

DROP TABLE IF EXISTS `TijdelijkeRekeningmutaties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TijdelijkeRekeningmutaties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Rekening` varchar(25) NOT NULL,
  `Omschrijving` varchar(50) DEFAULT NULL,
  `Boekdatum` datetime DEFAULT NULL,
  `Grootboekrekening` varchar(5) DEFAULT NULL,
  `Valuta` varchar(4) DEFAULT NULL,
  `Valutakoers` double DEFAULT NULL,
  `Fonds` varchar(25) DEFAULT NULL,
  `Aantal` double NOT NULL,
  `Fondskoers` double DEFAULT NULL,
  `Debet` double DEFAULT NULL,
  `Credit` double DEFAULT NULL,
  `Bedrag` double DEFAULT NULL,
  `Transactietype` varchar(5) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `aktie` varchar(6) DEFAULT NULL,
  `bestand` varchar(50) DEFAULT NULL,
  `regelnr` int(11) DEFAULT NULL,
  `Verwerkt` tinyint(4) DEFAULT NULL,
  `Memoriaalboeking` tinyint(4) DEFAULT NULL,
  `bankTransactieId` varchar(25) NOT NULL,
  `settlementDatum` date NOT NULL,
  `OmschrijvingOrg` text NOT NULL,
  `bankTransactieCode` varchar(15) NOT NULL,
  `bankOmschrijving` text NOT NULL,
  `orderId` varchar(25) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Transactieoverzicht`
--

DROP TABLE IF EXISTS `Transactieoverzicht`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Transactieoverzicht` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Portefeuille` varchar(24) NOT NULL,
  `Clientnaam` varchar(50) DEFAULT NULL,
  `Clientnaam1` varchar(50) DEFAULT NULL,
  `Depotbank` varchar(10) DEFAULT NULL,
  `Client` varchar(16) DEFAULT NULL,
  `ClientVermogensbeheerder` varchar(10) DEFAULT NULL,
  `Vermogensbeheerdersnaam` varchar(50) DEFAULT NULL,
  `Fonds` varchar(25) NOT NULL DEFAULT '',
  `FondskoersInkoop` double DEFAULT NULL,
  `FondskoersVerkoop` double DEFAULT NULL,
  `Fondseenheid` double DEFAULT NULL,
  `Fondsomschrijving` varchar(50) DEFAULT NULL,
  `Transactietype` varchar(5) DEFAULT NULL,
  `Boekdatum` datetime DEFAULT NULL,
  `Mutatieaantal` bigint(20) DEFAULT NULL,
  `Mutatiebedrag` double DEFAULT NULL,
  `InkoopwaardeInValuta` double DEFAULT NULL,
  `InkoopwaardeInEuro` double DEFAULT NULL,
  `VerkoopwaardeInValuta` double DEFAULT NULL,
  `VerkoopwaardeInEuro` double DEFAULT NULL,
  `HistorischeKostprijs` double DEFAULT NULL,
  `ResultaatVoorgaandeJaren` double DEFAULT NULL,
  `ResultaatAbsoluut` double DEFAULT NULL,
  `ResultaatPercentage` varchar(10) DEFAULT NULL,
  `VanDatum` datetime DEFAULT NULL,
  `TotDatum` datetime DEFAULT NULL,
  `FondsresultaatHuidigJaar` double DEFAULT NULL,
  `FondsresultaatVoorgaandeJaren` double DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Transactietypes`
--

DROP TABLE IF EXISTS `Transactietypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Transactietypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Transactietype` varchar(5) DEFAULT NULL,
  `Omschrijving` varchar(50) DEFAULT NULL,
  `Liquiditeit` tinyint(4) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `transactievorm` varchar(1) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `UpdateHistory`
--

DROP TABLE IF EXISTS `UpdateHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UpdateHistory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Bedrijf` varchar(35) NOT NULL DEFAULT '',
  `exportId` varchar(35) NOT NULL DEFAULT '',
  `type` varchar(35) NOT NULL DEFAULT '',
  `filename` varchar(100) NOT NULL DEFAULT '',
  `filesize` int(11) NOT NULL DEFAULT '0',
  `server` varchar(100) NOT NULL DEFAULT '',
  `username` varchar(35) NOT NULL DEFAULT '',
  `password` varchar(35) NOT NULL DEFAULT '',
  `complete` tinyint(1) NOT NULL DEFAULT '0',
  `terugmelding` text NOT NULL,
  `add_user` varchar(15) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(15) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `tableDef` mediumtext NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ValutaPerRegio`
--

DROP TABLE IF EXISTS `ValutaPerRegio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ValutaPerRegio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Valuta` varchar(4) DEFAULT NULL,
  `Regio` varchar(15) DEFAULT NULL,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Valutakoersen`
--

DROP TABLE IF EXISTS `Valutakoersen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Valutakoersen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Valuta` varchar(4) DEFAULT NULL,
  `Datum` datetime DEFAULT NULL,
  `Koers` double DEFAULT NULL,
  `import` int(11) NOT NULL DEFAULT '0',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `oorspKrsDt` date NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=143046 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Valutarisico`
--

DROP TABLE IF EXISTS `Valutarisico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Valutarisico` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Proces` varchar(25) DEFAULT NULL,
  `Datum` datetime DEFAULT NULL,
  `Portefeuille` varchar(50) DEFAULT NULL,
  `Valuta` varchar(4) DEFAULT NULL,
  `Fondswaarde` double DEFAULT NULL,
  `Liquiditeit` double DEFAULT NULL,
  `ValutaHedge` double DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Valutas`
--

DROP TABLE IF EXISTS `Valutas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Valutas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Valuta` varchar(4) DEFAULT NULL,
  `Omschrijving` varchar(50) DEFAULT NULL,
  `ValutaImportCode` varchar(10) DEFAULT NULL,
  `Valutateken` char(2) DEFAULT NULL,
  `Koerseenheid` bigint(20) DEFAULT NULL,
  `Afdrukvolgorde` tinyint(4) DEFAULT NULL,
  `AABgrens` double DEFAULT NULL,
  `AABcorrectie` double DEFAULT NULL,
  `TermijnValuta` tinyint(1) NOT NULL DEFAULT '0',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Valuta` (`Valuta`) USING BTREE,
  KEY `change_date` (`change_date`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ValutasPerBedrijf`
--

DROP TABLE IF EXISTS `ValutasPerBedrijf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ValutasPerBedrijf` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Bedrijf` varchar(20) NOT NULL DEFAULT '',
  `Valuta` varchar(4) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Bedrijf` (`Bedrijf`) USING BTREE,
  KEY `Valuta` (`Valuta`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Vermogensbeheerders`
--

DROP TABLE IF EXISTS `Vermogensbeheerders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Vermogensbeheerders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `Naam` varchar(50) DEFAULT NULL,
  `Adres` varchar(25) DEFAULT NULL,
  `Woonplaats` varchar(25) DEFAULT NULL,
  `Telefoon` varchar(25) NOT NULL,
  `Fax` varchar(25) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `order_controle` text NOT NULL,
  `grafiek_kleur` text NOT NULL,
  `Contactpersoon` varchar(25) DEFAULT NULL,
  `Exportpad` varchar(100) DEFAULT NULL,
  `NAWPad` varchar(100) DEFAULT NULL,
  `Layout` tinyint(4) DEFAULT NULL,
  `OIH` tinyint(4) DEFAULT NULL,
  `OIS` tinyint(4) DEFAULT NULL,
  `HSE` tinyint(4) DEFAULT NULL,
  `OIB` tinyint(4) DEFAULT NULL,
  `OIV` tinyint(4) DEFAULT NULL,
  `PERF` tinyint(4) DEFAULT NULL,
  `VOLK` tinyint(4) DEFAULT NULL,
  `VHO` tinyint(4) DEFAULT NULL,
  `TRANS` tinyint(4) DEFAULT NULL,
  `AfdrukvolgordeOIH` tinyint(4) DEFAULT NULL,
  `AfdrukvolgordeOIS` tinyint(4) DEFAULT NULL,
  `AfdrukvolgordeHSE` tinyint(4) DEFAULT NULL,
  `AfdrukvolgordeOIB` tinyint(4) DEFAULT NULL,
  `AfdrukvolgordeOIV` tinyint(4) DEFAULT NULL,
  `AfdrukvolgordePERF` tinyint(4) DEFAULT NULL,
  `AfdrukvolgordeVOLK` tinyint(4) DEFAULT NULL,
  `AfdrukvolgordeVHO` tinyint(4) DEFAULT NULL,
  `AfdrukvolgordeTRANS` tinyint(4) DEFAULT NULL,
  `Index1` varchar(25) DEFAULT NULL,
  `Index2` varchar(25) DEFAULT NULL,
  `PerformanceBerekening` tinyint(4) DEFAULT NULL,
  `MUT` tinyint(4) DEFAULT NULL,
  `AfdrukvolgordeMUT` tinyint(4) DEFAULT NULL,
  `VraagOmNAWImport` tinyint(4) DEFAULT NULL,
  `Gebruikersbeheer` tinyint(4) DEFAULT NULL,
  `SamenvoegenClientRapporten` tinyint(4) DEFAULT NULL,
  `PadPDFcombine` varchar(255) DEFAULT NULL,
  `FactuurBeheerfeeBerekening` tinyint(4) DEFAULT NULL,
  `BasisVoorRisicoMeting` tinyint(4) DEFAULT NULL,
  `AfdrukSortering` varchar(20) NOT NULL DEFAULT '',
  `csvSeperator` char(1) NOT NULL DEFAULT ',',
  `Export_data_kwartaal` text NOT NULL,
  `Export_data_maand` text NOT NULL,
  `Export_data_dag` text NOT NULL,
  `Export_kwartaal_pad` varchar(255) NOT NULL DEFAULT '',
  `Export_maand_pad` varchar(255) NOT NULL DEFAULT '',
  `Export_dag_pad` varchar(255) NOT NULL DEFAULT '',
  `rapportLink` tinyint(1) DEFAULT NULL,
  `rapportLinkUrl` varchar(150) NOT NULL DEFAULT '',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `Logo` varchar(35) NOT NULL DEFAULT '',
  `OIR` tinyint(4) NOT NULL DEFAULT '0',
  `GRAFIEK` tinyint(4) NOT NULL DEFAULT '0',
  `grafiek_sortering` tinyint(4) NOT NULL DEFAULT '0',
  `AfdrukvolgordeOIR` tinyint(4) NOT NULL DEFAULT '0',
  `AfdrukvolgordeGrafiek` tinyint(4) NOT NULL DEFAULT '0',
  `OptieTools` tinyint(4) NOT NULL DEFAULT '0',
  `Attributie` char(1) DEFAULT NULL,
  `attributieInPerformance` tinyint(4) NOT NULL DEFAULT '0',
  `check_rekeningmutaties` tinyint(4) NOT NULL DEFAULT '0',
  `check_categorie` tinyint(4) NOT NULL DEFAULT '0',
  `check_sector` tinyint(4) NOT NULL DEFAULT '0',
  `check_zorgplichtFonds` tinyint(4) NOT NULL DEFAULT '0',
  `check_zorgplichtPortefeuille` tinyint(4) NOT NULL DEFAULT '0',
  `check_hoofdcategorie` tinyint(4) NOT NULL DEFAULT '0',
  `check_hoofdsector` tinyint(4) NOT NULL DEFAULT '0',
  `check_sectorRegio` tinyint(4) NOT NULL DEFAULT '0',
  `check_sectorAttributie` tinyint(4) NOT NULL DEFAULT '0',
  `check_module_CRM` tinyint(4) NOT NULL DEFAULT '0',
  `check_module_ORDER` tinyint(4) NOT NULL DEFAULT '0',
  `ATT` tinyint(4) NOT NULL DEFAULT '0',
  `AfdrukvolgordeATT` tinyint(4) NOT NULL DEFAULT '0',
  `txtKoppeling` varchar(30) NOT NULL DEFAULT '',
  `uitgebreideAutoupdate` tinyint(4) NOT NULL DEFAULT '0',
  `maandRapportageYTD` tinyint(1) NOT NULL DEFAULT '0',
  `kwartaalRapportageYTD` tinyint(1) NOT NULL DEFAULT '0',
  `check_kruisposten` tinyint(4) NOT NULL DEFAULT '0',
  `Export_data_frontOffice` text NOT NULL,
  `check_historischePortefeuilleIndex` tinyint(4) NOT NULL DEFAULT '0',
  `CrmClientNaam` tinyint(4) NOT NULL DEFAULT '0',
  `naamInExport` tinyint(4) NOT NULL DEFAULT '0',
  `CrmPortefeuilleInformatie` tinyint(4) NOT NULL DEFAULT '0',
  `CrmTerugRapportage` tinyint(4) NOT NULL DEFAULT '0',
  `check_module_BOEKEN` tinyint(4) NOT NULL DEFAULT '0',
  `check_module_ORDERNOTAS` tinyint(1) NOT NULL DEFAULT '0',
  `CrmExtraSpatie` tinyint(1) NOT NULL DEFAULT '0',
  `ddInleesLocatie` varchar(200) NOT NULL DEFAULT '',
  `rekening` varchar(20) NOT NULL DEFAULT '',
  `bank` varchar(40) NOT NULL DEFAULT '',
  `check_module_FACTUURHISTORIE` tinyint(4) NOT NULL DEFAULT '0',
  `ddInleesPortefeuillePreg` varchar(200) NOT NULL DEFAULT '',
  `koersExport` tinyint(4) NOT NULL DEFAULT '0',
  `FactuurMinimumBedrag` double NOT NULL DEFAULT '0',
  `website` varchar(100) NOT NULL DEFAULT '',
  `VerouderdeKoersDagen` int(11) NOT NULL DEFAULT '0',
  `verrekeningBestandsvergoeding` int(11) NOT NULL DEFAULT '0',
  `bestandsvergoedingBtw` int(11) NOT NULL DEFAULT '0',
  `bestandsvergoedingNiveau` int(11) NOT NULL DEFAULT '0',
  `OrderLoggingOpNota` tinyint(4) NOT NULL DEFAULT '0',
  `CRM_eigenTemplate` tinyint(4) NOT NULL DEFAULT '0',
  `OrderCheck` tinyint(4) NOT NULL DEFAULT '0',
  `kwartaalCheck` tinyint(4) NOT NULL DEFAULT '0',
  `module_bestandsvergoeding` tinyint(4) NOT NULL DEFAULT '0',
  `OrderStandaardType` tinyint(4) NOT NULL DEFAULT '0',
  `OrderStandaardMemo` varchar(255) NOT NULL DEFAULT '',
  `OrderOrderdesk` tinyint(4) NOT NULL DEFAULT '0',
  `OrderStatusKeuze` text NOT NULL,
  `transactiemeldingWaarde` double NOT NULL,
  `transactiemeldingEmail` varchar(200) NOT NULL,
  `check_module_CRM_eigenVelden` tinyint(4) NOT NULL DEFAULT '0',
  `IndexRisicovrij` varchar(25) NOT NULL DEFAULT '',
  `CRM_alleenNAW` tinyint(4) NOT NULL DEFAULT '0',
  `check_afmCategorie` tinyint(4) NOT NULL DEFAULT '0',
  `orderCheckMaxAge` int(11) NOT NULL DEFAULT '0',
  `check_rekeningATT` tinyint(4) NOT NULL DEFAULT '0',
  `check_rekeningCat` tinyint(4) NOT NULL DEFAULT '0',
  `fondsenmeldingEmail` varchar(200) NOT NULL DEFAULT '',
  `geenStandaardSector` tinyint(3) NOT NULL DEFAULT '0',
  `orderControleEmail` varchar(200) NOT NULL DEFAULT '',
  `check_module_PORTAAL` tinyint(1) NOT NULL DEFAULT '0',
  `check_module_portefeuilleWaarde` tinyint(1) NOT NULL DEFAULT '0',
  `OrderStandaardTijdsSoort` varchar(3) NOT NULL DEFAULT '',
  `ddVerwijderen` tinyint(3) NOT NULL DEFAULT '0',
  `transactieMeldingType` tinyint(4) NOT NULL DEFAULT '0',
  `check_rekeningDepotbank` tinyint(4) NOT NULL DEFAULT '0',
  `TransactiefeeBtw` tinyint(4) NOT NULL DEFAULT '0',
  `CrmAutomatischVerzenden` tinyint(4) NOT NULL DEFAULT '0',
  `FactuurMinimumPerTransactie` double NOT NULL DEFAULT '0',
  `autoPortaalVulling` tinyint(4) NOT NULL DEFAULT '0',
  `check_module_SCENARIO` tinyint(4) NOT NULL DEFAULT '0',
  `FACTUURHISTORIE_gebruikLaatsteWaarde` tinyint(3) NOT NULL DEFAULT '0',
  `ScenarioMinimaleKans` double NOT NULL DEFAULT '0',
  `CRM_PanasonicKoppeling` tinyint(4) NOT NULL,
  `OrderStandaardTransactieType` varchar(2) NOT NULL,
  `OrderCheckClientNaam` tinyint(3) NOT NULL,
  `BeheerfeeAdministratieVergoedingVast` tinyint(3) NOT NULL,
  `check_module_VRAGEN` tinyint(4) NOT NULL,
  `ScenarioGewenstProfiel` tinyint(3) NOT NULL,
  `frontofficeClientExcel` tinyint(4) NOT NULL,
  `OrderuitvoerBewaarder` tinyint(4) NOT NULL,
  `check_Beurs` tinyint(4) NOT NULL,
  `check_BB_Landcodes` tinyint(4) NOT NULL,
  `check_portaalCrmVink` tinyint(3) NOT NULL,
  `check_participants` tinyint(1) NOT NULL DEFAULT '0',
  `portaalPeriode` tinyint(3) NOT NULL,
  `check_portaalDocumenten` tinyint(3) NOT NULL,
  `Einddatum` datetime NOT NULL DEFAULT '2037-12-31 00:00:00',
  `orderMaxBedrag` double NOT NULL,
  `orderMaxPercentage` double NOT NULL,
  `SdFrequentie` varchar(2) NOT NULL,
  `SdMethodiek` varchar(2) NOT NULL,
  `SdWaarnemingen` int(11) NOT NULL,
  `SdOpbouw` tinyint(3) NOT NULL,
  `check_duurzaamheid` tinyint(3) NOT NULL,
  `aanlevertijd` time NOT NULL,
  `check_module_UREN` tinyint(3) NOT NULL,
  `orderMaxPercentagePositie` double NOT NULL,
  `orderPreValidatie` tinyint(3) NOT NULL,
  `orderVierOgen` tinyint(3) NOT NULL,
  `kasbankBrokerVerwerking` tinyint(3) NOT NULL,
  `orderAkkoord` tinyint(3) NOT NULL,
  `orderFxToestaan` tinyint(3) NOT NULL,
  `adventVerwerking` tinyint(3) NOT NULL,
  `ScenarioAfwijkendProfielPDF` tinyint(4) NOT NULL DEFAULT '1',
  `HTMLRapportage` tinyint(4) NOT NULL DEFAULT '0',
  `WelkomMenuV2` tinyint(4) NOT NULL DEFAULT '0',
  `vvRappToegestaan` tinyint(4) NOT NULL DEFAULT '0',
  `rapportDoorkijk` tinyint(3) NOT NULL DEFAULT '0',
  `orderGeenHervalidatie` tinyint(1) NOT NULL,
  `eMailInlezen` tinyint(4) NOT NULL,
  `millogicVerwerking` tinyint(1) NOT NULL,
  `orderAdviesNotificatie` tinyint(1) NOT NULL,
  `standaardRapportageFreq` varchar(1) NOT NULL,
  `emailSignaleringen` varchar(200) NOT NULL,
  `orderredenVerplicht` tinyint(3) NOT NULL,
  `orderTransRep` tinyint(3) NOT NULL,
  `portaalVragenToestaan` tinyint(3) NOT NULL,
  `orderTransRepDecisionMaker` varchar(10) NOT NULL,
  `LEInrVBH` varchar(25) NOT NULL,
  `spreadKosten` double NOT NULL,
  `jaarafsluitingPerBewaarder` tinyint(3) NOT NULL,
  `fondskostenDoorkijkExport` tinyint(3) NOT NULL,
  `check_duurzaamCategorie` tinyint(4) NOT NULL,
  `emailPortaalvulling` varchar(200) NOT NULL,
  `ixpVerwerking` tinyint(3) NOT NULL,
  `morningstar` tinyint(4) NOT NULL,
  `orderViaConsolidatie` tinyint(1) NOT NULL,
  `orderAdviesBcc` varchar(200) NOT NULL,
  `bedragTransactiesignalering` double NOT NULL,
  `portefeuilleWaardeInclVkm` tinyint(3) NOT NULL,
  `callableDatumGebruiken` tinyint(3) NOT NULL,
  `portaalDailyClientSync` tinyint(3) NOT NULL,
  `CRM_GesprVerslagVerwWijz` tinyint(4) NOT NULL,
  `documentloosPortaal` tinyint(1) NOT NULL,
  `NAW_inclDocumenten` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Vermogensbeheerder` (`Vermogensbeheerder`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=70 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `VermogensbeheerdersPerBedrijf`
--

DROP TABLE IF EXISTS `VermogensbeheerdersPerBedrijf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VermogensbeheerdersPerBedrijf` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Bedrijf` varchar(10) DEFAULT NULL,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Bedrijf` (`Bedrijf`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=303 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `VermogensbeheerdersPerGebruiker`
--

DROP TABLE IF EXISTS `VermogensbeheerdersPerGebruiker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VermogensbeheerdersPerGebruiker` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Gebruiker` varchar(10) DEFAULT NULL,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Vermogensbeheerder` (`Vermogensbeheerder`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=4230 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Vertalingen`
--

DROP TABLE IF EXISTS `Vertalingen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Vertalingen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Taal` tinyint(4) DEFAULT NULL,
  `Term` varchar(255) NOT NULL DEFAULT '',
  `Vertaling` varchar(255) NOT NULL DEFAULT '',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=844 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `VoorlopigeRekeningafschriften`
--

DROP TABLE IF EXISTS `VoorlopigeRekeningafschriften`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VoorlopigeRekeningafschriften` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Rekening` varchar(25) NOT NULL,
  `Afschriftnummer` double DEFAULT NULL,
  `Datum` datetime DEFAULT NULL,
  `Saldo` double DEFAULT NULL,
  `NieuwSaldo` double DEFAULT NULL,
  `Verwerkt` tinyint(4) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Rekening` (`Rekening`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `VoorlopigeRekeningmutaties`
--

DROP TABLE IF EXISTS `VoorlopigeRekeningmutaties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VoorlopigeRekeningmutaties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Rekening` varchar(25) NOT NULL,
  `Afschriftnummer` double DEFAULT NULL,
  `Volgnummer` double DEFAULT NULL,
  `Omschrijving` varchar(50) DEFAULT NULL,
  `Boekdatum` datetime DEFAULT NULL,
  `Grootboekrekening` varchar(5) DEFAULT NULL,
  `Valuta` varchar(4) DEFAULT NULL,
  `Valutakoers` double DEFAULT NULL,
  `Fonds` varchar(25) DEFAULT NULL,
  `Aantal` decimal(24,6) NOT NULL,
  `Fondskoers` double DEFAULT NULL,
  `Debet` double NOT NULL DEFAULT '0',
  `Credit` double NOT NULL DEFAULT '0',
  `Bedrag` double NOT NULL DEFAULT '0',
  `Transactietype` varchar(5) DEFAULT NULL,
  `Verwerkt` tinyint(4) DEFAULT NULL,
  `Memoriaalboeking` tinyint(4) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `Bewaarder` varchar(20) NOT NULL DEFAULT '',
  `bankTransactieId` varchar(25) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Rekening` (`Rekening`) USING BTREE,
  KEY `Afschriftnummer` (`Afschriftnummer`) USING BTREE,
  KEY `Fonds` (`Fonds`) USING BTREE,
  KEY `Valuta` (`Valuta`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `VragenAntwoorden`
--

DROP TABLE IF EXISTS `VragenAntwoorden`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VragenAntwoorden` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vraagId` int(11) NOT NULL DEFAULT '0',
  `omschrijving` varchar(200) NOT NULL DEFAULT '',
  `punten` double NOT NULL DEFAULT '0',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `VragenIngevuld`
--

DROP TABLE IF EXISTS `VragenIngevuld`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VragenIngevuld` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `relatieId` int(11) NOT NULL DEFAULT '0',
  `vragenlijstId` int(11) NOT NULL DEFAULT '0',
  `vraagId` int(11) NOT NULL DEFAULT '0',
  `antwoordId` int(11) NOT NULL DEFAULT '0',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT '',
  `antwoordOpen` text NOT NULL,
  `crmRef_id` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `VragenLijstenPerRelatie`
--

DROP TABLE IF EXISTS `VragenLijstenPerRelatie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VragenLijstenPerRelatie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `nawId` int(11) NOT NULL,
  `vragenLijstId` int(11) NOT NULL,
  `datum` date NOT NULL,
  `zichtbaarInPortaal` tinyint(4) NOT NULL,
  `portaalStatus` varchar(15) NOT NULL,
  `portaalDatumIngevuld` datetime NOT NULL,
  `omschrijving` text NOT NULL,
  `memo` text NOT NULL,
  `log` text NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `VragenVragen`
--

DROP TABLE IF EXISTS `VragenVragen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VragenVragen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vragenlijstId` int(11) NOT NULL DEFAULT '0',
  `omschrijving` varchar(200) NOT NULL DEFAULT '',
  `volgorde` tinyint(4) NOT NULL DEFAULT '0',
  `vraagNummer` varchar(5) NOT NULL DEFAULT '',
  `vraag` text NOT NULL,
  `factor` double NOT NULL DEFAULT '0',
  `offline` tinyint(4) NOT NULL DEFAULT '0',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `CRM_trekveld` varchar(40) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `VragenVragenlijsten`
--

DROP TABLE IF EXISTS `VragenVragenlijsten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VragenVragenlijsten` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `omschrijving` varchar(200) NOT NULL DEFAULT '',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `titel` varchar(255) NOT NULL,
  `tekstRisicoprofiel` tinyint(4) NOT NULL DEFAULT '1',
  `extraInfo` mediumtext NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ZorgplichtPerBeleggingscategorie`
--

DROP TABLE IF EXISTS `ZorgplichtPerBeleggingscategorie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ZorgplichtPerBeleggingscategorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `Zorgplicht` varchar(50) DEFAULT NULL,
  `Beleggingscategorie` varchar(25) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `VermogensbeheerderBeleggingscategorie` (`Vermogensbeheerder`,`Beleggingscategorie`) USING BTREE,
  KEY `VermogensbeheerderZorgplicht` (`Vermogensbeheerder`,`Zorgplicht`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=333 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ZorgplichtPerFonds`
--

DROP TABLE IF EXISTS `ZorgplichtPerFonds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ZorgplichtPerFonds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `Zorgplicht` varchar(50) DEFAULT NULL,
  `Fonds` varchar(25) DEFAULT NULL,
  `Percentage` int(11) NOT NULL DEFAULT '100',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Vermogensbeheerder` (`Vermogensbeheerder`) USING BTREE,
  KEY `Fonds` (`Fonds`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=63621 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ZorgplichtPerPortefeuille`
--

DROP TABLE IF EXISTS `ZorgplichtPerPortefeuille`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ZorgplichtPerPortefeuille` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Portefeuille` varchar(24) NOT NULL,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `Zorgplicht` varchar(50) DEFAULT NULL,
  `Minimum` double DEFAULT NULL,
  `Maximum` double DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `norm` double NOT NULL,
  `Vanaf` date NOT NULL DEFAULT '0000-00-00',
  `extra` tinyint(3) NOT NULL DEFAULT '0',
  `maxBedrag` double NOT NULL,
  `minBedrag` double NOT NULL,
  `procentueleOpslag` double NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Portefeuille` (`Portefeuille`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=8441 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ZorgplichtPerRisicoklasse`
--

DROP TABLE IF EXISTS `ZorgplichtPerRisicoklasse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ZorgplichtPerRisicoklasse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `Zorgplicht` varchar(50) DEFAULT NULL,
  `Risicoklasse` varchar(50) DEFAULT NULL,
  `Minimum` double DEFAULT NULL,
  `Maximum` double DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `norm` double NOT NULL,
  `maxBedrag` double NOT NULL,
  `minBedrag` double NOT NULL,
  `procentueleOpslag` double NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `VermogensbeheerderZorgplicht` (`Vermogensbeheerder`,`Zorgplicht`) USING BTREE,
  KEY `VermogensbeheerderRisicoklasse` (`Vermogensbeheerder`,`Risicoklasse`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=312 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Zorgplichtcategorien`
--

DROP TABLE IF EXISTS `Zorgplichtcategorien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Zorgplichtcategorien` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `Zorgplicht` varchar(50) DEFAULT NULL,
  `Omschrijving` varchar(100) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=170 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Zorgplichtcontrole`
--

DROP TABLE IF EXISTS `Zorgplichtcontrole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Zorgplichtcontrole` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Portefeuille` varchar(24) NOT NULL,
  `Depotbank` varchar(10) DEFAULT NULL,
  `ClientVermogensbeheerder` varchar(10) DEFAULT NULL,
  `ClientNaam` varchar(100) DEFAULT NULL,
  `Portefeuillewaarde` double DEFAULT NULL,
  `Conclusie` varchar(25) DEFAULT NULL,
  `Controledatum` datetime DEFAULT NULL,
  `Reden1` varchar(100) DEFAULT NULL,
  `Reden2` varchar(100) DEFAULT NULL,
  `Reden3` varchar(100) DEFAULT NULL,
  `Reden4` varchar(100) DEFAULT NULL,
  `Reden5` varchar(100) DEFAULT NULL,
  `Reden6` varchar(100) DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_htmlDashboard`
--

DROP TABLE IF EXISTS `_htmlDashboard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_htmlDashboard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `portefeuille` varchar(40) NOT NULL,
  `soort` varchar(25) NOT NULL,
  `datum` date NOT NULL,
  `periodeForm` date NOT NULL,
  `waardeHuidige` double NOT NULL,
  `waardeBegin` double NOT NULL,
  `performance` double NOT NULL,
  `perfCumulatief` double NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=812 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_htmlDashboardRen`
--

DROP TABLE IF EXISTS `_htmlDashboardRen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_htmlDashboardRen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `portefeuille` varchar(40) NOT NULL,
  `soort` varchar(25) NOT NULL,
  `datum` date NOT NULL,
  `periodeForm` date NOT NULL,
  `waardeHuidige` double NOT NULL,
  `waardeBegin` double NOT NULL,
  `performance` double NOT NULL,
  `perfCumulatief` double NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=664 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_htmlRapport_ATT`
--

DROP TABLE IF EXISTS `_htmlRapport_ATT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_htmlRapport_ATT` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `soort` varchar(20) NOT NULL,
  `waardeBegin` double NOT NULL,
  `index` double NOT NULL,
  `specifiekeIndex` double NOT NULL,
  `valuta` varchar(4) NOT NULL,
  `periode` varchar(35) NOT NULL,
  `periodeForm` varchar(35) NOT NULL,
  `waardeHuidige` double NOT NULL,
  `waardeMutatie` double NOT NULL,
  `stortingen` double NOT NULL,
  `onttrekkingen` double NOT NULL,
  `resultaatVerslagperiode` double NOT NULL,
  `gemiddelde` double NOT NULL,
  `kosten` double NOT NULL,
  `opbrengsten` double NOT NULL,
  `performance` double NOT NULL,
  `ongerealiseerd` double NOT NULL,
  `rente` double NOT NULL,
  `gerealiseerd` double NOT NULL,
  `extra` text NOT NULL,
  `datum` date NOT NULL,
  `specifiekeIndexPerformance` double NOT NULL,
  `perfCumulatief` double NOT NULL,
  `specifiekeIndexVorige` double DEFAULT NULL,
  `portefeuille` varchar(24) NOT NULL,
  `database` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=116 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_htmlRapport_FondsOverzicht`
--

DROP TABLE IF EXISTS `_htmlRapport_FondsOverzicht`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_htmlRapport_FondsOverzicht` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `vermogensBeheerder` varchar(10) NOT NULL,
  `Portefeuille` varchar(30) NOT NULL,
  `Rapport` varchar(20) NOT NULL,
  `Client` varchar(20) NOT NULL,
  `Naam` varchar(50) NOT NULL,
  `Naam1` varchar(50) NOT NULL,
  `Fonds` varchar(25) NOT NULL,
  `fondsISIN` varchar(25) NOT NULL,
  `accountmanager` varchar(50) NOT NULL,
  `depotbank` varchar(12) NOT NULL,
  `FondsOmschrijving` varchar(50) NOT NULL,
  `Kostprijs` double NOT NULL,
  `HistorischeWaarde` double NOT NULL,
  `AandeelBeleggingscategorie` double NOT NULL,
  `AandeelTotaalvermogen` double NOT NULL,
  `AandeelTotaalBelegdvermogen` double NOT NULL,
  `AantalInPortefeuille` double NOT NULL,
  `memo` text NOT NULL,
  `risicoklasse` varchar(50) NOT NULL,
  `soortOvereenkomst` varchar(30) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_htmlRapport_MODEL`
--

DROP TABLE IF EXISTS `_htmlRapport_MODEL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_htmlRapport_MODEL` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `datum` date NOT NULL,
  `type` varchar(5) NOT NULL,
  `fonds` varchar(60) NOT NULL,
  `fondsOmschrijving` varchar(64) NOT NULL,
  `modelPercentage` double NOT NULL,
  `werkelijkPercentage` double NOT NULL,
  `afwijkingPercentage` double NOT NULL,
  `afwijkingEur` double NOT NULL,
  `kopen` double NOT NULL,
  `verkopen` double NOT NULL,
  `waardeModel` double NOT NULL,
  `koersLokaal` double NOT NULL,
  `geschatOrderbedrag` double NOT NULL,
  `modelWaarde` double NOT NULL,
  `huidigeWaarde` double NOT NULL,
  `portefeuille` varchar(24) NOT NULL,
  `ISINCode` varchar(24) NOT NULL,
  `valuta` varchar(4) NOT NULL,
  `stamgegevens` text NOT NULL,
  `hoofdcategorie` varchar(30) NOT NULL,
  `hoofdsector` varchar(30) NOT NULL,
  `Regio` varchar(30) NOT NULL,
  `beleggingscategorie` varchar(30) NOT NULL,
  `beleggingssector` varchar(30) NOT NULL,
  `hoofdcategorieVolgorde` double NOT NULL,
  `hoofdcategorieOmschrijving` varchar(60) NOT NULL,
  `hoofdsectorVolgorde` double NOT NULL,
  `hoofdsectorOmschrijving` varchar(60) NOT NULL,
  `valutaVolgorde` double NOT NULL,
  `valutaOmschrijving` varchar(60) NOT NULL,
  `regioVolgorde` double NOT NULL,
  `regioOmschrijving` varchar(60) NOT NULL,
  `beleggingscategorieVolgorde` double NOT NULL,
  `beleggingscategorieOmschrijving` varchar(60) NOT NULL,
  `beleggingssectorVolgorde` double NOT NULL,
  `beleggingssectorOmschrijving` varchar(60) NOT NULL,
  `consolidatie` int(3) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_htmlRapport_TRANS`
--

DROP TABLE IF EXISTS `_htmlRapport_TRANS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_htmlRapport_TRANS` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `datum` date NOT NULL,
  `transactietype` varchar(5) NOT NULL,
  `aantal` double NOT NULL,
  `fonds` varchar(60) NOT NULL,
  `fondsOmschrijving` varchar(64) NOT NULL,
  `aankoopKoersValuta` double NOT NULL,
  `aankoopWaardeValuta` double NOT NULL,
  `aankoopWaardeEur` double NOT NULL,
  `verkoopKoersValuta` double NOT NULL,
  `verkoopWaardeValuta` double NOT NULL,
  `verkoopWaardeEur` double NOT NULL,
  `historischeKostprijsEur` double NOT NULL,
  `resultaatEur` double NOT NULL,
  `resultaatvoorgaandEur` double NOT NULL,
  `resultaatgedurendEur` double NOT NULL,
  `resultaatPercent` double NOT NULL,
  `portefeuille` varchar(24) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=459 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_htmlRapport_VOLK`
--

DROP TABLE IF EXISTS `_htmlRapport_VOLK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_htmlRapport_VOLK` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `type` varchar(30) NOT NULL,
  `totaalAantal` double NOT NULL,
  `historischeWaarde` double NOT NULL,
  `historischeValutakoers` double NOT NULL,
  `historischeRapportageValutakoers` double NOT NULL,
  `beginwaardeLopendeJaar` double NOT NULL,
  `fondsEenheid` double NOT NULL,
  `beginwaardeValutaLopendeJaar` double NOT NULL,
  `renteBerekenen` double NOT NULL,
  `voorgaandejarenActief` double NOT NULL,
  `fondsOmschrijving` varchar(60) NOT NULL,
  `valuta` varchar(5) NOT NULL,
  `eersteRentedatum` datetime NOT NULL,
  `rentedatum` datetime NOT NULL,
  `renteperiode` double NOT NULL,
  `actueleValuta` double NOT NULL,
  `actueleFonds` double NOT NULL,
  `koersDatum` datetime NOT NULL,
  `Bewaarder` varchar(5) NOT NULL,
  `beginPortefeuilleWaardeInValuta` double NOT NULL,
  `beginPortefeuilleWaardeEuro` double NOT NULL,
  `actuelePortefeuilleWaardeInValuta` double NOT NULL,
  `actuelePortefeuilleWaardeEuro` double NOT NULL,
  `fonds` varchar(60) NOT NULL,
  `beleggingssector` varchar(30) NOT NULL,
  `beleggingscategorie` varchar(30) NOT NULL,
  `lossingsdatum` datetime NOT NULL,
  `Regio` varchar(30) NOT NULL,
  `AttributieCategorie` varchar(30) NOT NULL,
  `afmCategorie` varchar(30) NOT NULL,
  `beleggingscategorieOmschrijving` varchar(60) NOT NULL,
  `beleggingssectorOmschrijving` varchar(60) NOT NULL,
  `hoofdcategorie` varchar(30) NOT NULL,
  `hoofdsector` varchar(30) NOT NULL,
  `hoofdcategorieOmschrijving` varchar(60) NOT NULL,
  `hoofdsectorOmschrijving` varchar(60) NOT NULL,
  `attributieCategorieOmschrijving` varchar(60) NOT NULL,
  `afmCategorieOmschrijving` varchar(60) NOT NULL,
  `regioOmschrijving` varchar(60) NOT NULL,
  `valutaOmschrijving` varchar(30) NOT NULL,
  `valutaVolgorde` double NOT NULL,
  `hoofdcategorieVolgorde` double NOT NULL,
  `hoofdsectorVolgorde` double NOT NULL,
  `beleggingssectorVolgorde` double NOT NULL,
  `beleggingscategorieVolgorde` double NOT NULL,
  `regioVolgorde` double NOT NULL,
  `attributieCategorieVolgorde` double NOT NULL,
  `aandeelOpTotaleWaarde` double NOT NULL,
  `fondsResultaat` double NOT NULL,
  `valutaResultaat` double NOT NULL,
  `resultaatInProcent` double NOT NULL,
  `renteVanaf` datetime NOT NULL,
  `renteDagen` double NOT NULL,
  `rekening` varchar(25) NOT NULL,
  `portefeuille` varchar(30) NOT NULL,
  `rapportDatum` date NOT NULL,
  `afmCategorieVolgorde` double DEFAULT NULL,
  `ISINCode` varchar(26) NOT NULL,
  `rating` varchar(26) NOT NULL,
  `duurzaamCategorie` varchar(15) NOT NULL,
  `duurzaamCategorieOmschrijving` varchar(50) NOT NULL,
  `duurzaamCategorieVolgorde` tinyint(4) NOT NULL,
  `orderinlegInBedrag` tinyint(4) NOT NULL,
  `consolidatie` int(3) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=79 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `abnV2TransactieCodes`
--

DROP TABLE IF EXISTS `abnV2TransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abnV2TransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `bankCode` varchar(10) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ae_config`
--

DROP TABLE IF EXISTS `ae_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ae_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `field` varchar(60) NOT NULL DEFAULT '',
  `value` mediumtext NOT NULL,
  `lock` tinyint(3) DEFAULT '0',
  `memo` text,
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(15) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `fieldIndex` (`field`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=303 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ae_log`
--

DROP TABLE IF EXISTS `ae_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ae_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `txt` text,
  `date` datetime DEFAULT NULL,
  `add_user` varchar(10) NOT NULL,
  `bron` varchar(100) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `datum` (`date`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ae_modulecfg`
--

DROP TABLE IF EXISTS `ae_modulecfg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ae_modulecfg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `moduleName` varchar(20) DEFAULT NULL,
  `moduleChecksum` varchar(64) DEFAULT NULL,
  `moduleExpires` date DEFAULT NULL,
  `bedrijf` varchar(50) DEFAULT NULL,
  `add_date` date DEFAULT NULL,
  `add_user` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `afmCategorien`
--

DROP TABLE IF EXISTS `afmCategorien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `afmCategorien` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `afmCategorie` varchar(15) NOT NULL DEFAULT '',
  `omschrijving` varchar(50) DEFAULT NULL,
  `standaarddeviatie` double NOT NULL DEFAULT '0',
  `correlatie` text NOT NULL,
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `Afdrukvolgorde` tinyint(3) NOT NULL,
  `standaarddeviatieMin` double NOT NULL,
  `standaarddeviatieMax` double NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `afmCategorie` (`afmCategorie`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `afmCategorien_201812`
--

DROP TABLE IF EXISTS `afmCategorien_201812`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `afmCategorien_201812` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `afmCategorie` varchar(15) NOT NULL DEFAULT '',
  `omschrijving` varchar(50) DEFAULT NULL,
  `standaarddeviatie` double NOT NULL DEFAULT '0',
  `correlatie` text NOT NULL,
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `Afdrukvolgorde` tinyint(3) NOT NULL,
  `standaarddeviatieMin` double NOT NULL,
  `standaarddeviatieMax` double NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `afmCategorie` (`afmCategorie`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `afmCategorien_202110`
--

DROP TABLE IF EXISTS `afmCategorien_202110`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `afmCategorien_202110` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `afmCategorie` varchar(15) NOT NULL DEFAULT '',
  `omschrijving` varchar(50) DEFAULT NULL,
  `standaarddeviatie` double NOT NULL DEFAULT '0',
  `correlatie` text NOT NULL,
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `Afdrukvolgorde` tinyint(3) NOT NULL,
  `standaarddeviatieMin` double NOT NULL,
  `standaarddeviatieMax` double NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `afmCategorie` (`afmCategorie`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `afmCategorien_AFM2010_20150821`
--

DROP TABLE IF EXISTS `afmCategorien_AFM2010_20150821`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `afmCategorien_AFM2010_20150821` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `afmCategorie` varchar(15) NOT NULL DEFAULT '',
  `omschrijving` varchar(50) DEFAULT NULL,
  `standaarddeviatie` double NOT NULL DEFAULT '0',
  `correlatie` text NOT NULL,
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `Afdrukvolgorde` tinyint(3) NOT NULL,
  `standaarddeviatieMin` double NOT NULL,
  `standaarddeviatieMax` double NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `afmCategorie` (`afmCategorie`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `afmCategorien_backup_20150821`
--

DROP TABLE IF EXISTS `afmCategorien_backup_20150821`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `afmCategorien_backup_20150821` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `afmCategorie` varchar(15) NOT NULL DEFAULT '',
  `omschrijving` varchar(50) DEFAULT NULL,
  `standaarddeviatie` double NOT NULL DEFAULT '0',
  `correlatie` text NOT NULL,
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `Afdrukvolgorde` tinyint(3) NOT NULL,
  `standaarddeviatieMin` double NOT NULL,
  `standaarddeviatieMax` double NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `afmCategorie` (`afmCategorie`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agenda`
--

DROP TABLE IF EXISTS `agenda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agenda` (
  `id` bigint(4) NOT NULL AUTO_INCREMENT,
  `gebruiker` tinytext,
  `kop` tinytext,
  `txt` text,
  `soort` varchar(20) NOT NULL DEFAULT '',
  `plandate` date DEFAULT NULL,
  `alarm` char(1) DEFAULT NULL,
  `done` tinyint(1) DEFAULT NULL,
  `plantime` time DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `klant` varchar(40) DEFAULT NULL,
  `duur` time DEFAULT NULL,
  `add_user` varchar(15) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(15) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `soort` (`soort`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agenda_gebruiker`
--

DROP TABLE IF EXISTS `agenda_gebruiker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agenda_gebruiker` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(10) NOT NULL DEFAULT '0',
  `agenda_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `agenda` (`user_id`,`agenda_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `apiQueueExtern`
--

DROP TABLE IF EXISTS `apiQueueExtern`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apiQueueExtern` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `submitterIp` varchar(50) NOT NULL,
  `eventCode` varchar(50) NOT NULL,
  `action` varchar(50) NOT NULL,
  `dataFields` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `appVertaling`
--

DROP TABLE IF EXISTS `appVertaling`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appVertaling` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `veld` text NOT NULL,
  `nl` text NOT NULL,
  `en` text NOT NULL,
  `fr` text NOT NULL,
  `du` text NOT NULL,
  `orgin` varchar(200) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=9450 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `begrippenCategorie`
--

DROP TABLE IF EXISTS `begrippenCategorie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `begrippenCategorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vermogensbeheerder` varchar(10) NOT NULL DEFAULT '',
  `categorie` varchar(50) NOT NULL DEFAULT '',
  `afdrukVolgorde` tinyint(4) NOT NULL DEFAULT '0',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `begrippenRapport`
--

DROP TABLE IF EXISTS `begrippenRapport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `begrippenRapport` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vermogensbeheerder` varchar(10) NOT NULL DEFAULT '',
  `begrip` varchar(50) NOT NULL DEFAULT '',
  `omschrijving` text NOT NULL,
  `afdrukVolgorde` tinyint(4) NOT NULL DEFAULT '0',
  `categorieId` int(11) NOT NULL DEFAULT '0',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `benchmarkverdeling`
--

DROP TABLE IF EXISTS `benchmarkverdeling`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `benchmarkverdeling` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `benchmark` varchar(25) NOT NULL DEFAULT '',
  `fonds` varchar(25) NOT NULL DEFAULT '',
  `percentage` double NOT NULL DEFAULT '0',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `toelichting` varchar(200) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `benchmark` (`benchmark`) USING BTREE,
  KEY `fonds` (`fonds`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=614 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `benchmarkverdelingVanaf`
--

DROP TABLE IF EXISTS `benchmarkverdelingVanaf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `benchmarkverdelingVanaf` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `benchmark` varchar(25) NOT NULL DEFAULT '',
  `fonds` varchar(25) NOT NULL DEFAULT '',
  `percentage` double NOT NULL DEFAULT '0',
  `vanaf` date DEFAULT '0000-00-00',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `toelichting` varchar(200) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `benchmark` (`benchmark`) USING BTREE,
  KEY `fonds` (`fonds`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bilTransactieCodes`
--

DROP TABLE IF EXISTS `bilTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bilTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `BILcode` varchar(10) NOT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bnpbglTransactieCodes`
--

DROP TABLE IF EXISTS `bnpbglTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bnpbglTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `bankCode` varchar(25) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `btcTransactieCodes`
--

DROP TABLE IF EXISTS `btcTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `btcTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `bankCode` varchar(10) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `caceisTransactieCodes`
--

DROP TABLE IF EXISTS `caceisTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `caceisTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `bankCode` varchar(25) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cawTransactieCodes`
--

DROP TABLE IF EXISTS `cawTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cawTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `bankCode` varchar(30) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contractueleUitsluitingen`
--

DROP TABLE IF EXISTS `contractueleUitsluitingen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contractueleUitsluitingen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vanaf` date NOT NULL DEFAULT '0000-00-00',
  `vermogensbeheerder` varchar(10) DEFAULT NULL,
  `portefeuille` varchar(24) NOT NULL,
  `fonds` varchar(25) DEFAULT NULL,
  `categoriesoort` varchar(50) NOT NULL,
  `categorie` varchar(30) NOT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `einddatum` date NOT NULL,
  `soortReservering` varchar(25) NOT NULL,
  `geldrekening` varchar(25) NOT NULL,
  `bedrag` double NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `controleEmailHistorie`
--

DROP TABLE IF EXISTS `controleEmailHistorie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `controleEmailHistorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categorie` varchar(100) NOT NULL DEFAULT '',
  `onderwerp` varchar(200) NOT NULL DEFAULT '',
  `body` mediumtext,
  `add_date` datetime DEFAULT NULL,
  `add_user` varchar(15) DEFAULT NULL,
  `change_user` varchar(15) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crmLaatsteFondsWaarden`
--

DROP TABLE IF EXISTS `crmLaatsteFondsWaarden`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crmLaatsteFondsWaarden` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `beginAantal` decimal(18,6) NOT NULL,
  `totaalAantal` decimal(18,6) NOT NULL,
  `historischeWaarde` double NOT NULL DEFAULT '0',
  `historischeValutakoers` double NOT NULL DEFAULT '0',
  `beginwaardeLopendeJaar` double NOT NULL DEFAULT '0',
  `fondsEenheid` double NOT NULL DEFAULT '0',
  `actueleValuta` double NOT NULL DEFAULT '0',
  `beginwaardeValutaLopendeJaar` double NOT NULL DEFAULT '0',
  `fondsOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `actueleFonds` double NOT NULL DEFAULT '0',
  `beginJaarPortefeuilleWaardeInValuta` double NOT NULL DEFAULT '0',
  `beginJaarPortefeuilleWaardeEuro` double NOT NULL DEFAULT '0',
  `beginPortefeuilleWaardeInValuta` double NOT NULL DEFAULT '0',
  `beginPortefeuilleWaardeEuro` double NOT NULL DEFAULT '0',
  `actuelePortefeuilleWaardeInValuta` double NOT NULL DEFAULT '0',
  `actuelePortefeuilleWaardeEuro` double NOT NULL DEFAULT '0',
  `fonds` varchar(25) NOT NULL DEFAULT '',
  `renteBerekenen` tinyint(1) NOT NULL DEFAULT '0',
  `rentePercentage` double NOT NULL DEFAULT '0',
  `renteDagen` int(11) NOT NULL DEFAULT '0',
  `eersteRentedatum` date NOT NULL DEFAULT '0000-00-00',
  `rentedatum` date NOT NULL DEFAULT '0000-00-00',
  `renteperiode` tinyint(4) NOT NULL DEFAULT '0',
  `renteVanaf` date NOT NULL DEFAULT '0000-00-00',
  `opgelopenRente` double NOT NULL DEFAULT '0',
  `opgelopenRenteEuro` double NOT NULL DEFAULT '0',
  `portefeuille` varchar(24) NOT NULL,
  `rekening` varchar(25) NOT NULL DEFAULT '',
  `type` varchar(25) NOT NULL DEFAULT '',
  `rapportageDatum` date NOT NULL DEFAULT '0000-00-00',
  `Lossingsdatum` date NOT NULL DEFAULT '0000-00-00',
  `historischeRapportageValutakoers` double NOT NULL DEFAULT '0',
  `Bewaarder` varchar(20) NOT NULL DEFAULT '',
  `EindDatum` date NOT NULL DEFAULT '0000-00-00',
  `koersDatum` date NOT NULL DEFAULT '0000-00-00',
  `beleggingscategorie` varchar(15) NOT NULL DEFAULT '',
  `beleggingscategorieOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `beleggingssectorOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `hoofdcategorie` varchar(15) NOT NULL DEFAULT '',
  `hoofdsector` varchar(15) NOT NULL DEFAULT '',
  `hoofdcategorieOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `hoofdsectorOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `hoofdcategorieVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `hoofdsectorVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `beleggingssector` varchar(15) NOT NULL DEFAULT '',
  `beleggingssectorVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `beleggingscategorieVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `valuta` varchar(4) NOT NULL DEFAULT '',
  `valutaVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `valutaOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `regio` varchar(15) NOT NULL DEFAULT '',
  `regioOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `regioVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `attributieCategorie` varchar(15) NOT NULL DEFAULT '',
  `attributieCategorieVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `attributieCategorieOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `afmCategorie` varchar(15) NOT NULL DEFAULT '',
  `afmCategorieOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `afmCategorieVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `fondspaar` int(11) NOT NULL,
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(15) NOT NULL DEFAULT '',
  `duurzaamCategorie` varchar(15) NOT NULL,
  `duurzaamCategorieOmschrijving` varchar(50) NOT NULL,
  `duurzaamCategorieVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `weging` double NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `portefeuille` (`portefeuille`) USING BTREE,
  KEY `fonds` (`fonds`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2193572 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_templates`
--

DROP TABLE IF EXISTS `custom_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `naam` varchar(255) DEFAULT NULL,
  `template` longtext,
  `categorie` varchar(100) DEFAULT NULL,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `verplichteVelden` text NOT NULL,
  `meertalig` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_txt`
--

DROP TABLE IF EXISTS `custom_txt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_txt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `txt` text,
  `field` varchar(40) NOT NULL,
  `type` varchar(40) NOT NULL,
  `Vermogensbeheerder` varchar(10) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(15) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(15) NOT NULL DEFAULT '',
  `extraKoppeling` varchar(255) NOT NULL DEFAULT '',
  `OrderLoggingOpNota` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dd_datastore01`
--

DROP TABLE IF EXISTS `dd_datastore01`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dd_datastore01` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `referenceId` int(11) NOT NULL DEFAULT '0',
  `filename` varchar(200) NOT NULL DEFAULT '',
  `filesize` int(11) NOT NULL DEFAULT '0',
  `filetype` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(127) NOT NULL DEFAULT '',
  `blobdata` mediumblob NOT NULL COMMENT 'max 16 mb',
  `blobCompressed` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `reference` (`referenceId`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dd_logging`
--

DROP TABLE IF EXISTS `dd_logging`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dd_logging` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dd_id` int(11) NOT NULL DEFAULT '0',
  `datastore` varchar(25) NOT NULL DEFAULT '',
  `rootReference` tinyint(4) NOT NULL DEFAULT '0',
  `user` varchar(20) NOT NULL DEFAULT '',
  `datum` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip` varchar(20) NOT NULL DEFAULT '',
  `txt` text NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `datesearch` (`datum`,`user`) USING BTREE,
  KEY `usersearch` (`user`,`datum`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dd_reference`
--

DROP TABLE IF EXISTS `dd_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dd_reference` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dd_id` int(11) NOT NULL DEFAULT '0',
  `datastore` varchar(25) NOT NULL DEFAULT '',
  `rootReference` tinyint(4) NOT NULL DEFAULT '0',
  `description` varchar(127) NOT NULL DEFAULT '',
  `keywords` text NOT NULL,
  `securitylevel` tinyint(4) NOT NULL DEFAULT '5',
  `module` varchar(40) NOT NULL DEFAULT '' COMMENT 'tablename for linked id',
  `module_id` int(11) NOT NULL DEFAULT '0' COMMENT 'id of item in the module defined table',
  `filename` varchar(60) NOT NULL DEFAULT '',
  `filesize` int(11) NOT NULL DEFAULT '0',
  `filetype` varchar(50) NOT NULL DEFAULT '',
  `categorie` varchar(60) NOT NULL DEFAULT '',
  `portaalKoppelId` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `quater` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `clientID` int(11) NOT NULL,
  `reportDate` date NOT NULL,
  `hash` varchar(50) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `moduleId` (`module`,`module_id`) USING BTREE,
  KEY `portaalId` (`portaalKoppelId`) USING BTREE,
  FULLTEXT KEY `search` (`description`,`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `degiroTransactieCodes`
--

DROP TABLE IF EXISTS `degiroTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `degiroTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `giroCode` varchar(10) NOT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `doorkijk_categoriePerVermogensbeheerder`
--

DROP TABLE IF EXISTS `doorkijk_categoriePerVermogensbeheerder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doorkijk_categoriePerVermogensbeheerder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `doorkijkCategoriesoort` varchar(60) DEFAULT NULL,
  `doorkijkCategorie` varchar(60) DEFAULT NULL,
  `afdrukVolgorde` tinyint(4) DEFAULT NULL,
  `grafiekKleur` varchar(60) DEFAULT NULL,
  `min` double NOT NULL,
  `max` double NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Vermogensbeheerder` (`Vermogensbeheerder`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `doorkijk_categorieWegingenPerFonds`
--

DROP TABLE IF EXISTS `doorkijk_categorieWegingenPerFonds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doorkijk_categorieWegingenPerFonds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `datumVanaf` date NOT NULL,
  `Fonds` varchar(60) NOT NULL,
  `ISINCode` varchar(12) NOT NULL,
  `msCategoriesoort` varchar(60) DEFAULT NULL,
  `msCategorie` varchar(60) DEFAULT NULL,
  `Valuta` varchar(3) NOT NULL,
  `weging` double DEFAULT NULL,
  `datumProvider` date NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Fonds` (`Fonds`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3218794 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `doorkijk_koppelingPerVermogensbeheerder`
--

DROP TABLE IF EXISTS `doorkijk_koppelingPerVermogensbeheerder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doorkijk_koppelingPerVermogensbeheerder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `Vermogensbeheerder` varchar(10) NOT NULL,
  `systeem` varchar(4) NOT NULL,
  `doorkijkCategoriesoort` varchar(60) DEFAULT NULL,
  `doorkijkCategorie` varchar(60) DEFAULT NULL,
  `bronKoppeling` varchar(60) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Vermogensbeheerder` (`Vermogensbeheerder`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `doorkijk_looptijd`
--

DROP TABLE IF EXISTS `doorkijk_looptijd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doorkijk_looptijd` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `code` varchar(10) DEFAULT NULL,
  `van` int(11) DEFAULT NULL,
  `tot` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `doorkijk_msCategoriesoort`
--

DROP TABLE IF EXISTS `doorkijk_msCategoriesoort`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doorkijk_msCategoriesoort` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `msCategoriesoort` varchar(60) DEFAULT NULL,
  `msCategorie` varchar(60) DEFAULT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `grafiekKleur` text NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `msCategoriesoort` (`msCategoriesoort`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=95 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `eDossierQueue`
--

DROP TABLE IF EXISTS `eDossierQueue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eDossierQueue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `portefeuille` varchar(26) NOT NULL DEFAULT '',
  `filename` varchar(60) NOT NULL DEFAULT '',
  `filesize` int(11) NOT NULL DEFAULT '0',
  `filetype` varchar(50) NOT NULL DEFAULT '',
  `categorie` varchar(60) NOT NULL DEFAULT '',
  `description` varchar(127) NOT NULL DEFAULT '',
  `keywords` text NOT NULL,
  `module` varchar(40) NOT NULL DEFAULT '',
  `module_id` int(11) NOT NULL DEFAULT '0',
  `blobdata` mediumblob NOT NULL,
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `portefeuille` (`portefeuille`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `emailLog`
--

DROP TABLE IF EXISTS `emailLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emailLog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zender` varchar(150) NOT NULL DEFAULT '',
  `ontvangers` varchar(255) NOT NULL,
  `onderwerp` varchar(150) NOT NULL DEFAULT '',
  `verzonden` tinyint(4) NOT NULL DEFAULT '0',
  `vanaf` varchar(50) NOT NULL DEFAULT '',
  `foutmelding` varchar(200) NOT NULL DEFAULT '',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `body` text NOT NULL,
  `bijlagen` varchar(200) NOT NULL,
  `cc` varchar(255) NOT NULL,
  `bcc` varchar(255) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `add_date` (`add_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `emailQueue`
--

DROP TABLE IF EXISTS `emailQueue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emailQueue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `crmId` int(11) NOT NULL DEFAULT '0',
  `status` varchar(20) NOT NULL DEFAULT '',
  `senderName` varchar(100) NOT NULL DEFAULT '',
  `senderEmail` varchar(255) NOT NULL,
  `receiverName` varchar(100) NOT NULL DEFAULT '',
  `receiverEmail` varchar(255) NOT NULL,
  `subject` varchar(200) NOT NULL DEFAULT '',
  `bodyHtml` mediumtext NOT NULL,
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `ccEmail` varchar(100) NOT NULL DEFAULT '',
  `bccEmail` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `crmId` (`crmId`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `emailQueueAttachments`
--

DROP TABLE IF EXISTS `emailQueueAttachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emailQueueAttachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emailQueueId` int(11) NOT NULL DEFAULT '0',
  `filename` varchar(200) NOT NULL DEFAULT '',
  `attachment` mediumblob NOT NULL,
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `emailQueueId` (`emailQueueId`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `emittentPerFonds`
--

DROP TABLE IF EXISTS `emittentPerFonds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emittentPerFonds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emittent` varchar(15) DEFAULT NULL,
  `fonds` varchar(25) DEFAULT NULL,
  `vermogensbeheerder` varchar(10) DEFAULT NULL,
  `rekenmethode` int(11) NOT NULL DEFAULT '0',
  `percentage` double NOT NULL DEFAULT '0',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `depotbank` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Fonds` (`fonds`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `emittenten`
--

DROP TABLE IF EXISTS `emittenten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emittenten` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emittent` varchar(15) DEFAULT NULL,
  `naam` varchar(50) NOT NULL DEFAULT '',
  `adres` varchar(25) NOT NULL DEFAULT '',
  `woonplaats` varchar(15) NOT NULL DEFAULT '',
  `telefoon` varchar(15) NOT NULL DEFAULT '',
  `fax` varchar(15) NOT NULL DEFAULT '',
  `email` varchar(25) NOT NULL DEFAULT '',
  `contactpersoon` varchar(25) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `rating` varchar(26) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `emittent` (`emittent`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=199 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `externeOrders`
--

DROP TABLE IF EXISTS `externeOrders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `externeOrders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `externOrderId` varchar(40) NOT NULL,
  `ISIN` varchar(12) NOT NULL,
  `valuta` varchar(3) NOT NULL,
  `fonds` varchar(25) NOT NULL,
  `aantal` double NOT NULL,
  `datum` date NOT NULL,
  `settlementdatum` date NOT NULL,
  `beurs` varchar(30) NOT NULL,
  `uitvoeringskoers` double NOT NULL,
  `verwerkt` tinyint(4) NOT NULL,
  `nettobedrag` double NOT NULL,
  `executor` varchar(15) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `externeQueries`
--

DROP TABLE IF EXISTS `externeQueries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `externeQueries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titel` varchar(100) NOT NULL DEFAULT '',
  `omschrijving` varchar(255) NOT NULL DEFAULT '',
  `query` mediumtext NOT NULL,
  `homeOnly` tinyint(4) NOT NULL DEFAULT '0',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `categorie` varchar(30) NOT NULL,
  `memo` text NOT NULL,
  `run_date` datetime NOT NULL,
  `run_user` varchar(10) NOT NULL,
  `frequentie` tinyint(3) NOT NULL,
  `controlekolommen` tinyint(4) NOT NULL,
  `autoVanaf` date NOT NULL DEFAULT '0000-00-00',
  `autoLaatste` date NOT NULL DEFAULT '0000-00-00',
  `autoEmailadres` varchar(150) NOT NULL DEFAULT '',
  `autoVanafUur` tinyint(3) NOT NULL,
  `uitvoer` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `externeQueryCategorien`
--

DROP TABLE IF EXISTS `externeQueryCategorien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `externeQueryCategorien` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categorie` varchar(30) NOT NULL DEFAULT '',
  `omschrijving` varchar(100) NOT NULL DEFAULT '',
  `volgorde` tinyint(3) NOT NULL DEFAULT '0',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `facmod_abonnement`
--

DROP TABLE IF EXISTS `facmod_abonnement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `facmod_abonnement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `aantal` decimal(8,2) NOT NULL,
  `eenheid` varchar(10) NOT NULL,
  `artnr` varchar(50) NOT NULL,
  `txt` text NOT NULL,
  `btw` char(2) NOT NULL,
  `totaal_excl` decimal(8,2) NOT NULL,
  `stuksprijs` decimal(8,2) NOT NULL,
  `volgnr` int(11) NOT NULL,
  `vorigeVerwerkdatum` datetime NOT NULL,
  `door` varchar(15) NOT NULL,
  `actief` varchar(1) NOT NULL,
  `periode` varchar(1) NOT NULL,
  `opmerking` text NOT NULL,
  `factor` int(11) NOT NULL,
  `rubriek` varchar(50) NOT NULL,
  `achteraf` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `facmod_artikel`
--

DROP TABLE IF EXISTS `facmod_artikel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `facmod_artikel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `artnr` varchar(50) NOT NULL,
  `omschrijving` tinytext NOT NULL,
  `eenheid` varchar(10) NOT NULL,
  `btw` varchar(2) NOT NULL,
  `stuksprijs` double NOT NULL,
  `rubriek` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `facmod_factuurregels`
--

DROP TABLE IF EXISTS `facmod_factuurregels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `facmod_factuurregels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `aantal` decimal(8,2) NOT NULL,
  `eenheid` varchar(10) NOT NULL,
  `artnr` varchar(10) NOT NULL,
  `txt` text NOT NULL,
  `btw` char(2) NOT NULL,
  `btw_per` decimal(4,2) NOT NULL,
  `totaal_excl` decimal(9,2) NOT NULL,
  `totaal_incl` decimal(9,2) NOT NULL,
  `stuksprijs` decimal(8,2) NOT NULL,
  `volgnr` int(11) NOT NULL,
  `vorigeVerwerkdatum` datetime NOT NULL,
  `door` varchar(15) NOT NULL,
  `actief` varchar(1) NOT NULL,
  `periode` varchar(1) NOT NULL,
  `opmerking` text NOT NULL,
  `factor` int(11) NOT NULL,
  `wachtstand` tinyint(4) NOT NULL,
  `facnr` int(11) NOT NULL,
  `datum` datetime NOT NULL,
  `afdeling` varchar(10) NOT NULL,
  `auto` varchar(1) NOT NULL,
  `module` varchar(20) NOT NULL,
  `module_id` varchar(20) NOT NULL,
  `inkoopstuksprijs` decimal(9,2) NOT NULL,
  `inkooptotaal_excl` decimal(9,2) NOT NULL,
  `inkooptotaal_incl` decimal(9,2) NOT NULL,
  `rubriek` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `factorVanafDatum`
--

DROP TABLE IF EXISTS `factorVanafDatum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factorVanafDatum` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fonds` varchar(25) DEFAULT NULL,
  `datum` datetime DEFAULT NULL,
  `factor` double NOT NULL DEFAULT '1',
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `fonds` (`fonds`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feehistorie`
--

DROP TABLE IF EXISTS `feehistorie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feehistorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `portefeuille` varchar(24) NOT NULL,
  `datum` datetime DEFAULT NULL,
  `portfoliowaarde` double NOT NULL DEFAULT '0',
  `highwatermark` double NOT NULL DEFAULT '0',
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `portefeuille` (`portefeuille`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fixDepotbankenPerVermogensbeheerder`
--

DROP TABLE IF EXISTS `fixDepotbankenPerVermogensbeheerder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fixDepotbankenPerVermogensbeheerder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) NOT NULL,
  `change_date` datetime NOT NULL,
  `add_user` varchar(10) NOT NULL,
  `add_date` datetime NOT NULL,
  `vermogensbeheerder` varchar(10) DEFAULT '',
  `depotbank` varchar(10) DEFAULT '',
  `rekeningNrTonen` tinyint(3) NOT NULL,
  `meervoudigViaFix` tinyint(3) NOT NULL,
  `nominaalViaFix` tinyint(3) NOT NULL,
  `fixDefaultAan` tinyint(3) NOT NULL,
  `careOrderVerplicht` tinyint(3) NOT NULL DEFAULT '0',
  `meervNominaalFIX` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `vmdb` (`vermogensbeheerder`,`depotbank`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fixOrders`
--

DROP TABLE IF EXISTS `fixOrders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fixOrders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) NOT NULL,
  `change_date` datetime NOT NULL,
  `add_user` varchar(10) NOT NULL,
  `add_date` datetime NOT NULL,
  `portefeuille` varchar(25) NOT NULL,
  `client` varchar(50) NOT NULL,
  `rekeningnr` varchar(30) NOT NULL,
  `vermogensBeheerder` varchar(20) NOT NULL,
  `orderid` int(11) NOT NULL,
  `aantal` double NOT NULL,
  `fondsCode` varchar(20) NOT NULL,
  `fonds` varchar(30) NOT NULL,
  `fondsOmschrijving` varchar(70) NOT NULL,
  `transactieType` varchar(6) NOT NULL,
  `transactieSoort` varchar(6) NOT NULL,
  `tijdsLimiet` date NOT NULL,
  `tijdsSoort` varchar(6) NOT NULL,
  `koersLimiet` double NOT NULL,
  `status` text NOT NULL,
  `laatsteStatus` varchar(25) NOT NULL,
  `Depotbank` varchar(10) NOT NULL,
  `uitvoeringsPrijs` double NOT NULL,
  `uitvoeringsDatum` date NOT NULL,
  `aantalUitgevoerd` double NOT NULL,
  `meldingen` text NOT NULL,
  `verwerkt` tinyint(4) NOT NULL,
  `verwerktStamp` datetime NOT NULL,
  `verwerktResult` varchar(20) NOT NULL,
  `bankfondsCode` varchar(20) NOT NULL,
  `DepotbankOrderId` varchar(20) NOT NULL,
  `AIRSorderReference` int(11) NOT NULL,
  `FIXRecordArray` text NOT NULL,
  `AIRS_bedrijf` varchar(16) NOT NULL,
  `no_legs` int(11) NOT NULL,
  `legs` text NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `AIRSorderReference` (`AIRSorderReference`) USING BTREE,
  KEY `orderid` (`orderid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fondsOptieSymbolen`
--

DROP TABLE IF EXISTS `fondsOptieSymbolen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fondsOptieSymbolen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `key` varchar(5) NOT NULL,
  `Fonds` varchar(25) NOT NULL,
  `aantal` double NOT NULL,
  `optieValuta` varchar(4) NOT NULL,
  `optieBeurs` varchar(4) NOT NULL,
  `optieVWD` varchar(80) NOT NULL DEFAULT '',
  `optieAABCode` varchar(26) NOT NULL DEFAULT '',
  `optieaabbeCode` varchar(26) NOT NULL DEFAULT '',
  `optiestroeveCode` varchar(26) NOT NULL DEFAULT '',
  `optiekasbankCode` varchar(26) NOT NULL DEFAULT '',
  `optiebinckCode` varchar(26) NOT NULL DEFAULT '',
  `optiesnsSecCode` varchar(26) NOT NULL DEFAULT '',
  `optieVWDSuffix` varchar(5) NOT NULL DEFAULT '',
  `optieVWDFactor` int(5) NOT NULL DEFAULT '1',
  `optieSAXOcode` varchar(26) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Fonds` (`Fonds`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=921 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fondsTurboSymbolen`
--

DROP TABLE IF EXISTS `fondsTurboSymbolen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fondsTurboSymbolen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `Fonds` varchar(25) NOT NULL,
  `short` varchar(15) NOT NULL,
  `long` varchar(25) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Fonds` (`Fonds`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fondsenOptiestatistieken`
--

DROP TABLE IF EXISTS `fondsenOptiestatistieken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fondsenOptiestatistieken` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fonds` varchar(25) NOT NULL,
  `datum` date DEFAULT '0000-00-00',
  `delta` double NOT NULL DEFAULT '0',
  `omega` double NOT NULL DEFAULT '0',
  `theta` double NOT NULL DEFAULT '0',
  `vega` double NOT NULL DEFAULT '0',
  `gamma` double NOT NULL DEFAULT '0',
  `rho` double NOT NULL DEFAULT '0',
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `fonds` (`fonds`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fondskoersAanvragen`
--

DROP TABLE IF EXISTS `fondskoersAanvragen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fondskoersAanvragen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Fonds` varchar(25) DEFAULT NULL,
  `Datum` datetime DEFAULT NULL,
  `Koers` double DEFAULT NULL,
  `emailAdres` varchar(50) NOT NULL DEFAULT '',
  `verwerkt` tinyint(3) NOT NULL DEFAULT '0',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Fonds` (`Fonds`) USING BTREE,
  KEY `change_date` (`change_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fondskosten`
--

DROP TABLE IF EXISTS `fondskosten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fondskosten` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fonds` varchar(25) DEFAULT NULL,
  `datum` datetime DEFAULT NULL,
  `percentage` double DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `datumProvider` date NOT NULL,
  `handmatig` tinyint(3) NOT NULL,
  `opmerking` varchar(255) NOT NULL,
  `transCostFund` double NOT NULL,
  `perfFeeFund` double NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `fonds` (`fonds`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=153916 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `grootboeknummers`
--

DROP TABLE IF EXISTS `grootboeknummers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grootboeknummers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vermogensbeheerder` varchar(10) NOT NULL DEFAULT '',
  `grootboekrekening` varchar(5) DEFAULT NULL,
  `rekeningnummer` varchar(10) NOT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `omschrijving` varchar(50) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `vermogensbeheerder` (`vermogensbeheerder`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gsTransactieCodes`
--

DROP TABLE IF EXISTS `gsTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gsTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `bankCode` varchar(10) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `handleidingenAIRS`
--

DROP TABLE IF EXISTS `handleidingenAIRS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `handleidingenAIRS` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titel` varchar(120) NOT NULL,
  `informatie` text NOT NULL,
  `categorie` varchar(60) NOT NULL,
  `bijlage` mediumblob NOT NULL,
  `publiceer` tinyint(4) NOT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `documentType` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `help_tekst`
--

DROP TABLE IF EXISTS `help_tekst`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `help_tekst` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titel` varchar(150) NOT NULL DEFAULT '',
  `url` varchar(150) NOT NULL DEFAULT '',
  `txt` text,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `titel` (`titel`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `help_velden`
--

DROP TABLE IF EXISTS `help_velden`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `help_velden` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `veld` varchar(150) NOT NULL DEFAULT '',
  `txt` text,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `veld` (`veld`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `hhbTransactieCodes`
--

DROP TABLE IF EXISTS `hhbTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hhbTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `bankCode` varchar(10) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `historischeTenaamstelling`
--

DROP TABLE IF EXISTS `historischeTenaamstelling`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `historischeTenaamstelling` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientId` int(11) NOT NULL DEFAULT '0',
  `crmId` int(11) NOT NULL DEFAULT '0',
  `Naam` varchar(100) DEFAULT NULL,
  `Naam1` varchar(100) DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `geldigTot` date NOT NULL DEFAULT '0000-00-00',
  `adres` varchar(50) NOT NULL DEFAULT '',
  `pc` varchar(17) NOT NULL DEFAULT '',
  `woonplaats` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `clientId` (`clientId`) USING BTREE,
  KEY `crmId` (`crmId`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `hsbcTransactieCodes`
--

DROP TABLE IF EXISTS `hsbcTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hsbcTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `HSBCcode` varchar(20) NOT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `importAfwijkingen`
--

DROP TABLE IF EXISTS `importAfwijkingen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `importAfwijkingen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `depotbank` varchar(10) NOT NULL,
  `vermogensBeheerder` varchar(10) NOT NULL,
  `actief` tinyint(4) NOT NULL,
  `functie` varchar(50) NOT NULL,
  `subInFunctie` varchar(50) NOT NULL,
  `testVeld` varchar(50) NOT NULL,
  `testConditie` varchar(50) NOT NULL,
  `targetVeld` varchar(50) NOT NULL,
  `targetWaarde` varchar(50) NOT NULL,
  `prio` int(11) NOT NULL,
  `memo` text NOT NULL,
  `testSoort` varchar(20) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `importZoekVervang`
--

DROP TABLE IF EXISTS `importZoekVervang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `importZoekVervang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `depotbank` varchar(10) NOT NULL,
  `vermogensBeheerder` varchar(10) NOT NULL,
  `actief` tinyint(4) NOT NULL,
  `zoek` varchar(100) NOT NULL,
  `vervang` varchar(100) NOT NULL,
  `typeVervang` varchar(20) NOT NULL,
  `veldAanduiding` text NOT NULL,
  `prio` int(11) NOT NULL,
  `memo` text NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inflatiepercentages`
--

DROP TABLE IF EXISTS `inflatiepercentages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inflatiepercentages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jaar` date DEFAULT '0000-00-00',
  `percentage` double NOT NULL DEFAULT '0',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `vermogensbeheerder` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `vermogensbeheerder` (`vermogensbeheerder`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ingTransactieCodes`
--

DROP TABLE IF EXISTS `ingTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `INGcode` varchar(10) NOT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `invulInstructies`
--

DROP TABLE IF EXISTS `invulInstructies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invulInstructies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `vermogensBeheerder` varchar(20) NOT NULL,
  `script` varchar(50) NOT NULL,
  `field` varchar(50) NOT NULL,
  `value` varchar(50) NOT NULL,
  `active` tinyint(4) NOT NULL,
  `header` text NOT NULL,
  `text` text NOT NULL,
  `class` varchar(30) NOT NULL,
  `memo` text NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `jbTransactieCodes`
--

DROP TABLE IF EXISTS `jbTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jbTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `JBcode` varchar(10) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `jbluxTransactieCodes`
--

DROP TABLE IF EXISTS `jbluxTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jbluxTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `bankCode` varchar(20) NOT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `jpmTransactieCodes`
--

DROP TABLE IF EXISTS `jpmTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jpmTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `bankCode` varchar(20) NOT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kasBankTransactieCodes`
--

DROP TABLE IF EXISTS `kasBankTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kasBankTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `kasbankCode` varchar(10) NOT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  `actieAlternatief` varchar(10) NOT NULL,
  `portefeuillesAltActies` text NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kbcTransactieCodes`
--

DROP TABLE IF EXISTS `kbcTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kbcTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `bankCode` varchar(10) NOT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `klantMutaties`
--

DROP TABLE IF EXISTS `klantMutaties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `klantMutaties` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tabel` varchar(50) NOT NULL DEFAULT '',
  `recordId` bigint(20) NOT NULL DEFAULT '0',
  `veld` varchar(50) NOT NULL DEFAULT '',
  `oudeWaarde` varchar(255) NOT NULL DEFAULT '',
  `nieuweWaarde` varchar(255) NOT NULL DEFAULT '',
  `verwerkt` tinyint(3) NOT NULL DEFAULT '0',
  `Vermogensbeheerder` varchar(10) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(15) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(15) NOT NULL DEFAULT '',
  `emailAdres` varchar(50) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `knoxTransactieCodes`
--

DROP TABLE IF EXISTS `knoxTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `knoxTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `bankCode` varchar(50) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `laatstePortefeuilleWaarde`
--

DROP TABLE IF EXISTS `laatstePortefeuilleWaarde`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `laatstePortefeuilleWaarde` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `portefeuille` varchar(24) NOT NULL,
  `laatsteWaarde` double DEFAULT NULL,
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `rendement` double NOT NULL DEFAULT '0',
  `beginWaarde` double NOT NULL DEFAULT '0',
  `Stortingen` double NOT NULL DEFAULT '0',
  `Onttrekkingen` double NOT NULL DEFAULT '0',
  `Opbrengsten` double NOT NULL DEFAULT '0',
  `Kosten` double NOT NULL DEFAULT '0',
  `gerealiseerd` double NOT NULL DEFAULT '0',
  `ongerealiseerd` double NOT NULL DEFAULT '0',
  `mutatieOpgelopenRente` double NOT NULL DEFAULT '0',
  `afmstdev` double NOT NULL DEFAULT '0',
  `zorgMeting` varchar(50) NOT NULL DEFAULT '',
  `kansOpDoelvermogen` double NOT NULL DEFAULT '0',
  `toelichting` varchar(200) NOT NULL,
  `BEH` double NOT NULL,
  `BEW` double NOT NULL,
  `KNBA` double NOT NULL,
  `KOBU` double NOT NULL,
  `KOST` double NOT NULL,
  `ROER` double NOT NULL,
  `TOB` double NOT NULL,
  `DIV` double NOT NULL,
  `VTRES` double NOT NULL,
  `HUUR` double NOT NULL,
  `VMAR` double NOT NULL,
  `VKSTO` double NOT NULL,
  `RENTE` double NOT NULL,
  `RENOB` double NOT NULL,
  `RENME` double NOT NULL,
  `DIVBE` double NOT NULL,
  `OG` double NOT NULL,
  `omzet` double NOT NULL DEFAULT '0',
  `gemVermogen` double NOT NULL DEFAULT '0',
  `omzetsnelheid` double NOT NULL DEFAULT '0',
  `rendementModel` double NOT NULL,
  `benchmarkRendement` double NOT NULL DEFAULT '0',
  `vkm` double NOT NULL DEFAULT '0',
  `vkmDoorlKst` double NOT NULL DEFAULT '0',
  `vkmDirK` double NOT NULL DEFAULT '0',
  `saldoGeldrek` double NOT NULL DEFAULT '0',
  `rapportageDatum` date NOT NULL,
  `rendementQTD` double NOT NULL,
  `rendementMTD` double NOT NULL,
  `ptfSignMethode` varchar(3) NOT NULL,
  `SignRapDatumRend` double NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `portefeuille` (`portefeuille`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=30326 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `laatstePortefeuilleWaardeQueue`
--

DROP TABLE IF EXISTS `laatstePortefeuilleWaardeQueue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `laatstePortefeuilleWaardeQueue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `portefeuille` varchar(25) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `pid` int(11) NOT NULL,
  `change_user` varchar(10) NOT NULL,
  `change_date` datetime NOT NULL,
  `add_user` varchar(10) NOT NULL,
  `add_date` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `portefeuille` (`portefeuille`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lanschotTransactieCodes`
--

DROP TABLE IF EXISTS `lanschotTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lanschotTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `FVLCode` varchar(10) NOT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lombardTransactieCodes`
--

DROP TABLE IF EXISTS `lombardTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lombardTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `LOMcode` varchar(25) NOT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lynxTransactieCodes`
--

DROP TABLE IF EXISTS `lynxTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lynxTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `LYNXcode` varchar(10) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `millogic_fondsparameters`
--

DROP TABLE IF EXISTS `millogic_fondsparameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `millogic_fondsparameters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `fonds` varchar(25) NOT NULL,
  `isShare` tinyint(4) NOT NULL,
  `nlFonds` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `millogic_rekeningen`
--

DROP TABLE IF EXISTS `millogic_rekeningen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `millogic_rekeningen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `rekening` varchar(25) NOT NULL,
  `nietParticulier` tinyint(4) NOT NULL,
  `rekeningZonderKosten` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `millogic_transactieMapping`
--

DROP TABLE IF EXISTS `millogic_transactieMapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `millogic_transactieMapping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `depotbank` varchar(15) NOT NULL,
  `bankcode` varchar(15) NOT NULL,
  `Millogic` varchar(6) NOT NULL,
  `omschrijving` varchar(60) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `modelPortefeuillesPerModelPortefeuille`
--

DROP TABLE IF EXISTS `modelPortefeuillesPerModelPortefeuille`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modelPortefeuillesPerModelPortefeuille` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vermogensbeheerder` varchar(10) NOT NULL DEFAULT '',
  `modelPortefeuille` varchar(24) NOT NULL,
  `modelPortefeuilleComponent` varchar(24) NOT NULL,
  `percentage` double NOT NULL DEFAULT '0',
  `vanaf` date NOT NULL DEFAULT '0000-00-00',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `modelPortefeuille` (`modelPortefeuille`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `modulezTijdelijkeBatch`
--

DROP TABLE IF EXISTS `modulezTijdelijkeBatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modulezTijdelijkeBatch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `batch` varchar(25) NOT NULL,
  `portefeuille` varchar(35) NOT NULL,
  `bedragVrijmaken` double NOT NULL,
  `record` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `modulezTransactieCodes`
--

DROP TABLE IF EXISTS `modulezTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modulezTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `code` varchar(10) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `module` varchar(50) NOT NULL,
  `message` tinytext NOT NULL,
  `module_id` int(11) NOT NULL,
  `ttl` varchar(25) NOT NULL,
  `usr` varchar(5) NOT NULL,
  `type` varchar(25) DEFAULT NULL,
  `seen` int(1) NOT NULL,
  `ttl_date` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `see` (`seen`,`ttl_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `optTransactieCodes`
--

DROP TABLE IF EXISTS `optTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `optTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `OPTcode` varchar(10) NOT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `orderLogs`
--

DROP TABLE IF EXISTS `orderLogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orderLogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `timeOffset` varchar(4) NOT NULL,
  `logLevel` tinyint(4) NOT NULL,
  `orderRecordId` int(11) NOT NULL,
  `fixRecordId` int(11) NOT NULL,
  `bulkorderRecordId` int(11) NOT NULL,
  `message` tinytext NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `orderRecordId` (`orderRecordId`) USING BTREE,
  KEY `fixRecordId` (`fixRecordId`) USING BTREE,
  KEY `bulkorderRecordId` (`bulkorderRecordId`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `orderkosten`
--

DROP TABLE IF EXISTS `orderkosten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orderkosten` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vermogensbeheerder` varchar(10) NOT NULL DEFAULT '',
  `fondssoort` varchar(8) DEFAULT NULL,
  `kostenpercentage` double NOT NULL DEFAULT '0',
  `kostenminimumbedrag` double NOT NULL DEFAULT '0',
  `brokerkostenpercentage` double NOT NULL DEFAULT '0',
  `brokerkostenminimumbedrag` double NOT NULL DEFAULT '0',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `portefeuille` varchar(24) NOT NULL,
  `prijsPerStuk` double NOT NULL DEFAULT '0',
  `beursregio` varchar(4) NOT NULL,
  `transactievorm` varchar(1) NOT NULL,
  `valuta` varchar(4) NOT NULL,
  `berekenwijze` tinyint(3) NOT NULL,
  `staffel1` double NOT NULL,
  `staffel2` double NOT NULL,
  `staffel3` double NOT NULL,
  `staffel4` double NOT NULL,
  `staffel5` double NOT NULL,
  `staffelPercentage1` double NOT NULL,
  `staffelPercentage2` double NOT NULL,
  `staffelPercentage3` double NOT NULL,
  `staffelPercentage4` double NOT NULL,
  `staffelPercentage5` double NOT NULL,
  `prijsPerStukBroker` double NOT NULL,
  `factorCHF` double NOT NULL,
  `factorGBP` double NOT NULL,
  `factorUSD` double NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `vermogensbeheerderBelcat` (`vermogensbeheerder`,`fondssoort`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `participanten`
--

DROP TABLE IF EXISTS `participanten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `participanten` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `fonds_fonds` varchar(25) NOT NULL,
  `crm_id` int(11) NOT NULL,
  `registration_number` varchar(45) NOT NULL,
  `memo` text NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `participantenFondsVerloop`
--

DROP TABLE IF EXISTS `participantenFondsVerloop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `participantenFondsVerloop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `participanten_id` int(11) NOT NULL,
  `datum` date NOT NULL,
  `transactietype` varchar(5) NOT NULL,
  `aantal` double NOT NULL,
  `koers` double NOT NULL,
  `omschrijving` text NOT NULL,
  `print_date` datetime NOT NULL,
  `waarde` double NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pdfTemplateAfbeelding`
--

DROP TABLE IF EXISTS `pdfTemplateAfbeelding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pdfTemplateAfbeelding` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `templateFile` varchar(255) DEFAULT NULL,
  `pagina` tinyint(4) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `x` int(11) DEFAULT NULL,
  `y` int(11) DEFAULT NULL,
  `imageWidth` int(11) DEFAULT NULL,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pdfTemplateText`
--

DROP TABLE IF EXISTS `pdfTemplateText`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pdfTemplateText` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `templateFile` varchar(255) DEFAULT NULL,
  `pagina` tinyint(4) DEFAULT NULL,
  `tekst` mediumblob,
  `fontName` varchar(100) DEFAULT NULL,
  `fontSize` tinyint(4) DEFAULT NULL,
  `fontStyle` varchar(1) DEFAULT NULL,
  `lineHeight` tinyint(4) DEFAULT NULL,
  `lineAlign` varchar(1) DEFAULT NULL,
  `lineBorder` tinyint(4) DEFAULT NULL,
  `lineWidth` int(11) DEFAULT NULL,
  `x` int(11) DEFAULT NULL,
  `y` int(11) DEFAULT NULL,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pictetTransactieCodes`
--

DROP TABLE IF EXISTS `pictetTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pictetTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `PICcode` varchar(10) NOT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `portaalQueue`
--

DROP TABLE IF EXISTS `portaalQueue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portaalQueue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `crmId` int(11) NOT NULL DEFAULT '0',
  `status` varchar(20) NOT NULL DEFAULT '',
  `periode` varchar(1) NOT NULL DEFAULT '',
  `raportageDatum` date NOT NULL DEFAULT '0000-00-00',
  `portefeuille` varchar(24) NOT NULL,
  `email` varchar(100) NOT NULL,
  `crmWachtwoord` varchar(100) NOT NULL,
  `naam` varchar(100) NOT NULL DEFAULT '',
  `naam1` varchar(100) NOT NULL DEFAULT '',
  `filename` varchar(200) NOT NULL DEFAULT '',
  `pdfData` mediumblob NOT NULL,
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `verzendAanhef` varchar(255) NOT NULL,
  `accountmanagerNaam` varchar(75) NOT NULL,
  `accountmanagerGebruikerNaam` varchar(50) NOT NULL,
  `accountmanagerEmail` varchar(50) NOT NULL,
  `pdfFactuurData` mediumblob NOT NULL,
  `depotbank` varchar(10) NOT NULL,
  `accountmanagerTelefoon` varchar(20) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `portefeuilleClusters`
--

DROP TABLE IF EXISTS `portefeuilleClusters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portefeuilleClusters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vermogensbeheerder` varchar(10) NOT NULL DEFAULT '',
  `cluster` varchar(24) NOT NULL,
  `clusterOmschrijving` varchar(75) NOT NULL,
  `portefeuille1` varchar(24) NOT NULL,
  `portefeuille2` varchar(24) NOT NULL,
  `portefeuille3` varchar(24) NOT NULL,
  `portefeuille4` varchar(24) NOT NULL,
  `portefeuille5` varchar(24) NOT NULL,
  `portefeuille6` varchar(24) NOT NULL,
  `portefeuille7` varchar(24) NOT NULL,
  `portefeuille8` varchar(24) NOT NULL,
  `portefeuille9` varchar(24) NOT NULL,
  `portefeuille10` varchar(24) NOT NULL,
  `portefeuille11` varchar(24) NOT NULL DEFAULT '',
  `portefeuille12` varchar(24) NOT NULL DEFAULT '',
  `portefeuille13` varchar(24) NOT NULL DEFAULT '',
  `portefeuille14` varchar(24) NOT NULL DEFAULT '',
  `portefeuille15` varchar(24) NOT NULL DEFAULT '',
  `portefeuille16` varchar(24) NOT NULL DEFAULT '',
  `portefeuille17` varchar(24) NOT NULL DEFAULT '',
  `portefeuille18` varchar(24) NOT NULL DEFAULT '',
  `portefeuille19` varchar(24) NOT NULL DEFAULT '',
  `portefeuille20` varchar(24) NOT NULL DEFAULT '',
  `portefeuille21` varchar(24) NOT NULL DEFAULT '',
  `portefeuille22` varchar(24) NOT NULL DEFAULT '',
  `portefeuille23` varchar(24) NOT NULL DEFAULT '',
  `portefeuille24` varchar(24) NOT NULL DEFAULT '',
  `portefeuille25` varchar(24) NOT NULL DEFAULT '',
  `portefeuille26` varchar(24) NOT NULL DEFAULT '',
  `portefeuille27` varchar(24) NOT NULL DEFAULT '',
  `portefeuille28` varchar(24) NOT NULL DEFAULT '',
  `portefeuille29` varchar(24) NOT NULL DEFAULT '',
  `portefeuille30` varchar(24) NOT NULL DEFAULT '',
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `portaal` tinyint(1) NOT NULL,
  `emailAdres` varchar(50) NOT NULL,
  `wachtwoord` varchar(12) NOT NULL,
  `actief` tinyint(1) NOT NULL,
  `verzendAanhef` varchar(255) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `cluster` (`cluster`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `quintetTransactieCodes`
--

DROP TABLE IF EXISTS `quintetTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quintetTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `bankCode` varchar(26) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `raboTransactieCodes`
--

DROP TABLE IF EXISTS `raboTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `raboTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `bankCode` varchar(10) NOT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reconMonitor_matrix`
--

DROP TABLE IF EXISTS `reconMonitor_matrix`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reconMonitor_matrix` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `bedrijf` varchar(10) NOT NULL,
  `depotbank` varchar(20) NOT NULL,
  `datum` datetime NOT NULL,
  `verwerkt` tinyint(4) NOT NULL,
  `door` varchar(10) NOT NULL,
  `bestanden` tinyint(4) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `memo` text NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reconV3Log`
--

DROP TABLE IF EXISTS `reconV3Log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reconV3Log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `location` varchar(50) NOT NULL,
  `omschrijving` varchar(100) NOT NULL,
  `stamp` datetime NOT NULL,
  `batch` varchar(50) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reconV3_airsPile`
--

DROP TABLE IF EXISTS `reconV3_airsPile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reconV3_airsPile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `batch` varchar(30) NOT NULL,
  `eigenaar` varchar(30) NOT NULL,
  `portefeuille` varchar(65) NOT NULL,
  `bankCode` varchar(28) NOT NULL,
  `ISIN` varchar(28) NOT NULL,
  `valuta` varchar(10) NOT NULL,
  `koers` varchar(10) NOT NULL,
  `aantal` double NOT NULL,
  `isPositie` tinyint(4) NOT NULL,
  `memo` varchar(255) NOT NULL,
  `airsCode` varchar(45) NOT NULL,
  `afwPortefeuille` varchar(35) NOT NULL,
  `totaal` double NOT NULL,
  `portDepotbank` varchar(15) NOT NULL,
  `depotbank` varchar(15) NOT NULL,
  `Rekening` varchar(35) NOT NULL,
  `afwRekening` varchar(35) NOT NULL,
  `vermogensbeheerder` varchar(35) NOT NULL,
  `client` varchar(50) NOT NULL,
  `einddatum` date NOT NULL,
  `accountmanager` varchar(15) NOT NULL,
  `fondsImportcode` varchar(35) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reconV3_bankPile`
--

DROP TABLE IF EXISTS `reconV3_bankPile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reconV3_bankPile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `batch` varchar(30) NOT NULL,
  `eigenaar` varchar(30) NOT NULL,
  `portefeuille` varchar(65) NOT NULL,
  `bankCode` varchar(28) NOT NULL,
  `ISIN` varchar(28) NOT NULL,
  `valuta` varchar(10) NOT NULL,
  `aantal` double NOT NULL,
  `koers` double NOT NULL,
  `isPositie` tinyint(4) NOT NULL,
  `memo` varchar(255) NOT NULL,
  `airsCode` varchar(45) NOT NULL,
  `Airs_bankCode` varchar(45) NOT NULL,
  `Airs_ISIN` varchar(28) NOT NULL,
  `Airs_valuta` varchar(10) NOT NULL,
  `reconDatum` date NOT NULL,
  `koersDatum` date NOT NULL,
  `match` varchar(15) NOT NULL,
  `afwPortefeuille` varchar(35) NOT NULL,
  `bankFonds` varchar(50) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reportbuilder_ANONIEM`
--

DROP TABLE IF EXISTS `reportbuilder_ANONIEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reportbuilder_ANONIEM` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Rapport` varchar(20) NOT NULL,
  `Portefeuille` varchar(12) NOT NULL,
  `Vermogensbeheerder` varchar(10) NOT NULL,
  `Client` varchar(16) NOT NULL,
  `Naam` varchar(50) NOT NULL,
  `Naam1` varchar(50) NOT NULL,
  `Fonds` varchar(25) NOT NULL,
  `FondsOmschrijving` varchar(50) NOT NULL,
  `Kostprijs` double NOT NULL,
  `HistorischeWaarde` double NOT NULL,
  `AandeelBeleggingscategorie` double NOT NULL,
  `AandeelTotaalvermogen` double NOT NULL,
  `AandeelTotaalBelegdvermogen` double NOT NULL,
  `AantalInPortefeuille` int(11) NOT NULL,
  `add_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Portefeuille` (`Portefeuille`) USING BTREE,
  KEY `Fonds` (`Fonds`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reportbuilder_Asblank`
--

DROP TABLE IF EXISTS `reportbuilder_Asblank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reportbuilder_Asblank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Rapport` varchar(20) NOT NULL,
  `Portefeuille` varchar(24) NOT NULL,
  `Vermogensbeheerder` varchar(10) NOT NULL,
  `Client` varchar(16) NOT NULL,
  `Naam` varchar(50) NOT NULL,
  `Naam1` varchar(50) NOT NULL,
  `beginvermogen` double NOT NULL,
  `totaalvermogen` double NOT NULL,
  `stortingen` double NOT NULL,
  `onttrekkingen` double NOT NULL,
  `inprocenttotaal` double NOT NULL,
  `performance` double NOT NULL,
  `resultaat` double NOT NULL,
  `AFMstd` double NOT NULL,
  `BEGIN` double NOT NULL,
  `BEH` double NOT NULL,
  `BELK` double NOT NULL,
  `BEW` double NOT NULL,
  `BTLBR` double NOT NULL,
  `BTW` double NOT NULL,
  `BTWAU` double NOT NULL,
  `DIV` double NOT NULL,
  `DIVBE` double NOT NULL,
  `FDFEE` double NOT NULL,
  `FONDS` double NOT NULL,
  `HUUR` double NOT NULL,
  `KNBA` double NOT NULL,
  `KNOG` double NOT NULL,
  `KNOV` double NOT NULL,
  `KOBU` double NOT NULL,
  `KOST` double NOT NULL,
  `Kruis` double NOT NULL,
  `KSGP` double NOT NULL,
  `MEM` double NOT NULL,
  `MWBEL` double NOT NULL,
  `OG` double NOT NULL,
  `OGIF` double NOT NULL,
  `ONTTR` double NOT NULL,
  `PERF` double NOT NULL,
  `RENME` double NOT NULL,
  `RENOB` double NOT NULL,
  `RENTE` double NOT NULL,
  `ROER` double NOT NULL,
  `STORT` double NOT NULL,
  `TOB` double NOT NULL,
  `TOBO` double NOT NULL,
  `TVDIV` double NOT NULL,
  `UGIF` double NOT NULL,
  `UITK` double NOT NULL,
  `VALK` double NOT NULL,
  `VEBH` double NOT NULL,
  `VERM` double NOT NULL,
  `VKSTO` double NOT NULL,
  `VMAR` double NOT NULL,
  `VTRES` double NOT NULL,
  `WINPE` double NOT NULL,
  `liquiditeiten` double NOT NULL,
  `add_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Portefeuille` (`Portefeuille`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=94 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reportbuilder_Theo`
--

DROP TABLE IF EXISTS `reportbuilder_Theo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reportbuilder_Theo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Rapport` varchar(20) NOT NULL,
  `client` varchar(50) NOT NULL,
  `clientNaam` varchar(150) NOT NULL,
  `clientNaam1` varchar(150) NOT NULL,
  `clientAdres` varchar(150) NOT NULL,
  `clientPostcode` varchar(150) NOT NULL,
  `clientWoonplaats` varchar(150) NOT NULL,
  `clientTelefoon` varchar(150) NOT NULL,
  `clientFax` varchar(150) NOT NULL,
  `clientEmail` varchar(150) NOT NULL,
  `datumTot` date NOT NULL,
  `datumVan` date NOT NULL,
  `factuurNummer` varchar(50) NOT NULL,
  `Portefeuille` varchar(24) NOT NULL,
  `RapportageValuta` varchar(3) NOT NULL,
  `totaalWaardeVanaf` double NOT NULL,
  `totaalWaarde` double NOT NULL,
  `gemiddeldeVermogen` double NOT NULL,
  `maandsWaarde_1` double NOT NULL,
  `maandsWaarde_2` double NOT NULL,
  `maandsWaarde_3` double NOT NULL,
  `maandsGemiddelde` double NOT NULL,
  `beheerfeeOpJaarbasis` double NOT NULL,
  `performancefee` double NOT NULL,
  `administratieBedrag` double NOT NULL,
  `BeheerfeeTeruggaveHuisfondsenPercentage` double NOT NULL,
  `BeheerfeeRemisiervergoedingsPercentage` double NOT NULL,
  `totaalTransactie` double NOT NULL,
  `beheerfeeBetalen` double NOT NULL,
  `btw` double NOT NULL,
  `beheerfeeBetalenIncl` double NOT NULL,
  `stortingenOntrekkingen` double NOT NULL,
  `resultaat` double NOT NULL,
  `performancePeriode` double NOT NULL,
  `performanceJaar` double NOT NULL,
  `rekenvermogen` double NOT NULL,
  `BeheerfeePercentageVermogenDeelVanJaar` double NOT NULL,
  `add_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Portefeuille` (`Portefeuille`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reportbuilder_dprice`
--

DROP TABLE IF EXISTS `reportbuilder_dprice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reportbuilder_dprice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Rapport` varchar(20) NOT NULL,
  `Portefeuille` varchar(24) NOT NULL,
  `Vermogensbeheerder` varchar(10) NOT NULL,
  `Client` varchar(16) NOT NULL,
  `Naam` varchar(50) NOT NULL,
  `Naam1` varchar(50) NOT NULL,
  `beginvermogen` double NOT NULL,
  `totaalvermogen` double NOT NULL,
  `stortingen` double NOT NULL,
  `onttrekkingen` double NOT NULL,
  `inprocenttotaal` double NOT NULL,
  `performance` double NOT NULL,
  `resultaat` double NOT NULL,
  `AFMstd` double NOT NULL,
  `BEGIN` double NOT NULL,
  `BEH` double NOT NULL,
  `BELK` double NOT NULL,
  `BEW` double NOT NULL,
  `BTLBR` double NOT NULL,
  `BTW` double NOT NULL,
  `BTWAU` double NOT NULL,
  `DIV` double NOT NULL,
  `DIVBE` double NOT NULL,
  `FDFEE` double NOT NULL,
  `FONDS` double NOT NULL,
  `HUUR` double NOT NULL,
  `KNBA` double NOT NULL,
  `KNOG` double NOT NULL,
  `KNOV` double NOT NULL,
  `KOBU` double NOT NULL,
  `KOST` double NOT NULL,
  `Kruis` double NOT NULL,
  `KSGP` double NOT NULL,
  `MEM` double NOT NULL,
  `MWBEL` double NOT NULL,
  `OG` double NOT NULL,
  `OGIF` double NOT NULL,
  `ONTTR` double NOT NULL,
  `PERF` double NOT NULL,
  `RENME` double NOT NULL,
  `RENOB` double NOT NULL,
  `RENTE` double NOT NULL,
  `ROER` double NOT NULL,
  `STORT` double NOT NULL,
  `TOB` double NOT NULL,
  `TVDIV` double NOT NULL,
  `UGIF` double NOT NULL,
  `UITK` double NOT NULL,
  `VALK` double NOT NULL,
  `VEBH` double NOT NULL,
  `VERM` double NOT NULL,
  `VKSTO` double NOT NULL,
  `VMAR` double NOT NULL,
  `VTRES` double NOT NULL,
  `WINPE` double NOT NULL,
  `liquiditeiten` double NOT NULL,
  `add_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Portefeuille` (`Portefeuille`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=85 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reportbuilder_jhorst`
--

DROP TABLE IF EXISTS `reportbuilder_jhorst`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reportbuilder_jhorst` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Rapport` varchar(20) NOT NULL,
  `Portefeuille` varchar(24) NOT NULL,
  `Vermogensbeheerder` varchar(10) NOT NULL,
  `Client` varchar(16) NOT NULL,
  `Naam` varchar(50) NOT NULL,
  `Naam1` varchar(50) NOT NULL,
  `totaalvermogen` double NOT NULL,
  `inprocenttotaal` double NOT NULL,
  `performance` double NOT NULL,
  `resultaat` double NOT NULL,
  `rendement` double NOT NULL,
  `AFMstd` double NOT NULL,
  `BEGIN` double NOT NULL,
  `BEH` double NOT NULL,
  `BEW` double NOT NULL,
  `BTLBR` double NOT NULL,
  `BTW` double NOT NULL,
  `BTWAU` double NOT NULL,
  `DIV` double NOT NULL,
  `DIVBE` double NOT NULL,
  `FONDS` double NOT NULL,
  `HUUR` double NOT NULL,
  `KNBA` double NOT NULL,
  `KNOG` double NOT NULL,
  `KOBU` double NOT NULL,
  `KOST` double NOT NULL,
  `Kruis` double NOT NULL,
  `MEM` double NOT NULL,
  `MWBEL` double NOT NULL,
  `OG` double NOT NULL,
  `ONTTR` double NOT NULL,
  `RENME` double NOT NULL,
  `RENOB` double NOT NULL,
  `RENTE` double NOT NULL,
  `ROER` double NOT NULL,
  `STORT` double NOT NULL,
  `TOB` double NOT NULL,
  `VALK` double NOT NULL,
  `VERM` double NOT NULL,
  `VKSTO` double NOT NULL,
  `VMAR` double NOT NULL,
  `VTRES` double NOT NULL,
  `liquiditeiten` double NOT NULL,
  `add_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Portefeuille` (`Portefeuille`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reportbuilder_rbolle`
--

DROP TABLE IF EXISTS `reportbuilder_rbolle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reportbuilder_rbolle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Rapport` varchar(20) NOT NULL,
  `Portefeuille` varchar(24) NOT NULL,
  `Vermogensbeheerder` varchar(10) NOT NULL,
  `Client` varchar(16) NOT NULL,
  `Naam` varchar(50) NOT NULL,
  `Naam1` varchar(50) NOT NULL,
  `totaalvermogen` double NOT NULL,
  `Risicoklasse` varchar(50) NOT NULL,
  `Conclusie` varchar(50) NOT NULL,
  `Reden` varchar(255) NOT NULL,
  `norm` varchar(255) NOT NULL,
  `add_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Portefeuille` (`Portefeuille`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sarTransactieCodes`
--

DROP TABLE IF EXISTS `sarTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sarTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `bankCode` varchar(10) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `saxoTransactieCodes`
--

DROP TABLE IF EXISTS `saxoTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saxoTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `bankCode` varchar(40) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `scenarioInstellingen`
--

DROP TABLE IF EXISTS `scenarioInstellingen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scenarioInstellingen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vermogensbeheerder` varchar(10) DEFAULT NULL,
  `jaarVanaf` int(11) DEFAULT NULL,
  `risicoklasse` varchar(50) DEFAULT NULL,
  `standaarddeviatie` float NOT NULL DEFAULT '0',
  `verwachtRendement` float NOT NULL DEFAULT '0',
  `add_date` datetime DEFAULT NULL,
  `add_user` varchar(15) DEFAULT NULL,
  `change_user` varchar(15) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `scenariosPerVermogensbeheerder`
--

DROP TABLE IF EXISTS `scenariosPerVermogensbeheerder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scenariosPerVermogensbeheerder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vermogensbeheerder` varchar(10) DEFAULT NULL,
  `scenario` varchar(150) NOT NULL DEFAULT '',
  `percentage` float NOT NULL DEFAULT '0',
  `add_date` datetime DEFAULT NULL,
  `add_user` varchar(15) DEFAULT NULL,
  `change_user` varchar(15) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `kleurcode` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=133 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `signaleringPortRend`
--

DROP TABLE IF EXISTS `signaleringPortRend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `signaleringPortRend` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `portefeuille` varchar(24) NOT NULL,
  `periode` varchar(3) NOT NULL,
  `signaleringsPercentage` double NOT NULL DEFAULT '0',
  `datum` date NOT NULL DEFAULT '0000-00-00',
  `status` tinyint(3) NOT NULL DEFAULT '0',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `toelichting` text NOT NULL,
  `rendementDetails` text NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `portefeuille` (`portefeuille`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `signaleringStortingen`
--

DROP TABLE IF EXISTS `signaleringStortingen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `signaleringStortingen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `portefeuille` varchar(24) NOT NULL,
  `periode` varchar(3) NOT NULL,
  `bedrag` double NOT NULL DEFAULT '0',
  `datum` date NOT NULL DEFAULT '0000-00-00',
  `rekeningmutatieId` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(3) NOT NULL DEFAULT '0',
  `toelichting` varchar(50) NOT NULL,
  `opmerking` text NOT NULL,
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `passend` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `portefeuille` (`portefeuille`) USING BTREE,
  KEY `rekeningmutatieId` (`rekeningmutatieId`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `socgenTransactieCodes`
--

DROP TABLE IF EXISTS `socgenTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `socgenTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `bankCode` varchar(50) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `standaardTaken`
--

DROP TABLE IF EXISTS `standaardTaken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `standaardTaken` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hoofdtaak` varchar(256) NOT NULL DEFAULT '',
  `taak` varchar(256) NOT NULL DEFAULT '',
  `add_date` datetime DEFAULT NULL,
  `add_user` varchar(15) DEFAULT NULL,
  `change_user` varchar(15) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `dagenTotZichtbaar` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tableLocks`
--

DROP TABLE IF EXISTS `tableLocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tableLocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(15) DEFAULT '',
  `table` varchar(50) DEFAULT '',
  `tableId` int(11) DEFAULT '0',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT '',
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3622 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `taken`
--

DROP TABLE IF EXISTS `taken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taken` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `gebruiker` tinytext,
  `kop` tinytext NOT NULL,
  `txt` text,
  `afgewerkt` tinyint(1) NOT NULL DEFAULT '0',
  `relatie` varchar(128) NOT NULL DEFAULT '',
  `soort` varchar(40) NOT NULL DEFAULT '',
  `spoed` tinyint(1) NOT NULL DEFAULT '0',
  `zichtbaar` date DEFAULT '0000-00-00',
  `add_date` datetime DEFAULT NULL,
  `add_user` varchar(15) DEFAULT NULL,
  `change_user` varchar(15) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `standaardtaakId` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `rel_id` (`rel_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `taken_gebruiker`
--

DROP TABLE IF EXISTS `taken_gebruiker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taken_gebruiker` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(10) NOT NULL DEFAULT '0',
  `taken_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `agenda` (`user_id`,`taken_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tempLaatsteFondsWaarden`
--

DROP TABLE IF EXISTS `tempLaatsteFondsWaarden`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tempLaatsteFondsWaarden` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `beginAantal` decimal(18,6) NOT NULL,
  `totaalAantal` decimal(18,6) NOT NULL,
  `historischeWaarde` double NOT NULL DEFAULT '0',
  `historischeValutakoers` double NOT NULL DEFAULT '0',
  `beginwaardeLopendeJaar` double NOT NULL DEFAULT '0',
  `fondsEenheid` double NOT NULL DEFAULT '0',
  `actueleValuta` double NOT NULL DEFAULT '0',
  `beginwaardeValutaLopendeJaar` double NOT NULL DEFAULT '0',
  `fondsOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `actueleFonds` double NOT NULL DEFAULT '0',
  `beginJaarPortefeuilleWaardeInValuta` double NOT NULL DEFAULT '0',
  `beginJaarPortefeuilleWaardeEuro` double NOT NULL DEFAULT '0',
  `beginPortefeuilleWaardeInValuta` double NOT NULL DEFAULT '0',
  `beginPortefeuilleWaardeEuro` double NOT NULL DEFAULT '0',
  `actuelePortefeuilleWaardeInValuta` double NOT NULL DEFAULT '0',
  `actuelePortefeuilleWaardeEuro` double NOT NULL DEFAULT '0',
  `fonds` varchar(25) NOT NULL DEFAULT '',
  `renteBerekenen` tinyint(1) NOT NULL DEFAULT '0',
  `rentePercentage` double NOT NULL DEFAULT '0',
  `renteDagen` int(11) NOT NULL DEFAULT '0',
  `eersteRentedatum` date NOT NULL DEFAULT '0000-00-00',
  `rentedatum` date NOT NULL DEFAULT '0000-00-00',
  `renteperiode` tinyint(4) NOT NULL DEFAULT '0',
  `renteVanaf` date NOT NULL DEFAULT '0000-00-00',
  `opgelopenRente` double NOT NULL DEFAULT '0',
  `opgelopenRenteEuro` double NOT NULL DEFAULT '0',
  `portefeuille` varchar(24) NOT NULL,
  `rekening` varchar(25) NOT NULL DEFAULT '',
  `type` varchar(25) NOT NULL DEFAULT '',
  `rapportageDatum` date NOT NULL DEFAULT '0000-00-00',
  `Lossingsdatum` date NOT NULL DEFAULT '0000-00-00',
  `historischeRapportageValutakoers` double NOT NULL DEFAULT '0',
  `Bewaarder` varchar(20) NOT NULL DEFAULT '',
  `EindDatum` date NOT NULL DEFAULT '0000-00-00',
  `koersDatum` date NOT NULL DEFAULT '0000-00-00',
  `beleggingscategorie` varchar(15) NOT NULL DEFAULT '',
  `beleggingscategorieOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `beleggingssectorOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `hoofdcategorie` varchar(15) NOT NULL DEFAULT '',
  `hoofdsector` varchar(15) NOT NULL DEFAULT '',
  `hoofdcategorieOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `hoofdsectorOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `hoofdcategorieVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `hoofdsectorVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `beleggingssector` varchar(15) NOT NULL DEFAULT '',
  `beleggingssectorVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `beleggingscategorieVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `valuta` varchar(4) NOT NULL DEFAULT '',
  `valutaVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `valutaOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `regio` varchar(15) NOT NULL DEFAULT '',
  `regioOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `regioVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `attributieCategorie` varchar(15) NOT NULL DEFAULT '',
  `attributieCategorieVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `attributieCategorieOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `afmCategorie` varchar(15) NOT NULL DEFAULT '',
  `afmCategorieOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `afmCategorieVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `fondspaar` int(11) NOT NULL,
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(15) NOT NULL DEFAULT '',
  `duurzaamCategorie` varchar(15) NOT NULL,
  `duurzaamCategorieOmschrijving` varchar(50) NOT NULL,
  `duurzaamCategorieVolgorde` tinyint(4) NOT NULL DEFAULT '127',
  `weging` double NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `portefeuille` (`portefeuille`) USING BTREE,
  KEY `fonds` (`fonds`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tempLaatstePortefeuilleWaarde`
--

DROP TABLE IF EXISTS `tempLaatstePortefeuilleWaarde`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tempLaatstePortefeuilleWaarde` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `portefeuille` varchar(24) NOT NULL,
  `laatsteWaarde` double DEFAULT NULL,
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `rendement` double NOT NULL DEFAULT '0',
  `beginWaarde` double NOT NULL DEFAULT '0',
  `Stortingen` double NOT NULL DEFAULT '0',
  `Onttrekkingen` double NOT NULL DEFAULT '0',
  `Opbrengsten` double NOT NULL DEFAULT '0',
  `Kosten` double NOT NULL DEFAULT '0',
  `gerealiseerd` double NOT NULL DEFAULT '0',
  `ongerealiseerd` double NOT NULL DEFAULT '0',
  `mutatieOpgelopenRente` double NOT NULL DEFAULT '0',
  `afmstdev` double NOT NULL DEFAULT '0',
  `zorgMeting` varchar(50) NOT NULL DEFAULT '',
  `kansOpDoelvermogen` double NOT NULL DEFAULT '0',
  `toelichting` varchar(200) NOT NULL,
  `BEH` double NOT NULL,
  `BEW` double NOT NULL,
  `KNBA` double NOT NULL,
  `KOBU` double NOT NULL,
  `KOST` double NOT NULL,
  `ROER` double NOT NULL,
  `TOB` double NOT NULL,
  `DIV` double NOT NULL,
  `VTRES` double NOT NULL,
  `HUUR` double NOT NULL,
  `VMAR` double NOT NULL,
  `VKSTO` double NOT NULL,
  `RENTE` double NOT NULL,
  `RENOB` double NOT NULL,
  `RENME` double NOT NULL,
  `DIVBE` double NOT NULL,
  `OG` double NOT NULL,
  `omzet` double NOT NULL DEFAULT '0',
  `gemVermogen` double NOT NULL DEFAULT '0',
  `omzetsnelheid` double NOT NULL DEFAULT '0',
  `rendementModel` double NOT NULL,
  `benchmarkRendement` double NOT NULL DEFAULT '0',
  `vkm` double NOT NULL DEFAULT '0',
  `vkmDoorlKst` double NOT NULL DEFAULT '0',
  `vkmDirK` double NOT NULL DEFAULT '0',
  `saldoGeldrek` double NOT NULL DEFAULT '0',
  `rapportageDatum` date NOT NULL,
  `rendementQTD` double NOT NULL,
  `rendementMTD` double NOT NULL,
  `ptfSignMethode` varchar(3) NOT NULL,
  `SignRapDatumRend` double NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `portefeuille` (`portefeuille`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tgc_blacklist`
--

DROP TABLE IF EXISTS `tgc_blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tgc_blacklist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `ip` varchar(20) NOT NULL,
  `memo` text NOT NULL,
  `onList` datetime NOT NULL,
  `offList` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tgc_ipAccessList`
--

DROP TABLE IF EXISTS `tgc_ipAccessList`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tgc_ipAccessList` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `ip` varchar(20) NOT NULL,
  `locatie` varchar(60) NOT NULL,
  `bedrijf` varchar(15) NOT NULL,
  `onlineDatum` date NOT NULL,
  `offlineDatum` date NOT NULL,
  `loginVan` time NOT NULL,
  `loginTot` time NOT NULL,
  `logging` text NOT NULL,
  `memo` text NOT NULL,
  `whitelist` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tgc_log`
--

DROP TABLE IF EXISTS `tgc_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tgc_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `ip` varchar(20) NOT NULL,
  `dns` varchar(100) NOT NULL,
  `memo` text NOT NULL,
  `stamp` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tijdelijkeRecon`
--

DROP TABLE IF EXISTS `tijdelijkeRecon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tijdelijkeRecon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `vermogensbeheerder` varchar(10) NOT NULL,
  `depotbank` varchar(10) NOT NULL,
  `portefeuille` varchar(25) NOT NULL,
  `rekeningnummer` varchar(25) NOT NULL,
  `client` varchar(25) NOT NULL,
  `cashPositie` tinyint(4) NOT NULL,
  `fonds` varchar(75) NOT NULL,
  `importCode` varchar(25) NOT NULL,
  `depotbankFondsCode` varchar(50) NOT NULL,
  `isinCode` varchar(26) NOT NULL,
  `valuta` varchar(5) NOT NULL,
  `positieBank` double NOT NULL,
  `positieAirs` double NOT NULL,
  `verschil` double NOT NULL,
  `fondsCodeMatch` varchar(75) NOT NULL,
  `batch` varchar(25) NOT NULL,
  `Einddatum` date NOT NULL,
  `Accountmanager` varchar(50) NOT NULL,
  `reconDatum` date NOT NULL,
  `positieAirsGisteren` double NOT NULL,
  `koers` double NOT NULL,
  `koersDatum` date NOT NULL,
  `fondsImportcode` varchar(16) NOT NULL,
  `fileBankCode` varchar(50) NOT NULL,
  `opmerking` varchar(50) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tmpFondsenPerBedrijf`
--

DROP TABLE IF EXISTS `tmpFondsenPerBedrijf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tmpFondsenPerBedrijf` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Bedrijf` varchar(20) NOT NULL DEFAULT '',
  `Fonds` varchar(25) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `Bedrijf` (`Bedrijf`) USING BTREE,
  KEY `Fonds` (`Fonds`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tmpOrder`
--

DROP TABLE IF EXISTS `tmpOrder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tmpOrder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tmpOrdernr` int(11) NOT NULL DEFAULT '0',
  `Fonds` varchar(25) NOT NULL DEFAULT '',
  `FondsOmschrijving` varchar(50) NOT NULL DEFAULT '',
  `ISINCode` varchar(26) NOT NULL DEFAULT '',
  `Portefeuille` varchar(24) NOT NULL,
  `ClientNaam` varchar(60) NOT NULL DEFAULT '',
  `Aantal` decimal(9,2) NOT NULL DEFAULT '0.00',
  `AankoopWaarde` decimal(9,2) NOT NULL DEFAULT '0.00',
  `Depotbank` varchar(10) NOT NULL DEFAULT '',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tmp_reportbuilder_jhorst`
--

DROP TABLE IF EXISTS `tmp_reportbuilder_jhorst`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tmp_reportbuilder_jhorst` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Portefeuille` varchar(24) NOT NULL,
  `Vermogensbeheerder` varchar(10) NOT NULL,
  `Client` varchar(16) NOT NULL,
  `Consolidatie` tinyint(4) NOT NULL DEFAULT '0',
  `Naam` varchar(50) NOT NULL,
  `Depotbank` varchar(10) NOT NULL,
  `InternDepot` tinyint(4) NOT NULL DEFAULT '0',
  `Startdatum` datetime NOT NULL,
  `Einddatum` datetime NOT NULL,
  `ClientVermogensbeheerder` varchar(10) NOT NULL,
  `Accountmanager` varchar(15) NOT NULL,
  `Risicoprofiel` varchar(15) NOT NULL,
  `SoortOvereenkomst` varchar(15) NOT NULL,
  `Risicoklasse` varchar(50) NOT NULL,
  `Remisier` varchar(15) NOT NULL,
  `AFMprofiel` varchar(15) NOT NULL,
  `ModelPortefeuille` varchar(12) NOT NULL,
  `totaalvermogen` double NOT NULL,
  `totaalbeginvermogen` double NOT NULL,
  `inprocenttotaal` double NOT NULL,
  `performance` double NOT NULL,
  `resultaat` double NOT NULL,
  `rendement` double NOT NULL,
  `OnttrLicht` double NOT NULL,
  `Onttrekkingen` double NOT NULL,
  `Lichtingen` double NOT NULL,
  `StortDepon` double NOT NULL,
  `Stortingen` double NOT NULL,
  `Deponeringen` double NOT NULL,
  `dividend` double NOT NULL,
  `dividendbelasting` double NOT NULL,
  `rente` double NOT NULL,
  `koersongerealiseerd` double NOT NULL,
  `koersgerealiseerd` double NOT NULL,
  `stockdividend` double NOT NULL,
  `creditrente` double NOT NULL,
  `transactiekosten` double NOT NULL,
  `kostenBuitenland` double NOT NULL,
  `beheerfee` double NOT NULL,
  `bewaarloon` double NOT NULL,
  `bankkosten` double NOT NULL,
  `liquiditeiten` double NOT NULL,
  `gemVermogen` double NOT NULL,
  `omzet` double NOT NULL,
  `omzetsnelheid` double NOT NULL,
  `benchmarkRendement` double NOT NULL,
  `BANK` double NOT NULL,
  `TOB` double NOT NULL,
  `BTLBR` double NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `toelichtingStortOnttr`
--

DROP TABLE IF EXISTS `toelichtingStortOnttr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `toelichtingStortOnttr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `toelichting` varchar(50) NOT NULL,
  `change_user` varchar(10) NOT NULL,
  `change_date` datetime NOT NULL,
  `add_user` varchar(10) NOT NULL,
  `add_date` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trackAndTrace`
--

DROP TABLE IF EXISTS `trackAndTrace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trackAndTrace` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tabel` varchar(50) NOT NULL DEFAULT '',
  `recordId` bigint(20) NOT NULL DEFAULT '0',
  `veld` varchar(50) NOT NULL DEFAULT '',
  `oudeWaarde` mediumtext NOT NULL,
  `nieuweWaarde` mediumtext NOT NULL,
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `add_date` (`add_date`) USING BTREE,
  KEY `tabelId` (`tabel`,`recordId`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ubsluxTransactieCodes`
--

DROP TABLE IF EXISTS `ubsluxTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ubsluxTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `bankCode` varchar(40) NOT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `uitsluitingenModelcontrole`
--

DROP TABLE IF EXISTS `uitsluitingenModelcontrole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uitsluitingenModelcontrole` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `portefeuille` varchar(24) NOT NULL,
  `fonds` varchar(25) DEFAULT NULL,
  `rekening` varchar(25) NOT NULL,
  `bedrag` double NOT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `Beleggingscategorie` varchar(15) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `portefeuille` (`portefeuille`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `updateInformatie`
--

DROP TABLE IF EXISTS `updateInformatie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `updateInformatie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `versie` double DEFAULT '0',
  `informatie` text,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) DEFAULT NULL,
  `publiceer` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1572 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usageLog`
--

DROP TABLE IF EXISTS `usageLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usageLog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `object` varchar(50) NOT NULL DEFAULT '',
  `query` mediumtext NOT NULL,
  `add_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(15) NOT NULL DEFAULT '',
  `filename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `date_user` (`add_date`,`add_user`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=87 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `veldopmaak`
--

DROP TABLE IF EXISTS `veldopmaak`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `veldopmaak` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tabel` varchar(60) NOT NULL DEFAULT '',
  `veld` varchar(60) NOT NULL DEFAULT '',
  `uitlijning` varchar(1) NOT NULL DEFAULT '',
  `getalformat` varchar(10) NOT NULL DEFAULT '',
  `aantalRegels` tinyint(3) NOT NULL DEFAULT '0',
  `weergaveBreedte` tinyint(3) NOT NULL DEFAULT '0',
  `headerBreedte` tinyint(3) NOT NULL DEFAULT '0',
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `add_user` varchar(10) NOT NULL DEFAULT '',
  `change_date` datetime DEFAULT '0000-00-00 00:00:00',
  `change_user` varchar(10) NOT NULL DEFAULT '',
  `formExtra` text NOT NULL,
  `formExtraTxt` text NOT NULL,
  `nietLeeg` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vlchTransactieCodes`
--

DROP TABLE IF EXISTS `vlchTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vlchTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `bankCode` varchar(25) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vpTransactieCodes`
--

DROP TABLE IF EXISTS `vpTransactieCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vpTransactieCodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `bankCode` varchar(25) NOT NULL,
  `doActie` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `widgetCache`
--

DROP TABLE IF EXISTS `widgetCache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widgetCache` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `change_user` varchar(10) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `add_user` varchar(10) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `widgetName` varchar(40) NOT NULL,
  `user` varchar(20) NOT NULL,
  `ttl` datetime NOT NULL,
  `content` mediumblob NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-27  9:27:29
